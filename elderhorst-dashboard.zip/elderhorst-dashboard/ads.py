"""
Live advertentiedashboard (Meta Marketing API).

Vereist de permissie `ads_read` op het token en toegang van de systeemgebruiker tot het advertentieaccount van de klant.
Per klant aan/uit te zetten (tabel ads_settings in data.db). Cijfers worden 15 minuten bewaard ('live').
"""
import json
import re
from datetime import date, timedelta

import store
from meta_client import DAY, MetaApiError

LIVE_TTL = 15 * 60
FIELDS = "spend,impressions,reach,frequency,clicks,inline_link_clicks,ctr,cpc,cpm,actions,cost_per_action_type"

# Wat telt als 'resultaat' (eerste die voorkomt wint) en hoe we het noemen
RESULT_PRIORITY = [
    ("lead", "Leads"), ("onsite_conversion.lead_grouped", "Leads"), ("offsite_conversion.fb_pixel_lead", "Leads"),
    ("offsite_conversion.fb_pixel_purchase", "Aankopen"), ("purchase", "Aankopen"),
    ("onsite_conversion.messaging_conversation_started_7d", "Gesprekken gestart"),
    ("landing_page_view", "Bezoeken landingspagina"), ("link_click", "Linkklikken"),
    ("video_view", "Videoweergaven"), ("post_engagement", "Interacties"),
]
ACTION_LABELS = dict(RESULT_PRIORITY) | {
    "post_reaction": "Reacties (likes)", "comment": "Opmerkingen",
    "onsite_conversion.post_save": "Keer opgeslagen", "post": "Keer gedeeld", "like": "Paginalikes",
    "follow": "Nieuwe volgers",
}
PERMISSION_HELP = ("Het token heeft geen toegang tot advertenties. Voeg in Business-instellingen bij de systeemgebruiker "
                   "de permissie ads_read toe, wijs het advertentieaccount van de klant toe en maak een nieuw token aan.")


class AdsError(Exception):
    pass


def _call(fn):
    try:
        return fn()
    except MetaApiError as e:
        if e.code in (200, 10) or "ermission" in str(e):
            raise AdsError(PERMISSION_HELP)
        raise


def ad_accounts(c):
    rows = _call(lambda: c.get_all("me/adaccounts", {
        "fields": "id,name,account_status,currency,business{name}", "limit": 100}, ttl=3600))
    return sorted([{"id": r["id"], "name": r.get("name") or r["id"], "business": (r.get("business") or {}).get("name"),
                    "currency": r.get("currency"), "active": r.get("account_status") == 1} for r in rows],
                  key=lambda a: a["name"].lower())


def suggest_account(accounts, page_name):
    """Kies het advertentieaccount waarvan de naam het meest lijkt op de paginanaam."""
    words = lambda s: {w for w in re.findall(r"[a-z0-9]+", (s or "").lower()) if len(w) > 2 and w not in ("b.v", "bv")}
    target = words(page_name)
    best = max(accounts, key=lambda a: len(target & (words(a["name"]) | words(a["business"]))), default=None)
    return best["id"] if best and target & (words(best["name"]) | words(best["business"])) else None


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _actions(row, key="actions"):
    return {a["action_type"]: _num(a.get("value")) or 0 for a in row.get(key) or []}


def summarize(row, rtype=None):
    """Zet één insights-rij om naar getallen, met 'resultaat' en kosten per resultaat.
    Met rtype tellen alle rijen hetzelfde soort resultaat (anders vergelijk je leads met klikken)."""
    if not row:
        return None
    acts = _actions(row)
    spend = _num(row.get("spend")) or 0
    if rtype:
        result = (rtype, dict(RESULT_PRIORITY).get(rtype, rtype), acts.get(rtype, 0))
    else:
        result = next(((t, l, acts[t]) for t, l in RESULT_PRIORITY if acts.get(t)), None)
    out = {
        "spend": spend, "impressions": _num(row.get("impressions")), "reach": _num(row.get("reach")),
        "frequency": _num(row.get("frequency")), "clicks": _num(row.get("clicks")),
        "link_clicks": _num(row.get("inline_link_clicks")) or acts.get("link_click"),
        "ctr": _num(row.get("ctr")), "cpc": _num(row.get("cpc")), "cpm": _num(row.get("cpm")),
        "result_type": result and result[0], "result_label": result and result[1], "results": result and result[2],
        "cost_per_result": (spend / result[2]) if result and result[2] else None,
        "actions": _action_list(acts),
    }
    return out


def _action_list(acts):
    """Acties met Nederlandse naam; dubbele namen (bv. twee soorten leads) één keer, de hoogste waarde."""
    best = {}
    for k, v in acts.items():
        if k in ACTION_LABELS:
            label = ACTION_LABELS[k]
            best[label] = max(best.get(label, 0), v)
    return sorted(best.items(), key=lambda x: -x[1])


def _insights(c, acct, since, until, **extra):
    ttl = LIVE_TTL if until >= date.today() - timedelta(days=2) else 7 * DAY
    params = {"fields": FIELDS, "time_range": json.dumps({"since": since.isoformat(), "until": until.isoformat()}), "limit": 500}
    for k, v in extra.items():
        if k == "fields":
            params["fields"] = FIELDS + "," + v
        else:
            params[k] = v
    return _call(lambda: c.get_all(f"{acct}/insights", params, ttl=ttl, max_pages=10))


def client_ads(c, pid, since, until):
    st = store.get_ads_settings(pid)
    if not st["enabled"]:
        raise AdsError("Het advertentiedashboard staat uit voor deze klant.")
    if not st["ad_account_id"]:
        raise AdsError("Kies eerst het advertentieaccount van deze klant.")
    acct = st["ad_account_id"] if st["ad_account_id"].startswith("act_") else "act_" + st["ad_account_id"]
    until = min(until, date.today())
    since = min(since, until)
    n = (until - since).days + 1
    prev = (since - timedelta(days=n), since - timedelta(days=1))

    info = _call(lambda: c.get(acct, {"fields": "name,currency,account_status,timezone_name"}, ttl=3600))
    # Eén soort resultaat voor de hele pagina, bepaald over minimaal 30 dagen
    # (anders wordt 'vandaag' zonder leads ineens 'bezoeken landingspagina').
    if n < 30:
        wide = summarize((_insights(c, acct, until - timedelta(days=29), until) or [None])[0])
        rtype = wide and wide.get("result_type")
        total = summarize((_insights(c, acct, since, until) or [None])[0], rtype)
    else:
        total = summarize((_insights(c, acct, since, until) or [None])[0])
        rtype = total and total.get("result_type")
    previous = summarize((_insights(c, acct, *prev) or [None])[0], rtype)
    daily = [{"date": r["date_start"], **summarize(r, rtype)} for r in _insights(c, acct, since, until, time_increment=1)]

    # Campagnes: cijfers + status en budget (budget staat op campagne- óf advertentiesetniveau)
    camp_rows = _insights(c, acct, since, until, level="campaign", fields="campaign_id,campaign_name,objective")
    meta = {x["id"]: x for x in _call(lambda: c.get_all(f"{acct}/campaigns", {
        "fields": "id,name,effective_status,daily_budget,lifetime_budget,objective", "limit": 200}, ttl=LIVE_TTL, max_pages=5))}
    set_budget = {}
    for s_ in _call(lambda: c.get_all(f"{acct}/adsets", {
            "fields": "campaign_id,effective_status,daily_budget,lifetime_budget", "limit": 200}, ttl=LIVE_TTL, max_pages=5)):
        if s_.get("effective_status") != "ACTIVE":
            continue
        kind = "per dag" if _num(s_.get("daily_budget")) else "totaal" if _num(s_.get("lifetime_budget")) else None
        if kind:
            b = set_budget.setdefault(s_["campaign_id"], {"amount": 0, "type": kind})
            b["amount"] += (_num(s_.get("daily_budget")) or _num(s_.get("lifetime_budget"))) / 100
    campaigns = []
    for r in camp_rows:
        m = meta.get(r.get("campaign_id"), {})
        s = summarize(r, rtype)
        budget = _num(m.get("daily_budget")) or _num(m.get("lifetime_budget"))
        if budget:
            budget, btype = budget / 100, "per dag" if _num(m.get("daily_budget")) else "totaal"
        else:
            sb = set_budget.get(r.get("campaign_id")) or {}
            budget, btype = sb.get("amount"), sb.get("type")
        campaigns.append({**s, "id": r.get("campaign_id"), "name": r.get("campaign_name"),
                          "status": m.get("effective_status"), "budget": budget, "budget_type": btype})
    campaigns.sort(key=lambda x: -(x["spend"] or 0))

    # Advertenties met afbeelding (top 6 op resultaten, dan uitgaven)
    ad_rows = _insights(c, acct, since, until, level="ad", fields="ad_id,ad_name,campaign_name")
    ads = sorted(({**summarize(r, rtype), "id": r.get("ad_id"), "name": r.get("ad_name"), "campaign": r.get("campaign_name")}
                  for r in ad_rows), key=lambda x: (-(x["results"] or 0), -(x["spend"] or 0)))[:6]
    if ads:
        # Meta ondersteunt '?ids=' niet meer (v26+): daarom alle advertenties van het account in één lijst ophalen
        try:
            creatives = {a["id"]: a for a in c.get_all(f"{acct}/ads", {
                "fields": "id,effective_status,creative.thumbnail_width(480).thumbnail_height(480){thumbnail_url,image_url,body,title}",
                "limit": 200}, ttl=LIVE_TTL, max_pages=5)}
        except MetaApiError:
            creatives = {}
        for a in ads:
            cr = (creatives.get(a["id"]) or {}).get("creative") or {}
            a["image"] = cr.get("image_url") or cr.get("thumbnail_url")
            a["text"] = (cr.get("body") or cr.get("title") or "")[:160]
            a["status"] = (creatives.get(a["id"]) or {}).get("effective_status")

    return {"account": {"id": acct, "name": info.get("name"), "currency": info.get("currency") or "EUR",
                        "timezone": info.get("timezone_name")},
            "period": {"since": since.isoformat(), "until": until.isoformat(), "days": n,
                       "prev_since": prev[0].isoformat(), "prev_until": prev[1].isoformat()},
            "total": total, "prev": previous, "daily": daily, "campaigns": campaigns, "ads": ads}
