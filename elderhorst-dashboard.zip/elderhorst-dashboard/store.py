"""
Opslag.

Supabase (als SUPABASE_URL en SUPABASE_SERVICE_KEY in .env staan) is de hoofdopslag voor:
- klantinstellingen (samenwerking, advertentiedashboard), algemene instellingen, berekende cache, dagcijfers.
Lokaal (SQLite, data.db) blijft:
- de cache van ruwe Meta-antwoorden (veel kleine items, hoort niet in een database)
- een kopie van de instellingen, zodat het dashboard blijft werken als Supabase even niet bereikbaar is.
"""
import json
import os
import sqlite3
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

import supa

# Online (Vercel) is alleen /tmp beschrijfbaar; daar is data.db een tijdelijke cache per server.
DB = Path(os.environ.get("DATA_DB") or ("/tmp/data.db" if os.environ.get("VERCEL") else Path(__file__).parent / "data.db"))
_lock = threading.Lock()
_sb = None
_sb_checked = False
_mem = {}          # korte geheugen-cache voor instellingen uit Supabase
MEM_TTL = 20


def sb():
    """Supabase-client, of None als die niet is ingesteld."""
    global _sb, _sb_checked
    if not _sb_checked:
        _sb, _sb_checked = supa.from_env(), True
    return _sb


@contextmanager
def _conn():
    c = sqlite3.connect(DB, timeout=30)
    try:
        yield c
        c.commit()
    finally:
        c.close()


def init():
    with _lock, _conn() as c:
        c.execute("CREATE TABLE IF NOT EXISTS settings(page_id TEXT PRIMARY KEY, start_date TEXT, end_date TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS cache(key TEXT PRIMARY KEY, expires REAL, body TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS ads_settings(page_id TEXT PRIMARY KEY, enabled INTEGER, ad_account_id TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY, value TEXT)")


def _mem_get(key, loader):
    hit = _mem.get(key)
    if hit and time.time() - hit[0] < MEM_TTL:
        return hit[1]
    val = loader()
    _mem[key] = (time.time(), val)
    return val


def _mem_clear():
    _mem.clear()


def _sb_settings():
    """Alle rijen uit client_settings, of None als Supabase niet beschikbaar is."""
    if not sb():
        return None
    try:
        return _mem_get("client_settings", lambda: {r["page_id"]: r for r in sb().select("client_settings")})
    except supa.SupaError:
        return None


# ---------- klanten ----------
def ensure_clients(accounts):
    """Zorgt dat alle pagina's in Supabase staan (nodig voor de koppelingen tussen tabellen)."""
    if not sb():
        return
    sb().upsert("clients", [{"page_id": a["page_id"], "name": a["page_name"],
                             "instagram_id": (a.get("instagram") or {}).get("id"),
                             "instagram_username": (a.get("instagram") or {}).get("username"),
                             "updated_at": _now()} for a in accounts], "page_id")


def parse_ts(ts):
    """Tijdstip uit Supabase → Unix-tijd. Python 3.9 slikt geen 5 cijfers achter de komma, dus eerst aanvullen tot 6."""
    import re
    ts = ts.replace("Z", "+00:00")
    ts = re.sub(r"\.(\d+)", lambda m: "." + (m.group(1) + "000000")[:6], ts)
    return datetime.fromisoformat(ts).timestamp()


def _now():
    return datetime.now(timezone.utc).isoformat()


# ---------- samenwerking ----------
def _local_settings():
    with _conn() as c:
        rows = c.execute("SELECT page_id, start_date, end_date FROM settings").fetchall()
    return {r[0]: {"start": r[1], "end": r[2]} for r in rows}


def all_settings():
    rows = _sb_settings()
    if rows is None:
        return _local_settings()
    return {pid: {"start": r.get("start_date"), "end": r.get("end_date")}
            for pid, r in rows.items() if r.get("start_date") or r.get("end_date")}


def get_settings(page_id):
    return all_settings().get(page_id, {"start": None, "end": None})


def save_settings(page_id, start, end):
    with _lock, _conn() as c:
        c.execute("INSERT OR REPLACE INTO settings VALUES(?,?,?)", (page_id, start or None, end or None))
    if sb():
        sb().upsert("client_settings", [{"page_id": page_id, "start_date": start or None, "end_date": end or None,
                                         "updated_at": _now()}], "page_id")
        _mem_clear()


# ---------- advertenties per klant ----------
def _local_ads():
    with _conn() as c:
        rows = c.execute("SELECT page_id, enabled, ad_account_id FROM ads_settings").fetchall()
    return {r[0]: {"enabled": bool(r[1]), "ad_account_id": r[2]} for r in rows}


def all_ads_settings():
    rows = _sb_settings()
    if rows is None:
        return _local_ads()
    return {pid: {"enabled": bool(r.get("ads_enabled")), "ad_account_id": r.get("ad_account_id")}
            for pid, r in rows.items() if r.get("ads_enabled") or r.get("ad_account_id")}


def get_ads_settings(page_id):
    return all_ads_settings().get(page_id, {"enabled": False, "ad_account_id": None})


def save_ads_settings(page_id, enabled, ad_account_id):
    with _lock, _conn() as c:
        c.execute("INSERT OR REPLACE INTO ads_settings VALUES(?,?,?)", (page_id, 1 if enabled else 0, ad_account_id or None))
    if sb():
        sb().upsert("client_settings", [{"page_id": page_id, "ads_enabled": bool(enabled),
                                         "ad_account_id": ad_account_id or None, "updated_at": _now()}], "page_id")
        _mem_clear()


def migrate_local_to_supabase():
    """Eenmalig: bestaande instellingen uit data.db naar Supabase (alleen wat daar nog niet staat)."""
    if not sb():
        return 0
    existing = {r["page_id"] for r in sb().select("client_settings", select="page_id")}
    local, ads_local = _local_settings(), _local_ads()
    rows = []
    for pid in (set(local) | set(ads_local)) - existing:
        s, a = local.get(pid, {}), ads_local.get(pid, {})
        rows.append({"page_id": pid, "start_date": s.get("start"), "end_date": s.get("end"),
                     "ads_enabled": bool(a.get("enabled")), "ad_account_id": a.get("ad_account_id")})
    if rows:
        sb().upsert("client_settings", rows, "page_id")
        _mem_clear()
    return len(rows)


# ---------- algemene instellingen ----------
APP_DEFAULTS = {"sync_times": ["06:00", "18:00"], "sync_on_new_accounts": True}


def get_app_settings():
    out = dict(APP_DEFAULTS)
    try:
        if sb():
            out.update({r["key"]: r["value"] for r in _mem_get("app_settings", lambda: sb().select("app_settings"))})
            return out
    except supa.SupaError:
        pass
    with _conn() as c:
        out.update({k: json.loads(v) for k, v in c.execute("SELECT key, value FROM app_settings").fetchall()})
    return out


def save_app_settings(values):
    with _lock, _conn() as c:
        for k, v in values.items():
            c.execute("INSERT OR REPLACE INTO app_settings VALUES(?,?)", (k, json.dumps(v)))
    if sb():
        sb().upsert("app_settings", [{"key": k, "value": v, "updated_at": _now()} for k, v in values.items()], "key")
        _mem_clear()


# ---------- berekende cache (Supabase, gedeeld en 2x per dag ververst) ----------
def computed_get(key, max_age):
    if sb():
        try:
            rows = sb().select("computed_cache", {"key": f"eq.{key}"}, select="body,updated_at", limit=1)
            if rows:
                age = time.time() - parse_ts(rows[0]["updated_at"])
                if age < max_age:
                    return rows[0]["body"]
            return None
        except supa.SupaError:
            pass
    return cache_get("cc:" + key)


def computed_set(key, body, page_id=None, ttl=13 * 3600):
    cache_set("cc:" + key, body, ttl)   # lokale kopie
    if sb():
        try:
            sb().upsert("computed_cache", [{"key": key, "page_id": page_id, "body": body, "updated_at": _now()}], "key")
        except supa.SupaError:
            pass


# ---------- lokale cache van Meta-antwoorden ----------
def cache_get(key):
    with _conn() as c:
        row = c.execute("SELECT expires, body FROM cache WHERE key=?", (key,)).fetchone()
    if row and row[0] > time.time():
        return json.loads(row[1])
    return None


def cache_set(key, body, ttl):
    with _lock, _conn() as c:
        c.execute("INSERT OR REPLACE INTO cache VALUES(?,?,?)", (key, time.time() + ttl, json.dumps(body)))


def cache_clear_recent(max_left=86400):
    """Gooit alles weg wat binnen een dag zou verlopen (recente data); historische data blijft staan."""
    with _lock, _conn() as c:
        c.execute("DELETE FROM cache WHERE expires < ?", (time.time() + max_left,))
