"""
Inloggen met persoonlijke accounts (Supabase Auth).

De browser logt in bij Supabase en stuurt bij elk verzoek het toegangstoken mee (Authorization: Bearer ...).
De server vraagt aan Supabase wie dat is en laat alleen e-mailadressen uit ALLOWED_EMAILS toe.

Instellingen (.env lokaal, Environment Variables op Vercel):
  REQUIRE_LOGIN=1          verplicht inloggen (online staat dit altijd aan)
  SUPABASE_ANON_KEY=...     de publieke 'publishable' sleutel (voor de inlogpagina)
  ALLOWED_EMAILS=@elderhorstmedia.nl,iemand@voorbeeld.nl   domeinen (met @ ervoor) en/of losse adressen
"""
import hashlib
import json
import os
import time
import urllib.error
import urllib.request

_ok = {}          # hash(token) -> (geldig tot, gebruiker)
TOKEN_TTL = 300   # 5 minuten onthouden, daarna opnieuw controleren


class AuthError(Exception):
    pass


def required():
    return os.environ.get("REQUIRE_LOGIN") == "1" or bool(os.environ.get("VERCEL"))


def public_config():
    return {"auth": required(), "supabase_url": os.environ.get("SUPABASE_URL", "").rstrip("/"),
            "supabase_anon_key": os.environ.get("SUPABASE_ANON_KEY", "")}


def _allowed(email):
    email = (email or "").lower()
    rules = [r.strip().lower() for r in os.environ.get("ALLOWED_EMAILS", "").split(",") if r.strip()]
    return any(email.endswith(r) if r.startswith("@") else email == r for r in rules)


def check(header):
    """Geeft de ingelogde gebruiker terug, of gooit AuthError."""
    if not header or not header.lower().startswith("bearer "):
        raise AuthError("Niet ingelogd.")
    token = header[7:].strip()
    key = hashlib.sha256(token.encode()).hexdigest()
    hit = _ok.get(key)
    if hit and hit[0] > time.time():
        return hit[1]
    url = os.environ.get("SUPABASE_URL", "").rstrip("/")
    apikey = os.environ.get("SUPABASE_ANON_KEY") or os.environ.get("SUPABASE_SERVICE_KEY", "")
    if not url or not apikey:
        raise AuthError("Inloggen is niet ingesteld (SUPABASE_URL / SUPABASE_ANON_KEY ontbreekt).")
    req = urllib.request.Request(f"{url}/auth/v1/user", headers={"apikey": apikey, "Authorization": f"Bearer {token}"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            user = json.loads(r.read().decode())
    except urllib.error.HTTPError:
        raise AuthError("Sessie verlopen. Log opnieuw in.")
    except urllib.error.URLError:
        raise AuthError("Supabase is niet bereikbaar.")
    if not _allowed(user.get("email")):
        raise AuthError("Dit account heeft geen toegang tot het dashboard.")
    out = {"id": user.get("id"), "email": user.get("email")}
    if len(_ok) > 500:
        _ok.clear()
    _ok[key] = (time.time() + TOKEN_TTL, out)
    return out
