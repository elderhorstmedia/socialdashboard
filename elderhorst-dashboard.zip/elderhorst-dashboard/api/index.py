"""Ingang voor Vercel: alle /api/...-verzoeken komen hier binnen (zie vercel.json)."""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["TZ"] = os.environ.get("APP_TZ", "Europe/Amsterdam")
time.tzset()

from server import Handler  # noqa: E402


class handler(Handler):
    pass
