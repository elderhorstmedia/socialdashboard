"""
Kleine client voor de Meta Graph API (Facebook Pages + Instagram Business).
Alleen standaardbibliotheek, werkt met Python 3.9+.
Antwoorden worden in SQLite gecachet (zie store.py); het token komt nooit in de cache-sleutel.
"""
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta, timezone

import store

HOUR = 3600
DAY = 86400


class MetaApiError(Exception):
    def __init__(self, message, code=None, status=None):
        super().__init__(message)
        self.code = code
        self.status = status


class MetaClient:
    def __init__(self, access_token, api_version="v24.0"):
        self.token = access_token
        self.base = f"https://graph.facebook.com/{api_version}"
        self._page_tokens = {}
        store.init()

    def get(self, path, params=None, token=None, ttl=None):
        params = dict(params or {})
        key = path.lstrip("/") + "?" + urllib.parse.urlencode(sorted(params.items()))
        hit = store.cache_get(key)
        if hit is not None:
            return hit

        if ttl is None:
            # Afgesloten periodes (tot meer dan 3 dagen geleden) veranderen niet meer: 30 dagen bewaren.
            until = params.get("until")
            ttl = 30 * DAY if until and int(until) < time.time() - 3 * DAY else 3 * HOUR

        q = urllib.parse.urlencode({**params, "access_token": token or self.token})
        url = f"{self.base}/{path.lstrip('/')}?{q}"
        for attempt in range(3):
            try:
                with urllib.request.urlopen(url, timeout=40) as resp:
                    data = json.loads(resp.read().decode())
                break
            except urllib.error.HTTPError as e:
                body = e.read().decode(errors="replace")
                try:
                    err = json.loads(body).get("error", {})
                except ValueError:
                    raise MetaApiError(body, None, e.code)
                # Tijdelijke fouten / rate limit: kort wachten en opnieuw
                if err.get("is_transient") or err.get("code") in (1, 2, 4, 17, 32, 613):
                    if attempt < 2:
                        time.sleep(2 + attempt * 3)
                        continue
                raise MetaApiError(err.get("message", body), err.get("code"), e.code)
            except urllib.error.URLError as e:
                if attempt < 2:
                    time.sleep(2)
                    continue
                raise MetaApiError(f"Netwerkfout: {e.reason}")
        store.cache_set(key, data, ttl)
        return data

    def get_all(self, path, params=None, token=None, max_pages=20, ttl=None):
        """Volgt de cursors en geeft alle 'data'-items terug."""
        out, data = [], self.get(path, params, token, ttl)
        for _ in range(max_pages):
            out.extend(data.get("data", []))
            cursor = data.get("paging", {}).get("cursors", {}).get("after")
            if not data.get("paging", {}).get("next") or not cursor:
                break
            data = self.get(path, {**(params or {}), "after": cursor}, token, ttl)
        return out

    def clear_cache(self):
        store.cache_clear_recent()

    # ---------- accounts ----------
    def list_accounts(self):
        """Alle Facebook-pagina's waar het token bij kan, met gekoppeld IG-account."""
        pages = self.get_all(
            "me/accounts",
            {
                "fields": "id,name,access_token,fan_count,followers_count,picture{url},"
                          "instagram_business_account{id,username,name,followers_count,"
                          "media_count,profile_picture_url}",
                "limit": 100,
            },
        )
        result = []
        for p in pages:
            self._page_tokens[p["id"]] = p.get("access_token")
            ig = p.get("instagram_business_account")
            result.append({
                "page_id": p["id"],
                "page_name": p.get("name"),
                "page_picture": (p.get("picture") or {}).get("data", {}).get("url"),
                "page_followers": p.get("followers_count", p.get("fan_count")),
                "instagram": ig and {
                    "id": ig["id"],
                    "username": ig.get("username"),
                    "followers": ig.get("followers_count"),
                    "media_count": ig.get("media_count"),
                    "picture": ig.get("profile_picture_url"),
                },
            })
        return result

    def account(self, page_id):
        for a in self.list_accounts():
            if a["page_id"] == page_id:
                return a
        raise MetaApiError(f"Geen toegang tot pagina {page_id} met dit token.")

    def page_token(self, page_id):
        if page_id not in self._page_tokens:
            self.list_accounts()
        tok = self._page_tokens.get(page_id)
        if not tok:
            raise MetaApiError(f"Geen toegang tot pagina {page_id} met dit token.")
        return tok


# ---------- helpers ----------
def _ts(d):
    return int(datetime(d.year, d.month, d.day, tzinfo=timezone.utc).timestamp())


def _num(v):
    if isinstance(v, (int, float)):
        return v
    if isinstance(v, dict):  # sommige metrics geven een breakdown-dict terug
        return sum(x for x in v.values() if isinstance(x, (int, float)))
    return 0


def chunks(since, until, days):
    start = since
    while start <= until:
        end = min(start + timedelta(days=days - 1), until)
        yield start, end
        start = end + timedelta(days=1)


def value_day(end_time):
    """Meta zet de waarde van dag X op end_time = X+1 (07:00 UTC). Geeft dag X terug."""
    return date.fromisoformat(end_time[:10]) - timedelta(days=1)
