# Elderhorst Media – Social statistieken dashboard

Haalt Facebook- en Instagram-statistieken van al je klanten op via de Meta Graph API en toont ze in één dashboard.
Geen installatie nodig: alleen Python 3 (staat standaard op je Mac).

```
python3 server.py            # vereist .env met META_ACCESS_TOKEN
```
Open daarna http://localhost:8000

---

## Stap 1 – Meta Business-portfolio op orde

1. Ga naar **business.facebook.com** → zorg dat Elderhorst Media een Business-portfolio heeft.
2. Vraag per klant **partnertoegang** aan tot hun Facebook-pagina én Instagram-account
   (Instellingen → Accounts → Pagina's / Instagram-accounts → *Toegang aanvragen*), of laat de klant
   Elderhorst Media als partner toevoegen.
3. Controleer bij elke klant dat het Instagram-account een **zakelijk of creator-account** is en
   **gekoppeld is aan de Facebook-pagina**. Zonder die koppeling ziet de API het IG-account niet.

## Stap 2 – Meta-app aanmaken

1. Ga naar **developers.facebook.com/apps** → *App maken*.
2. Kies als use case iets als *“Overige”* → type **Business**, en koppel de app aan het Business-portfolio van Elderhorst Media.
3. Voeg de producten toe: **Facebook Login for Business** en **Instagram (API setup with Facebook login)**.

Benodigde permissies:

| Permissie | Waarvoor |
|---|---|
| `pages_show_list` | lijst met pagina's |
| `pages_read_engagement` | posts, reacties, volgers |
| `read_insights` | Facebook-paginastatistieken |
| `instagram_basic` | IG-profiel en media |
| `instagram_manage_insights` | IG-statistieken |
| `business_management` | toegang via het Business-portfolio |

## Stap 3 – Token: System User (aanbevolen voor een bureau)

Een system user-token verloopt niet en is niet gekoppeld aan jouw persoonlijke Facebook-account.

1. Business-instellingen → **Gebruikers → Systeemgebruikers** → *Toevoegen* (rol: Admin).
2. *Assets toewijzen* → selecteer de klantpagina's en Instagram-accounts → recht **“Volledige controle”** of minimaal inzichten bekijken.
3. *Nieuw token genereren* → kies je app → vink de permissies hierboven aan → vervaldatum **“Nooit”**.
4. Kopieer `.env.example` naar `.env` en plak het token bij `META_ACCESS_TOKEN`.

Nieuwe klant erbij? Alleen de assets aan de systeemgebruiker toewijzen; ze verschijnen dan vanzelf in het dashboard (klik *Vernieuwen*).

Test je token los in de **Graph API Explorer** (developers.facebook.com/tools/explorer) met:
`me/accounts?fields=name,instagram_business_account{username}`

## Stap 4 – App Review

Zolang de app in **ontwikkelmodus** staat, werkt hij alleen voor assets van mensen met een rol in de app.
Om pagina's van **klanten** (andere business-portfolio's) uit te lezen heb je voor de permissies hierboven
waarschijnlijk **Advanced Access** nodig via App Review, plus **Business-verificatie** van Elderhorst Media.
Reken daar een paar dagen tot weken voor. Begin met je eigen pagina om alles te testen.

---

## Wat het dashboard toont

**Overzicht alle klanten** (laatste 30 dagen, filter Totaal / Instagram / Facebook, sorteerbaar):
volgersgroei in %, engagement rate tegenover het eigen gemiddelde (6 maanden ervoor), bereik en weergaven met trendpijl,
totaal bereik en weergaven sinds de start van de samenwerking, dagen sinds de laatste post per kanaal, en een stoplicht.

**Stoplicht**: volgersgroei (>1% = +, <0% = −), bereik-trend en engagement vs. gemiddelde (±10%) tellen op.
Positief = groeit, negatief = daalt, anders staat stil. Meer dan 14 dagen niet gepost = één stap lager.
Drempels staan bovenin `analytics.py`.

**Resultatenpagina per klant**: start- en einddatum samenwerking instellen; periode kiezen (samenwerking, 30/90 dagen, 12 maanden, aangepast);
resultaten per kanaal en samen met trend t.o.v. de vorige periode; ontwikkeling over tijd; top 3 en flop 3 posts met thumbnail;
performance per formaat; videokijktijd en retentiecurve (Facebook); doelgroep.

**PDF-rapport voor de klant** (op de klantpagina): vorige maand, laatste 30 of 60 dagen, of sinds de start van de samenwerking.
Bevat samenvatting, voor-en-na (gemiddeld per 30 dagen vóór vs. tijdens de samenwerking), cijfers per kanaal, ontwikkeling,
best presterende posts met thumbnail (op weergaven of interacties, volgens de schuif bij top/flop), wat het best werkt, video, publiek en kansen.
Toon: groei vooraan met groene pijlen; dalingen staan zonder rode pijlen onder 'Kansen voor de komende periode'. Percentages vanaf een
vertrekpunt onder 20 worden niet genoemd (dan 'Nieuw'). Gemaakt met Google Chrome (headless) — dat moet op de Mac staan. Opmaak in `report.css`.

**Tellers op het overzicht**: all-time weergaven en weergaven dit jaar, alleen binnen de samenwerkingsperiodes van klanten met een startdatum.

**Grenzen van de Meta API**
- Statistieken gaan ongeveer 2 jaar terug; volgen/ontvolgen op Instagram ongeveer 1 jaar.
- Instagram geeft geen retentiecurve, alleen gemiddelde en totale kijktijd per reel.
- Facebook geeft geen leeftijd/geslacht meer, alleen land en stad van volgers.
- Accounts onder 100 volgers krijgen van Meta geen demografie en geen volg-/ontvolgcijfers.

## Goed om te weten

- **Metrics veranderen**: Meta hernoemt en schrapt regelmatig metrics. Staat er een gele melding
  “Niet alle metrics beschikbaar”, pas dan de lijsten bovenin `meta_client.py` aan (`PAGE_METRICS`, `IG_TOTAL_METRICS`).
- **Instagram**: maximaal 30 dagen per verzoek (het script knipt langere periodes zelf op); data gaat ongeveer 2 jaar terug.
  Accounts met minder dan 100 volgers krijgen van Meta geen volledige insights.
- **Caching**: antwoorden van Meta staan in `data.db` (SQLite). Recente cijfers 3 uur, afgesloten periodes 30 dagen.
  *Vernieuwen* haalt de recente cijfers opnieuw op. De eerste keer laden duurt per klant 10–40 seconden, daarna gaat het direct.
- **Samenwerkingsdatums** staan in Supabase (met een reservekopie in `data.db`).
- **Beveiliging**: lokaal luistert de server alleen op je eigen computer (127.0.0.1). Online moet iedereen inloggen (zie hieronder).

## Bestanden

- `meta_client.py` – verbinding met de Graph API, met cache
- `analytics.py` – alle berekeningen (overzicht, stoplicht, resultatenpagina)
- `store.py` – instellingen en cache (Supabase, met `data.db` als reserve)
- `supa.py` – verbinding met Supabase (REST)
- `sync.py` – het automatisch verversen (dagcijfers + vooraf berekende cache)
- `supabase_schema.sql` – de tabellen; eenmalig uitvoeren in de SQL Editor van Supabase
- `server.py` – webserver + JSON-API (`/api/accounts`, `/api/client/<id>/overview`, `/api/client/<id>/results`, `/api/client/<id>/settings`)
- `public/` – het dashboard (`index.html`, `app.js`, `style.css`, logo's)

## Live advertentiedashboard (per klant aan/uit)

Op de klantpagina staat het blok **Live advertenties**: schuif aan/uit, advertentieaccount kiezen, Opslaan.
Staat het aan, dan krijgt de klant een "Ads"-label in de zijbalk en een pagina *Open advertentiedashboard* met:
resultaten en kosten per resultaat, uitgaven, bereik, vertoningen, linkklikken, CTR, kosten per klik, verloop per dag,
campagnes (status, budget, resultaten) en de best presterende advertenties met afbeelding. Periodes: vandaag, 7 dagen, 30 dagen, deze maand.
Cijfers worden 15 minuten bewaard en de pagina ververst zichzelf elke 15 minuten.

**Vereist**: permissie `ads_read` op het token en het advertentieaccount van de klant toegewezen aan de systeemgebruiker.
De aan/uit-stand en het gekozen account staan in `data.db` (tabel `ads_settings`). De pagina is los opgebouwd
(`#/klant/<id>/advertenties`), zodat er later een eigen link voor de klant van gemaakt kan worden.

## Supabase en automatisch verversen

In `.env` staan `SUPABASE_URL` en `SUPABASE_SERVICE_KEY` (geheime sleutel, nooit delen). De tabellen maak je eenmalig aan
door `supabase_schema.sql` uit te voeren in de SQL Editor. Alle tabellen staan op slot (Row Level Security), alleen de server kan erbij.

Op het tabblad **Instellingen** stel je in wanneer er ververst wordt (standaard 06:00 en 18:00, maximaal 6 keer per dag) en
of er ook ververst moet worden zodra er een nieuwe pagina of nieuw advertentieaccount bij komt (elke 15 minuten gecontroleerd).
Een verversing:

1. haalt verse cijfers op bij Meta en bewaart de dagcijfers per klant in `daily_metrics` (Facebook, Instagram, advertenties);
2. rekent het overzicht en de laatste 30 dagen per klant vooraf uit en zet die in `computed_cache` – het dashboard laadt daardoor direct;
3. schrijft een regel in `sync_log` (zichtbaar in het logboek op het tabblad Instellingen).

De eerste keer duurt ongeveer 12 minuten (2 jaar geschiedenis), daarna gaat het sneller.
Het dashboard verzorgt het verversen zelf en moet dus draaien; een gemiste verversing wordt ingehaald bij de volgende start.
Andere periodes en de PDF-export worden live berekend en daarna ook bewaard.

## Online (Vercel + GitHub)

| Onderdeel | Waar |
| --- | --- |
| Code | privé repository op GitHub (geheimen staan in `.gitignore` en gaan dus niet mee) |
| Dashboard | Vercel: `public/` als website, `api/index.py` als Python-functie (`vercel.json`) |
| Verversen | GitHub Actions (`.github/workflows/sync.yml`): elk uur een korte controle, echt verversen op de ingestelde tijden of bij een nieuw account |
| Inloggen | Supabase Auth, persoonlijke accounts; alleen adressen uit `ALLOWED_EMAILS` komen binnen |
| PDF | online maakt de browser de PDF (nieuw tabblad → *Opslaan als PDF*); lokaal doet Chrome het nog automatisch |

**Environment Variables in Vercel** (zie `voorbeeld.env`): `META_ACCESS_TOKEN`, `META_API_VERSION`, `SUPABASE_URL`,
`SUPABASE_SERVICE_KEY`, `SUPABASE_ANON_KEY`, `ALLOWED_EMAILS`, en voor *Nu verversen* `GITHUB_REPO` + `GITHUB_TOKEN`
(fine-grained token, alleen deze repository, recht *Actions: Read and write*).

**Secrets in GitHub** (Settings → Secrets and variables → Actions): `META_ACCESS_TOKEN`, `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`.

**Supabase Auth**: zet *Allow new users to sign up* uit, zet de *Site URL* op het Vercel-adres en maak collega's aan via
Authentication → Users → *Add user* (uitnodiging per mail of direct met wachtwoord). Wachtwoord vergeten kan op de inlogpagina.

Een ronde die bezig is staat in `sync_log`; de Mac en GitHub draaien dus nooit tegelijk. Lokaal kun je het dashboard gewoon
blijven gebruiken (`python3 server.py`, zonder inloggen); zet `REQUIRE_LOGIN=1` in `.env` om lokaal ook in te loggen.
