"""
Rekenwerk voor het overzicht (alle klanten) en de resultatenpagina (per klant).

Definities (ook zichtbaar in het dashboard):
- Engagement rate (ER) = interacties / bereik.
  Facebook: interacties = page_post_engagements. Instagram: total_interactions.
- Eigen gemiddelde = ER over de 180 dagen vóór de laatste 30 dagen.
- Bereik Facebook = som van het dagelijkse unieke bereik; Instagram = uniek bereik per blok van max. 30 dagen.
  Over langere periodes is bereik dus een optelsom, geen aantal unieke mensen.
"""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta

import store
from meta_client import DAY, HOUR, MetaApiError, _num, _ts, chunks, value_day

# ---- drempels stoplicht (pas hier aan) ----
GROWTH_UP, GROWTH_DOWN = 1.0, 0.0     # volgersgroei 30 dagen in %: >1% = groei, <0% = daling
TREND_BAND = 10.0                     # bereik en ER: ±10% t.o.v. vorige periode / eigen gemiddelde
STALE_DAYS = 14                       # langer niet gepost = één stap omlaag
HISTORY_DAYS = 728                    # Meta bewaart ongeveer 2 jaar aan insights

IG_TOT = ["reach", "views", "total_interactions", "likes", "comments", "shares", "saves", "profile_links_taps"]
FB_DAILY = ["page_follows", "page_media_view", "page_total_media_view_unique", "page_post_engagements",
            "page_total_actions", "page_video_view_time"]


def yesterday():
    return date.today() - timedelta(days=1)


def pct(new, old):
    if new is None or not old:
        return None
    return round((new - old) / old * 100, 1)


def ratio(a, b):
    return round(a / b * 100, 2) if a is not None and b else None


# =================== Facebook ===================
def fb_daily(c, page_id, since, until, metrics=FB_DAILY):
    """{metric: {date: waarde}} — in blokken van 88 dagen (Meta staat max. ~93 dagen toe)."""
    tok = c.page_token(page_id)
    out = {m: {} for m in metrics}

    def add(rows):
        for m in rows:
            for v in m.get("values", []):
                d = value_day(v["end_time"])
                if since <= d <= until:
                    out.setdefault(m["name"], {})[d] = _num(v.get("value"))

    for s, u in chunks(since, until, 88):
        params = {"period": "day", "since": _ts(s), "until": _ts(u + timedelta(days=2))}
        try:
            add(c.get(f"{page_id}/insights", {**params, "metric": ",".join(metrics)}, token=tok)["data"])
        except MetaApiError:
            for m in metrics:  # één ongeldige metric mag de rest niet breken
                try:
                    add(c.get(f"{page_id}/insights", {**params, "metric": m}, token=tok)["data"])
                except MetaApiError:
                    pass
    return out


def fb_sum(daily, metric, s, u):
    vals = [v for d, v in daily.get(metric, {}).items() if s <= d <= u]
    return sum(vals) if vals else None


def fb_at(daily, metric, day):
    """Laatste bekende waarde op of vóór `day` (voor cumulatieve metrics zoals page_follows)."""
    pts = [(d, v) for d, v in daily.get(metric, {}).items() if d <= day and v]
    return max(pts)[1] if pts else None


def fb_last_post_days(c, page_id):
    tok = c.page_token(page_id)
    try:
        data = c.get(f"{page_id}/posts", {"fields": "created_time", "limit": 1}, token=tok, ttl=HOUR)["data"]
    except MetaApiError:
        return None
    return (date.today() - date.fromisoformat(data[0]["created_time"][:10])).days if data else None


FB_POST_METRICS = "post_media_view,post_total_media_view_unique,post_clicks," \
                  "post_video_avg_time_watched,post_video_view_time,post_video_retention_graph"


def fb_posts(c, page_id, since, until, cap=300):
    tok = c.page_token(page_id)
    fields = ("id,message,created_time,permalink_url,full_picture,attachments{media_type,type},shares,"
              "reactions.summary(total_count).limit(0),comments.summary(total_count).limit(0)")
    raw = c.get_all(f"{page_id}/posts", {
        "fields": fields, "limit": 50, "since": _ts(since), "until": _ts(until + timedelta(days=1)),
    }, token=tok, max_pages=cap // 50)[:cap]

    def build(p):
        att = ((p.get("attachments") or {}).get("data") or [{}])[0]
        kind = (att.get("media_type") or att.get("type") or "").lower()
        fmt = {"video": "Video", "photo": "Foto", "album": "Album", "link": "Link"}.get(kind, "Tekst" if not kind else "Overig")
        d = date.fromisoformat(p["created_time"][:10])
        post = {
            "channel": "facebook", "id": p["id"], "date": d.isoformat(), "format": fmt,
            "text": (p.get("message") or "")[:200], "url": p.get("permalink_url"), "image": p.get("full_picture"),
            "likes": p.get("reactions", {}).get("summary", {}).get("total_count", 0),
            "comments": p.get("comments", {}).get("summary", {}).get("total_count", 0),
            "shares": p.get("shares", {}).get("count", 0), "saves": None,
        }
        post["interactions"] = post["likes"] + post["comments"] + post["shares"]
        ttl = 7 * DAY if (date.today() - d).days > 30 else 3 * HOUR
        try:
            ins = c.get(f"{p['id']}/insights", {"metric": FB_POST_METRICS}, token=tok, ttl=ttl)["data"]
            # Meta stuurt sommige metrics dubbel (lifetime + per dag met nullen): neem de lifetime-waarde.
            vals = {}
            for m in ins:
                if m.get("period", "lifetime") == "lifetime" and m["name"] not in vals:
                    vals[m["name"]] = (m.get("values") or [{}])[0].get("value")
        except MetaApiError:
            vals = {}
        post.update({
            "views": _num(vals.get("post_media_view")), "reach": _num(vals.get("post_total_media_view_unique")),
            "clicks": _num(vals.get("post_clicks")),
            "avg_watch_ms": _num(vals.get("post_video_avg_time_watched")) or None,
            "watch_ms": _num(vals.get("post_video_view_time")) or None,
            "retention": vals.get("post_video_retention_graph") or None,
        })
        post["er"] = ratio(post["interactions"], post["reach"])
        return post

    with ThreadPoolExecutor(6) as pool:
        return list(pool.map(build, raw))


def fb_audience(c, page_id):
    tok = c.page_token(page_id)
    y = yesterday()
    out = {}
    for metric, key in (("page_follows_country", "countries"), ("page_follows_city", "cities")):
        try:
            data = c.get(f"{page_id}/insights", {"metric": metric, "period": "day",
                                                 "since": _ts(y - timedelta(days=3)), "until": _ts(y + timedelta(days=1))},
                         token=tok, ttl=DAY)["data"]
            vals = [v["value"] for v in data[0]["values"] if isinstance(v.get("value"), dict) and v["value"]]
            if vals:
                out[key] = sorted(vals[-1].items(), key=lambda x: -x[1])[:10]
        except (MetaApiError, IndexError):
            pass
    return out


# =================== Instagram ===================
def ig_window(c, ig_id, tok, s, u, metrics=IG_TOT):
    """Eén blok van max. 30 dagen, metric_type=total_value. None bij fout."""
    try:
        data = c.get(f"{ig_id}/insights", {
            "metric": ",".join(metrics), "period": "day", "metric_type": "total_value",
            "since": _ts(s), "until": _ts(u + timedelta(days=1)),
        }, token=tok)["data"]
    except MetaApiError:
        return None
    return {m["name"]: _num((m.get("total_value") or {}).get("value", 0)) for m in data}


def ig_totals(c, ig_id, tok, s, u, metrics=IG_TOT):
    tot, ok = {m: 0 for m in metrics}, False
    for cs, cu in chunks(s, u, 30):
        w = ig_window(c, ig_id, tok, cs, cu, metrics)
        if w:
            ok = True
            for k, v in w.items():
                tot[k] = tot.get(k, 0) + v
    return tot if ok else None


IG_FOLLOW_HISTORY = 360  # Meta geeft volgen/ontvolgen ongeveer een jaar terug; daarvoor komt stil 0 terug


def ig_follow_floor():
    return date.today() - timedelta(days=IG_FOLLOW_HISTORY)


def ig_net_follows(c, ig_id, tok, s, u):
    """Netto nieuwe volgers (volgen − ontvolgen) in [s, u]. None als Meta het niet (betrouwbaar) geeft."""
    if s < ig_follow_floor():
        return None
    net = 0
    for cs, cu in chunks(s, u, 30):
        try:
            data = c.get(f"{ig_id}/insights", {
                "metric": "follows_and_unfollows", "period": "day", "metric_type": "total_value",
                "breakdown": "follow_type", "since": _ts(cs), "until": _ts(cu + timedelta(days=1)),
            }, token=tok)["data"]
        except MetaApiError:
            return None
        if not data:  # accounts onder 100 volgers krijgen dit niet van Meta
            return None
        for b in (data[0].get("total_value") or {}).get("breakdowns", []):
            for r in b.get("results", []):
                kind = r["dimension_values"][0]
                net += r["value"] if kind == "FOLLOWER" else -r["value"] if kind == "NON_FOLLOWER" else 0
    return net


def ig_last_post_days(c, ig_id, tok):
    try:
        data = c.get(f"{ig_id}/media", {"fields": "timestamp", "limit": 1}, token=tok, ttl=HOUR)["data"]
    except MetaApiError:
        return None
    return (date.today() - date.fromisoformat(data[0]["timestamp"][:10])).days if data else None


IG_MEDIA_BASE = "reach,views,saved,shares,total_interactions,likes,comments"
IG_MEDIA_REELS = IG_MEDIA_BASE + ",ig_reels_avg_watch_time,ig_reels_video_view_total_time"


def ig_posts(c, ig_id, tok, since, until, cap=300):
    fields = "id,caption,media_type,media_product_type,timestamp,permalink,thumbnail_url,media_url,like_count,comments_count"
    items, params = [], {"fields": fields, "limit": 50}
    data = c.get(f"{ig_id}/media", params, token=tok, ttl=HOUR)
    for _ in range(cap // 50 + 2):
        done = False
        for m in data.get("data", []):
            d = date.fromisoformat(m["timestamp"][:10])
            if d > until:
                continue
            if d < since or len(items) >= cap:
                done = True
                break
            items.append(m)
        cursor = data.get("paging", {}).get("cursors", {}).get("after")
        if done or not data.get("paging", {}).get("next") or not cursor:
            break
        data = c.get(f"{ig_id}/media", {**params, "after": cursor}, token=tok, ttl=HOUR)

    def build(m):
        d = date.fromisoformat(m["timestamp"][:10])
        reel = m.get("media_product_type") == "REELS"
        fmt = "Reel" if reel else {"CAROUSEL_ALBUM": "Carrousel", "IMAGE": "Foto", "VIDEO": "Video"}.get(m["media_type"], "Overig")
        post = {
            "channel": "instagram", "id": m["id"], "date": d.isoformat(), "format": fmt,
            "text": (m.get("caption") or "")[:200], "url": m.get("permalink"),
            "image": m.get("thumbnail_url") or m.get("media_url"),
            "likes": m.get("like_count", 0), "comments": m.get("comments_count", 0),
        }
        ttl = 7 * DAY if (date.today() - d).days > 30 else 3 * HOUR
        try:
            ins = c.get(f"{m['id']}/insights", {"metric": IG_MEDIA_REELS if reel else IG_MEDIA_BASE}, token=tok, ttl=ttl)["data"]
            vals = {}
            for x in ins:
                if x.get("period", "lifetime") == "lifetime" and x["name"] not in vals:
                    vals[x["name"]] = _num((x.get("values") or [{}])[0].get("value"))
        except MetaApiError:
            vals = {}
        post.update({
            "reach": vals.get("reach"), "views": vals.get("views"), "saves": vals.get("saved"),
            "shares": vals.get("shares"), "clicks": None,
            "interactions": vals.get("total_interactions", post["likes"] + post["comments"]),
            "avg_watch_ms": vals.get("ig_reels_avg_watch_time"), "watch_ms": vals.get("ig_reels_video_view_total_time"),
            "retention": None,
        })
        post["er"] = ratio(post["interactions"], post["reach"])
        return post

    with ThreadPoolExecutor(6) as pool:
        return list(pool.map(build, items))


def ig_audience(c, ig_id, tok):
    out = {}

    def demo(breakdown):
        data = c.get(f"{ig_id}/insights", {"metric": "follower_demographics", "period": "lifetime",
                                          "metric_type": "total_value", "breakdown": breakdown}, token=tok, ttl=DAY)["data"]
        res = []
        for b in (data[0].get("total_value") or {}).get("breakdowns", []):
            res.extend((r["dimension_values"], r["value"]) for r in b.get("results", []))
        return res

    try:
        ages = {}
        for (age, gender), v in demo("age,gender"):
            ages.setdefault(age, {"F": 0, "M": 0, "U": 0})[gender] = v
        out["age_gender"] = sorted(ages.items())
        out["cities"] = sorted(((k[0], v) for k, v in demo("city")), key=lambda x: -x[1])[:10]
        out["countries"] = sorted(((k[0], v) for k, v in demo("country")), key=lambda x: -x[1])[:10]
    except (MetaApiError, IndexError, ValueError):
        pass  # minder dan 100 volgers: Meta geeft dan geen demografie
    return out


# =================== Overzicht ===================
def _status(total, last_post_days):
    score, reasons = 0, []
    g = total.get("follower_growth_pct")
    if g is not None:
        if g > GROWTH_UP: score += 1; reasons.append(f"volgers +{g:.1f}%")
        elif g < GROWTH_DOWN: score -= 1; reasons.append(f"volgers {g:.1f}%")
    t = total.get("reach_trend")
    if t is not None:
        if t > TREND_BAND: score += 1; reasons.append(f"bereik +{t:.0f}%")
        elif t < -TREND_BAND: score -= 1; reasons.append(f"bereik {t:.0f}%")
    e = total.get("er_vs_avg")
    if e is not None:
        if e > TREND_BAND: score += 1; reasons.append(f"engagement +{e:.0f}% boven gemiddelde")
        elif e < -TREND_BAND: score -= 1; reasons.append(f"engagement {e:.0f}% onder gemiddelde")
    level = 1 if score >= 1 else -1 if score <= -1 else 0
    known = [d for d in last_post_days if d is not None]
    if known and min(known) > STALE_DAYS:
        level -= 1
        reasons.append(f"{min(known)} dagen niet gepost")
    level = max(-1, min(1, level))
    return {"level": ["daalt", "staat stil", "groeit"][level + 1], "reasons": reasons or ["geen grote veranderingen"]}


def _channel_block(followers_now, net, reach, reach_prev, views, views_prev, inter, er_hist_inter, er_hist_reach, last_post):
    start = followers_now - net if followers_now is not None and net is not None else None
    er = ratio(inter, reach)
    er_avg = ratio(er_hist_inter, er_hist_reach)
    return {
        "followers": followers_now, "follower_net": net, "followers_start": start,
        "follower_growth_pct": pct(followers_now, start) if start else None,
        "reach": reach, "reach_prev": reach_prev, "reach_trend": pct(reach, reach_prev),
        "views": views, "views_prev": views_prev, "views_trend": pct(views, views_prev),
        "interactions": inter, "er": er, "er_avg": er_avg,
        "er_vs_avg": pct(er, er_avg) if er is not None and er_avg else None,
        "hist_inter": er_hist_inter, "hist_reach": er_hist_reach,
        "last_post_days": last_post,
    }


def _since_start(c, acc, settings):
    start = settings.get("start")
    if not start:
        return None
    y = yesterday()
    s = date.fromisoformat(start)
    e = min(date.fromisoformat(settings["end"]), y) if settings.get("end") else y
    s_eff = max(s, date.today() - timedelta(days=HISTORY_DAYS))
    if s_eff > e:
        return None
    res = {"from": s_eff.isoformat(), "until": e.isoformat(), "limited": s_eff > s, "reach": 0, "views": 0}
    daily = fb_daily(c, acc["page_id"], s_eff, e, ["page_media_view", "page_total_media_view_unique"])
    res["reach"] += fb_sum(daily, "page_total_media_view_unique", s_eff, e) or 0
    res["views"] += fb_sum(daily, "page_media_view", s_eff, e) or 0
    # Dit kalenderjaar (binnen de samenwerking)
    jan1 = date(date.today().year, 1, 1)
    y_s = max(s_eff, jan1)
    res["year"] = date.today().year
    res["year_views"] = (fb_sum(daily, "page_media_view", y_s, e) or 0) if y_s <= e else 0
    res["year_reach"] = (fb_sum(daily, "page_total_media_view_unique", y_s, e) or 0) if y_s <= e else 0
    if acc.get("instagram"):
        tok = c.page_token(acc["page_id"])
        tot = ig_totals(c, acc["instagram"]["id"], tok, s_eff, e, ["reach", "views"])
        if tot:
            res["reach"] += tot["reach"]
            res["views"] += tot["views"]
        if y_s <= e:
            ytot = ig_totals(c, acc["instagram"]["id"], tok, y_s, e, ["reach", "views"])
            if ytot:
                res["year_reach"] += ytot["reach"]
                res["year_views"] += ytot["views"]
    return res


def client_overview(c, acc, settings):
    pid = acc["page_id"]
    y = yesterday()
    W, P = (y - timedelta(days=29), y), (y - timedelta(days=59), y - timedelta(days=30))
    H = (y - timedelta(days=209), y - timedelta(days=30))
    row = {"page_id": pid, "name": acc["page_name"], "picture": acc.get("page_picture"),
           "instagram_username": (acc.get("instagram") or {}).get("username"), "settings": settings, "channels": {}}

    # Facebook
    daily = fb_daily(c, pid, H[0], y, ["page_follows", "page_media_view", "page_total_media_view_unique", "page_post_engagements"])
    f_end, f_start = fb_at(daily, "page_follows", y), fb_at(daily, "page_follows", P[1])
    row["channels"]["facebook"] = _channel_block(
        f_end or acc.get("page_followers"), (f_end - f_start) if f_end and f_start else None,
        fb_sum(daily, "page_total_media_view_unique", *W), fb_sum(daily, "page_total_media_view_unique", *P),
        fb_sum(daily, "page_media_view", *W), fb_sum(daily, "page_media_view", *P),
        fb_sum(daily, "page_post_engagements", *W),
        fb_sum(daily, "page_post_engagements", *H), fb_sum(daily, "page_total_media_view_unique", *H),
        fb_last_post_days(c, pid))

    # Instagram
    ig = acc.get("instagram")
    if ig:
        tok = c.page_token(pid)
        w = ig_window(c, ig["id"], tok, *W, ["reach", "views", "total_interactions"]) or {}
        p = ig_window(c, ig["id"], tok, *P, ["reach", "views"]) or {}
        h = ig_totals(c, ig["id"], tok, *H, ["reach", "total_interactions"]) or {}
        row["channels"]["instagram"] = _channel_block(
            ig.get("followers"), ig_net_follows(c, ig["id"], tok, *W),
            w.get("reach"), p.get("reach"), w.get("views"), p.get("views"), w.get("total_interactions"),
            h.get("total_interactions"), h.get("reach"), ig_last_post_days(c, ig["id"], tok))

    # Totaal (FB + IG)
    chs = list(row["channels"].values())
    def s(k):
        vals = [ch[k] for ch in chs if ch.get(k) is not None]
        return sum(vals) if vals else None
    total = _channel_block(s("followers"), s("follower_net"), s("reach"), s("reach_prev"), s("views"), s("views_prev"),
                           s("interactions"), s("hist_inter"), s("hist_reach"), None)
    # Groei alleen over kanalen waarvan begin- én eindstand bekend zijn
    known = [ch for ch in chs if ch.get("followers_start") and ch.get("followers") is not None]
    total["followers_start"] = sum(ch["followers_start"] for ch in known) if known else None
    total["follower_net"] = sum(ch["follower_net"] for ch in known) if known else None
    total["follower_growth_pct"] = pct(sum(ch["followers"] for ch in known), total["followers_start"]) if known else None
    row["total"] = total
    row["since_start"] = _since_start(c, acc, settings)
    row["status"] = _status(total, [ch["last_post_days"] for ch in chs])
    return row


def overview(c):
    accounts = c.list_accounts()
    settings = store.all_settings()

    def one(acc):
        try:
            return client_overview(c, acc, settings.get(acc["page_id"], {"start": None, "end": None}))
        except Exception as e:  # noqa – één klant mag het overzicht niet breken
            return {"page_id": acc["page_id"], "name": acc["page_name"], "error": str(e)}

    with ThreadPoolExecutor(5) as pool:
        rows = list(pool.map(one, accounts))
    return {"generated": date.today().isoformat(), "window": [(yesterday() - timedelta(days=29)).isoformat(), yesterday().isoformat()],
            "clients": rows}


# =================== Resultatenpagina ===================
def _buckets(since, until):
    size = 7 if (until - since).days + 1 <= 120 else 28
    return list(chunks(since, until, size)), size


def _formats(posts):
    groups = {}
    for p in posts:
        groups.setdefault(p["format"], []).append(p)

    def avg(lst, k):
        vals = [x[k] for x in lst if x.get(k) is not None]
        return round(sum(vals) / len(vals), 1) if vals else None
    out = []
    for fmt, lst in groups.items():
        out.append({"format": fmt, "count": len(lst), "reach": avg(lst, "reach"), "views": avg(lst, "views"),
                    "interactions": avg(lst, "interactions"), "saves": avg(lst, "saves"), "shares": avg(lst, "shares"),
                    "er": ratio(sum(x["interactions"] or 0 for x in lst), sum(x["reach"] or 0 for x in lst))})
    return sorted(out, key=lambda x: -(x["reach"] or 0))


RANK_KEYS = ("views", "interactions")


def _top_flop(posts):
    """Top 3 en flop 3, zowel gerangschikt op weergaven als op interacties (schuif in het dashboard)."""
    cutoff = (date.today() - timedelta(days=2)).isoformat()  # te nieuwe posts zijn nog geen flop
    slim = lambda p: {k: v for k, v in p.items() if k != "retention"}
    out = {}
    for key in RANK_KEYS:
        ranked = sorted(posts, key=lambda p: -(p.get(key) or 0))
        top = ranked[:3]
        flop = [p for p in reversed(ranked) if p["date"] <= cutoff and p not in top][:3]
        out[key] = {"top": [slim(p) for p in top], "flop": [slim(p) for p in flop]}
    return out


def _video(posts):
    vids = [p for p in posts if p.get("avg_watch_ms")]
    if not vids:
        return None
    curves = [p["retention"] for p in vids if isinstance(p.get("retention"), dict) and p["retention"]]
    avg_curve = None
    if curves:
        n = min(len(cv) for cv in curves)
        avg_curve = [round(sum(float(cv[str(i)]) for cv in curves if str(i) in cv) / len(curves) * 100, 1) for i in range(n)]
    top = sorted(vids, key=lambda p: -(p.get("views") or 0))[:10]
    return {
        "count": len(vids),
        "avg_watch_s": round(sum(p["avg_watch_ms"] for p in vids) / len(vids) / 1000, 1),
        "total_watch_h": round(sum(p.get("watch_ms") or 0 for p in vids) / 3_600_000, 1),
        "retention_curve": avg_curve,
        "videos": [{"date": p["date"], "text": p["text"][:80], "url": p["url"], "image": p["image"], "format": p["format"],
                    "views": p.get("views"), "reach": p.get("reach"), "avg_watch_s": round(p["avg_watch_ms"] / 1000, 1),
                    "watch_h": round((p.get("watch_ms") or 0) / 3_600_000, 2)} for p in top],
    }


def _post_sums(posts):
    def s(k):
        vals = [p[k] for p in posts if p.get(k) is not None]
        return sum(vals) if vals else None
    return {"posts": len(posts), "likes": s("likes"), "comments": s("comments"), "shares": s("shares"),
            "saves": s("saves"), "clicks": s("clicks")}


def client_results(c, page_id, since, until):
    acc = c.account(page_id)
    settings = store.get_settings(page_id)
    y = yesterday()
    until = min(until, y)
    if settings.get("end"):
        until = min(until, date.fromisoformat(settings["end"]))
    since = max(min(since, until), date.today() - timedelta(days=HISTORY_DAYS))
    n = (until - since).days + 1
    prev = (since - timedelta(days=n), since - timedelta(days=1))
    buckets, bsize = _buckets(since, until)
    res = {"client": {"page_id": page_id, "name": acc["page_name"], "picture": acc.get("page_picture"),
                      "instagram_username": (acc.get("instagram") or {}).get("username")},
           "settings": settings, "period": {"since": since.isoformat(), "until": until.isoformat(), "days": n,
                                            "prev_since": prev[0].isoformat(), "prev_until": prev[1].isoformat()},
           "bucket_days": bsize, "buckets": [s.isoformat() for s, _ in buckets], "channels": {}}

    # ---------- Facebook ----------
    # één dag extra: de volgersstand op de dag vóór de vorige periode is nodig voor de groei
    hist_from = max(prev[0] - timedelta(days=1), date.today() - timedelta(days=HISTORY_DAYS))
    daily = fb_daily(c, page_id, hist_from, until)
    posts = fb_posts(c, page_id, since, until)
    f_end, f_start = fb_at(daily, "page_follows", until), fb_at(daily, "page_follows", since - timedelta(days=1))
    reach, views = fb_sum(daily, "page_total_media_view_unique", since, until), fb_sum(daily, "page_media_view", since, until)
    inter = fb_sum(daily, "page_post_engagements", since, until)
    p_reach, p_views = fb_sum(daily, "page_total_media_view_unique", *prev), fb_sum(daily, "page_media_view", *prev)
    p_inter = fb_sum(daily, "page_post_engagements", *prev)
    p_f_end, p_f_start = fb_at(daily, "page_follows", prev[1]), fb_at(daily, "page_follows", prev[0] - timedelta(days=1))
    sums = _post_sums(posts)
    cta = fb_sum(daily, "page_total_actions", since, until) or 0
    res["channels"]["facebook"] = {
        "kpis": {
            "reach": reach, "views": views, "interactions": inter, "er": ratio(inter, reach),
            "followers": f_end or acc.get("page_followers"),
            "follower_net": (f_end - f_start) if f_end and f_start else None,
            "follower_growth_pct": pct(f_end, f_start) if f_end and f_start else None,
            "likes": sums["likes"], "comments": sums["comments"], "shares": sums["shares"], "saves": None,
            "clicks": (sums["clicks"] or 0) + cta, "posts": sums["posts"],
            "watch_h": round((fb_sum(daily, "page_video_view_time", since, until) or 0) / 3_600_000, 1),
        },
        "prev": {
            "reach": p_reach, "views": p_views, "interactions": p_inter, "er": ratio(p_inter, p_reach),
            "follower_net": (p_f_end - p_f_start) if p_f_end and p_f_start else None,
        },
        "timeline": [{
            "reach": fb_sum(daily, "page_total_media_view_unique", s, u), "views": fb_sum(daily, "page_media_view", s, u),
            "interactions": fb_sum(daily, "page_post_engagements", s, u), "followers": fb_at(daily, "page_follows", u),
        } for s, u in buckets],
        "top_flop": _top_flop(posts), "formats": _formats(posts), "video": _video(posts),
        "post_views": sum(p.get("views") or 0 for p in posts),  # om te zien welk deel van de weergaven de posts dekken
        "audience": fb_audience(c, page_id),
    }

    # ---------- Instagram ----------
    ig = acc.get("instagram")
    if ig:
        tok = c.page_token(page_id)
        tot = ig_totals(c, ig["id"], tok, since, until) or {}
        ptot = ig_totals(c, ig["id"], tok, *prev, ["reach", "views", "total_interactions", "likes", "comments", "shares", "saves", "profile_links_taps"]) \
            if prev[0] >= date.today() - timedelta(days=HISTORY_DAYS) else None
        posts = ig_posts(c, ig["id"], tok, since, until)
        f_since = max(since, ig_follow_floor())  # volgersgroei alleen over de periode waarvoor Meta het geeft
        net = ig_net_follows(c, ig["id"], tok, f_since, until) if f_since <= until else None
        p_net = ig_net_follows(c, ig["id"], tok, *prev) if ptot else None

        def bucket(su):
            s, u = su
            return ig_window(c, ig["id"], tok, s, u, ["reach", "views", "total_interactions"]) or {}, ig_net_follows(c, ig["id"], tok, s, u)
        with ThreadPoolExecutor(6) as pool:
            bdata = list(pool.map(bucket, buckets))
        # Volgers per blok terugrekenen vanaf het huidige aantal
        followers = [None] * len(buckets)
        cur, ok = ig.get("followers"), True
        later_net = ig_net_follows(c, ig["id"], tok, until + timedelta(days=1), y) if until < y else 0
        if cur is not None and later_net is not None:
            cur -= later_net
            for i in range(len(buckets) - 1, -1, -1):
                followers[i] = cur
                if bdata[i][1] is None:
                    break
                cur -= bdata[i][1]
        sums = _post_sums(posts)
        start_f = (ig.get("followers") - (later_net or 0) - net) if net is not None and ig.get("followers") else None
        res["channels"]["instagram"] = {
            "kpis": {
                "reach": tot.get("reach"), "views": tot.get("views"), "interactions": tot.get("total_interactions"),
                "er": ratio(tot.get("total_interactions"), tot.get("reach")),
                "followers": ig.get("followers"), "follower_net": net,
                "follower_from": f_since.isoformat() if f_since > since else None,
                "follower_growth_pct": pct(start_f + net, start_f) if start_f else None,
                "likes": tot.get("likes"), "comments": tot.get("comments"), "shares": tot.get("shares"),
                "saves": tot.get("saves"), "clicks": tot.get("profile_links_taps"), "posts": sums["posts"],
                "watch_h": round(sum(p.get("watch_ms") or 0 for p in posts) / 3_600_000, 1),
            },
            "prev": ptot and {
                "reach": ptot.get("reach"), "views": ptot.get("views"), "interactions": ptot.get("total_interactions"),
                "er": ratio(ptot.get("total_interactions"), ptot.get("reach")), "follower_net": p_net,
                "likes": ptot.get("likes"), "comments": ptot.get("comments"), "shares": ptot.get("shares"),
                "saves": ptot.get("saves"), "clicks": ptot.get("profile_links_taps"),
            },
            "timeline": [{"reach": b[0].get("reach"), "views": b[0].get("views"),
                          "interactions": b[0].get("total_interactions"), "followers": followers[i]}
                         for i, b in enumerate(bdata)],
            "top_flop": _top_flop(posts), "formats": _formats(posts), "video": _video(posts),
        "post_views": sum(p.get("views") or 0 for p in posts),  # om te zien welk deel van de weergaven de posts dekken
            "audience": ig_audience(c, ig["id"], tok),
        }
    return res
