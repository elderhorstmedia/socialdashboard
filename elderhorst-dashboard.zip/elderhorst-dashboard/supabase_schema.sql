-- Elderhorst Media dashboard – Supabase schema
-- Eenmalig uitvoeren: Supabase → SQL Editor → New query → plakken → Run.
-- Veilig om opnieuw te draaien (alles is 'if not exists').

-- Klanten (namen en koppelingen, wordt door het dashboard bijgewerkt)
create table if not exists clients (
  page_id            text primary key,
  name               text not null,
  instagram_id       text,
  instagram_username text,
  updated_at         timestamptz not null default now()
);

-- Instellingen per klant: samenwerking en advertentiedashboard
create table if not exists client_settings (
  page_id       text primary key references clients(page_id) on delete cascade,
  start_date    date,
  end_date      date,
  ads_enabled   boolean not null default false,
  ad_account_id text,
  updated_at    timestamptz not null default now(),
  constraint end_after_start check (end_date is null or start_date is null or end_date >= start_date)
);

-- Dagcijfers per klant en kanaal. Blijft bewaard, ook als Meta het na 1-2 jaar niet meer geeft.
create table if not exists daily_metrics (
  page_id       text not null references clients(page_id) on delete cascade,
  channel       text not null check (channel in ('facebook', 'instagram', 'ads')),
  day           date not null,
  followers     integer,          -- stand aan het eind van de dag
  new_followers integer,          -- nieuwe volgers die dag
  reach         integer,
  views         integer,
  interactions  integer,
  spend         numeric(12, 2),   -- alleen advertenties
  impressions   integer,
  link_clicks   integer,
  results       integer,
  result_type   text,
  updated_at    timestamptz not null default now(),
  primary key (page_id, channel, day)
);
create index if not exists daily_metrics_day on daily_metrics (day);

-- Logboek van de dagelijkse synchronisatie
create table if not exists sync_log (
  id          bigserial primary key,
  started_at  timestamptz not null default now(),
  finished_at timestamptz,
  rows        integer,
  message     text
);

-- Algemene instellingen (bv. verversmomenten)
create table if not exists app_settings (
  key        text primary key,
  value      jsonb not null,
  updated_at timestamptz not null default now()
);

-- Cache van berekende dashboardcijfers (overzicht en resultaten per klant), 2x per dag ververst
create table if not exists computed_cache (
  key        text primary key,
  page_id    text,
  body       jsonb not null,
  updated_at timestamptz not null default now()
);
create index if not exists computed_cache_page on computed_cache (page_id);

-- Bekende accounts, om nieuwe pagina's en advertentieaccounts te herkennen
create table if not exists known_accounts (
  id         text primary key,      -- page_id of act_...
  kind       text not null check (kind in ('page', 'ad_account')),
  name       text,
  first_seen timestamptz not null default now()
);

-- Beveiliging: Row Level Security aan en géén policies.
-- Alleen de service-sleutel van het dashboard kan lezen en schrijven; de publieke (anon) sleutel kan niets.
alter table clients         enable row level security;
alter table client_settings enable row level security;
alter table daily_metrics   enable row level security;
alter table sync_log        enable row level security;
alter table app_settings    enable row level security;
alter table computed_cache  enable row level security;
alter table known_accounts  enable row level security;
