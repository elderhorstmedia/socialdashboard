/* Elderhorst Media – resultatendashboard */
const BRAND = { navy: "#000030", mint: "#36E092", navy70: "#26264F", navy40: "#75759A", navy15: "#D5D5E2", navy06: "#EEEEF4", green: "#17A566" };
const CH = { instagram: { name: "Instagram", short: "IG", color: BRAND.navy }, facebook: { name: "Facebook", short: "FB", color: BRAND.mint } };
Chart.defaults.font.family = "Montserrat, system-ui, sans-serif";
Chart.defaults.font.size = 12;
Chart.defaults.color = BRAND.navy70;

/* ---------- helpers ---------- */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const fmt = n => n == null ? "–" : Math.round(n).toLocaleString("nl-NL");
const fmt1 = n => n == null ? "–" : n.toLocaleString("nl-NL", { maximumFractionDigits: 1 });
const fmtPct = (n, d = 1) => n == null ? "–" : n.toLocaleString("nl-NL", { minimumFractionDigits: d, maximumFractionDigits: d }) + "%";
const signed = (n, d = 1) => n == null ? "–" : (n > 0 ? "+" : "") + fmtPct(n, d);
const dmy = iso => iso ? iso.split("-").reverse().join("-") : "–";
const dm = iso => { const [, m, d] = iso.split("-"); return `${+d}-${+m}`; };
const isoDate = d => d.toISOString().slice(0, 10);
const addDays = (iso, n) => { const d = new Date(iso + "T12:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return isoDate(d); };
const yesterday = () => { const d = new Date(); d.setDate(d.getDate() - 1); return d.toLocaleDateString("sv-SE"); };
const pctChange = (a, b) => (a == null || !b) ? null : (a - b) / b * 100;
const region = (() => { try { return new Intl.DisplayNames(["nl"], { type: "region" }); } catch { return null; } })();
const countryName = c => (region && /^[A-Z]{2}$/.test(c) ? region.of(c) : c);

function trend(v, { band = 5, suffix = "" } = {}) {
  if (v == null || !isFinite(v)) return `<span class="tr flat">–</span>`;
  const cls = v > band ? "up" : v < -band ? "down" : "flat";
  const arrow = cls === "up" ? "▲" : cls === "down" ? "▼" : "▬";
  return `<span class="tr ${cls}" title="t.o.v. vorige periode">${arrow} ${signed(v, 0)}${suffix}</span>`;
}
const LEVEL = { "groeit": "groeit", "staat stil": "stil", "daalt": "daalt" };
const light = level => `<span class="light ${LEVEL[level] || ""}" aria-hidden="true"><i></i><i></i><i></i></span>`;
function ageCell(days) {
  if (days == null) return `<span class="muted">–</span>`;
  const cls = days > 14 ? "bad" : days > 7 ? "warn" : "";
  return `<span class="age ${cls}">${days === 0 ? "vandaag" : days === 1 ? "1 dag" : days + " dagen"}</span>`;
}
/* ---------- inloggen (Supabase Auth; alleen als de server dat vraagt) ---------- */
let config = { auth: false, pdf: true, online: false };
let sbAuth = null;
async function authHeader() {
  if (!sbAuth) return {};
  const { data } = await sbAuth.auth.getSession();   // ververst het token zelf als het bijna verloopt
  return data.session ? { Authorization: `Bearer ${data.session.access_token}` } : {};
}
async function authFetch(url, opts = {}) {
  const r = await fetch(url, { ...opts, headers: { ...(opts.headers || {}), ...(await authHeader()) } });
  if (r.status === 401) {
    const j = await r.clone().json().catch(() => ({}));
    if (j.login) showLogin(j.error);
  }
  return r;
}
async function api(url, opts) {
  const r = await authFetch(url, opts);
  const j = await r.json().catch(() => ({ error: r.statusText }));
  if (!r.ok) throw new Error(j.error || r.statusText);
  return j;
}

function showLogin(message, mode = "login") {
  document.querySelector(".layout").hidden = true;
  const box = $("#login");
  box.hidden = false;
  const pw = mode === "password";
  box.innerHTML = `<form class="login-card" id="login-form">
      <img src="/logo/logo-white.svg" alt="Elderhorst Media" class="login-logo">
      <div class="label light">${pw ? "Kies een wachtwoord" : "Dashboard"}</div>
      <h1>${pw ? "Nieuw wachtwoord" : "Inloggen"}</h1>
      ${pw ? "" : `<label>E-mailadres<input type="email" id="lg-email" autocomplete="username" required></label>`}
      <label>${pw ? "Nieuw wachtwoord (minstens 8 tekens)" : "Wachtwoord"}<input type="password" id="lg-pass" minlength="${pw ? 8 : 1}"
        autocomplete="${pw ? "new-password" : "current-password"}" required></label>
      <button class="btn primary" type="submit">${pw ? "Opslaan en verder" : "Inloggen"}</button>
      ${pw ? "" : `<a href="#" id="lg-forgot" class="small">Wachtwoord vergeten?</a>`}
      <p class="login-note small" id="lg-note">${esc(message || "")}</p>
    </form>`;
  const note = $("#lg-note");
  $("#login-form").onsubmit = async e => {
    e.preventDefault();
    note.textContent = "Bezig…";
    const res = pw ? await sbAuth.auth.updateUser({ password: $("#lg-pass").value })
                   : await sbAuth.auth.signInWithPassword({ email: $("#lg-email").value.trim(), password: $("#lg-pass").value });
    if (res.error) { note.textContent = res.error.message === "Invalid login credentials" ? "E-mailadres of wachtwoord klopt niet." : res.error.message; return; }
    location.replace(location.pathname + "#/");
    location.reload();
  };
  if (!pw) $("#lg-forgot").onclick = async e => {
    e.preventDefault();
    const email = $("#lg-email").value.trim();
    if (!email) { note.textContent = "Vul eerst je e-mailadres in."; return; }
    const { error } = await sbAuth.auth.resetPasswordForEmail(email, { redirectTo: location.origin + "/" });
    note.textContent = error ? error.message : "Als dit adres bekend is, staat er een mail met een link in je inbox.";
  };
  (pw ? $("#lg-pass") : $("#lg-email")).focus();
}
const charts = [];
function chart(el, cfg) { const c = new Chart(el, cfg); charts.push(c); return c; }
function clearCharts() { while (charts.length) charts.pop().destroy(); }
const avatar = (src, cls = "avatar") => src
  ? `<img class="${cls}" src="${esc(src)}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'${cls}'}))">`
  : `<span class="${cls}"></span>`;

/* ---------- state ---------- */
let accounts = [];
let adsSettings = {};          // page_id -> {enabled, ad_account_id}
const overviewRows = {};      // page_id -> overzichtsdata
let overviewLoading = null;
const ui = { channel: "total", sort: "status", sortDir: 1, rank: "views" };
try { const r = localStorage.getItem("em-rank"); if (r === "views" || r === "interactions") ui.rank = r; } catch {}

/* ---------- zijbalk ---------- */
function renderSidebar(activeId) {
  const onSettings = location.hash.startsWith("#/instellingen");
  $("#nav-overview").classList.toggle("active", !activeId && !onSettings);
  $("#nav-settings").classList.toggle("active", onSettings);
  $("#clients").innerHTML = accounts.map(a => {
    const row = overviewRows[a.page_id];
    const lvl = row?.status?.level;
    return `<a class="client ${a.page_id === activeId ? "active" : ""}" href="#/klant/${a.page_id}">
      ${avatar(a.page_picture || a.instagram?.picture)}
      <div><span class="name">${esc(a.page_name)}</span>${adsSettings[a.page_id]?.enabled ? ` <span class="ads-chip" title="Live advertentiedashboard staat aan">Ads</span>` : ""}
      <small>${lvl ? `<span class="dot ${LEVEL[lvl]}"></span>${lvl}` : (a.instagram ? "Facebook + Instagram" : "Alleen Facebook")}</small></div></a>`;
  }).join("");
}

/* ---------- router ---------- */
async function route() {
  clearCharts();
  window.scrollTo(0, 0);
  clearInterval(adsTimer); clearInterval(syncTimer);
  if (location.hash.startsWith("#/instellingen")) { renderSidebar(null); return showSettings(); }
  const a = location.hash.match(/^#\/klant\/(\d+)\/advertenties/);
  if (a) { renderSidebar(a[1]); return showAds(a[1]); }
  const m = location.hash.match(/^#\/klant\/(\d+)/);
  if (m) { renderSidebar(m[1]); return showClient(m[1]); }
  renderSidebar(null);
  showOverview();
}

/* ======================= OVERZICHT ======================= */
function loadOverview(force) {
  if (overviewLoading && !force) return overviewLoading;
  const queue = accounts.filter(a => force || !overviewRows[a.page_id]);
  const worker = async () => {
    while (queue.length) {
      const a = queue.shift();
      try { overviewRows[a.page_id] = await api(`/api/client/${a.page_id}/overview`); }
      catch (e) { overviewRows[a.page_id] = { page_id: a.page_id, name: a.page_name, error: e.message }; }
      if (!location.hash.startsWith("#/klant")) { renderOverviewBody(); renderSidebar(null); }
      else renderSidebar(location.hash.split("/")[2]);
    }
  };
  overviewLoading = Promise.all([1, 2, 3, 4].map(worker)).then(() => { overviewLoading = null; });
  return overviewLoading;
}

function showOverview() {
  const until = yesterday(), since = addDays(until, -29);
  $("#view").innerHTML = `
    <div class="page-head">
      <div><div class="label">Overzicht · laatste 30 dagen (${dmy(since)} – ${dmy(until)})</div><h1>Alle klanten</h1></div>
      <div class="controls">
        <div class="seg" id="ch-seg">
          <button data-ch="total">Totaal</button><button data-ch="instagram">Instagram</button><button data-ch="facebook">Facebook</button>
        </div>
        <button class="btn" id="refresh" title="Recente cijfers opnieuw ophalen bij Meta">Vernieuwen</button>
      </div>
    </div>
    <div id="ov-body"></div>
    <div class="foot">
      <b>Zo lees je het.</b> Alle cijfers gaan over de laatste 30 dagen; de pijltjes vergelijken met de 30 dagen daarvoor.
      <b>Engagement rate</b> = interacties ÷ bereik, afgezet tegen het eigen gemiddelde van de klant over de 6 maanden daarvoor.
      <b>Stoplicht</b>: elk signaal telt mee – volgersgroei (boven 1% telt positief, onder 0% negatief), bereik en engagement (meer dan 10% hoger of lager).
      Opgeteld positief = groeit, negatief = daalt, anders staat stil. Meer dan 14 dagen niet gepost zet de klant een stap lager.
      <b>Sinds start</b> telt bereik en weergaven op vanaf de startdatum van de samenwerking (Meta bewaart maximaal ongeveer 2 jaar).
      Bereik is daarbij een optelsom per dag (Facebook) of per blok van 30 dagen (Instagram), geen aantal unieke mensen.
    </div>`;
  document.querySelectorAll("#ch-seg button").forEach(b => {
    b.classList.toggle("active", b.dataset.ch === ui.channel);
    b.onclick = () => { ui.channel = b.dataset.ch; document.querySelectorAll("#ch-seg button").forEach(x => x.classList.toggle("active", x === b)); renderOverviewBody(); };
  });
  $("#refresh").onclick = async () => {
    $("#refresh").textContent = "Bezig…";
    await api("/api/refresh");
    accounts.forEach(a => delete overviewRows[a.page_id]);
    renderOverviewBody();
    await loadOverview(true);
    $("#refresh") && ($("#refresh").textContent = "Vernieuwen");
  };
  renderOverviewBody();
  loadOverview();
}

const SORTS = {
  name: r => r.name.toLowerCase(),
  status: r => ({ "daalt": 0, "staat stil": 1, "groeit": 2 }[r.status?.level] ?? 3),
  growth: r => val(r, "follower_growth_pct"),
  er: r => val(r, "er_vs_avg"),
  reach: r => val(r, "reach_trend"),
  views: r => val(r, "views_trend"),
  start: r => r.since_start?.reach,
  post: r => Math.min(...Object.values(r.channels || {}).map(c => c.last_post_days ?? 999)),
};
function chData(r) { return ui.channel === "total" ? r.total : r.channels?.[ui.channel]; }
function val(r, k) { return chData(r)?.[k]; }

function renderOverviewBody() {
  const body = $("#ov-body"); if (!body) return;
  const rows = accounts.map(a => overviewRows[a.page_id] || { page_id: a.page_id, name: a.page_name, picture: a.page_picture, loading: true });
  const done = rows.filter(r => !r.loading).length;
  const count = lvl => rows.filter(r => r.status?.level === lvl).length;

  const key = SORTS[ui.sort];
  const sorted = [...rows].sort((a, b) => {
    if (a.loading !== b.loading) return a.loading ? 1 : -1;
    const va = key(a), vb = key(b);
    if (va == null && vb == null) return 0; if (va == null) return 1; if (vb == null) return -1;
    return (va > vb ? 1 : va < vb ? -1 : 0) * ui.sortDir;
  });
  // Teller: alle weergaven sinds de start van elke samenwerking
  const withStart = rows.filter(r => r.since_start);
  const totViews = withStart.reduce((a, r) => a + (r.since_start.views || 0), 0);
  const totReach = withStart.reduce((a, r) => a + (r.since_start.reach || 0), 0);
  const noStart = rows.filter(r => !r.loading && !r.error && !r.settings?.start).length;
  const year = new Date().getFullYear();
  const yearViews = withStart.reduce((a, r) => a + (r.since_start.year_views || 0), 0);
  const yearReach = withStart.reduce((a, r) => a + (r.since_start.year_reach || 0), 0);
  const yearClients = withStart.filter(r => (r.since_start.year_views || 0) > 0).length;
  const plural = n => `${n} ${n === 1 ? "klant" : "klanten"}`;
  const counter = `<div class="counters">
      <div class="counter">
        <div><div class="label light">All-time weergaven · tijdens onze samenwerkingen</div>
          <div class="counter-num">${fmt(totViews)}</div>
          <div class="counter-sub">${fmt(totReach)} keer bereikt · ${plural(withStart.length)} met een startdatum</div></div>
        <img src="/logo/mark-green.svg" alt=""></div>
      <div class="counter light">
        <div><div class="label">Weergaven in ${year} · tijdens onze samenwerkingen</div>
          <div class="counter-num">${fmt(yearViews)}</div>
          <div class="counter-sub">${fmt(yearReach)} keer bereikt · ${plural(yearClients)} actief dit jaar</div></div></div>
    </div>
    ${noStart ? `<p class="muted small" style="margin:-8px 0 20px">${plural(noStart)} zonder startdatum ${noStart === 1 ? "telt" : "tellen"} nog niet mee in deze tellers. Stel de startdatum in op de pagina van de klant.</p>` : ""}`;

  const th = (k, label, cls = "") => `<th class="sortable ${cls} ${ui.sort === k ? "sorted" : ""}" data-sort="${k}">${label}${ui.sort === k ? (ui.sortDir > 0 ? " ↑" : " ↓") : ""}</th>`;

  body.innerHTML = `
    ${done < rows.length ? `<div class="loading-bar"><i style="width:${Math.round(done / rows.length * 100)}%"></i></div>
      <p class="muted small">Cijfers ophalen bij Meta: ${done} van ${rows.length} klanten. De eerste keer duurt dit even; daarna komt het uit de cache.</p>` : ""}
    ${counter}
    <div class="summary">
      <div>${light("groeit")}<span class="num">${count("groeit")}</span><span class="label">Groeit</span></div>
      <div>${light("staat stil")}<span class="num">${count("staat stil")}</span><span class="label">Staat stil</span></div>
      <div>${light("daalt")}<span class="num">${count("daalt")}</span><span class="label">Daalt</span></div>
    </div>
    <div class="panel"><div class="table-wrap"><table>
      <thead><tr>
        ${th("name", "Klant")}${th("status", "Status")}${th("growth", "Volgersgroei<br>30 dagen", "n")}
        ${th("er", "Engagement<br>vs. eigen gemiddelde", "n")}${th("reach", "Bereik<br>30 dagen", "n")}${th("views", "Weergaven<br>30 dagen", "n")}
        ${th("start", "Sinds start<br>bereik · weergaven", "n")}${th("post", "Laatste post<br>Instagram · Facebook", "n")}
      </tr></thead>
      <tbody>${sorted.map(overviewRow).join("")}</tbody>
    </table></div></div>`;
  body.querySelectorAll("th.sortable").forEach(h => h.onclick = () => {
    ui.sortDir = ui.sort === h.dataset.sort ? -ui.sortDir : (h.dataset.sort === "name" || h.dataset.sort === "status" ? 1 : -1);
    ui.sort = h.dataset.sort; renderOverviewBody();
  });
  body.querySelectorAll("tr[data-id]").forEach(tr => tr.onclick = e => { if (!e.target.closest("a")) location.hash = `#/klant/${tr.dataset.id}`; });
}

function overviewRow(r) {
  const head = `<td><div class="client-cell">${avatar(r.picture)}<div><div class="name">${esc(r.name)}</div>
    <div class="cell-sub">${r.settings?.start ? `klant sinds ${dmy(r.settings.start)}${r.settings.end ? ` · tot ${dmy(r.settings.end)}` : ""}` : r.loading ? "" : `<a href="#/klant/${r.page_id}">startdatum instellen</a>`}</div></div></div></td>`;
  if (r.loading) return `<tr>${head}<td colspan="7" class="skeleton">laden…</td></tr>`;
  if (r.error) return `<tr data-id="${r.page_id}" class="link">${head}<td colspan="7" class="small">Kon niet laden: ${esc(r.error)}</td></tr>`;
  const d = chData(r);
  if (!d) return `<tr data-id="${r.page_id}" class="link">${head}<td>${statusCell(r)}</td><td colspan="5" class="muted small">Geen ${CH[ui.channel].name} gekoppeld</td><td class="n">${postCell(r)}</td></tr>`;
  const st = r.since_start;
  return `<tr data-id="${r.page_id}" class="link">${head}
    <td>${statusCell(r)}</td>
    <td class="n"><div class="big">${d.follower_growth_pct == null ? "–" : signed(d.follower_growth_pct)}</div>
      <div class="cell-sub">${d.follower_net == null ? "" : (d.follower_net >= 0 ? "+" : "") + fmt(d.follower_net) + " · "}${fmt(d.followers)} volgers</div></td>
    <td class="n"><div class="big">${fmtPct(d.er, 1)}</div><div class="cell-sub">${trend(d.er_vs_avg, { band: 10 })} <span class="muted">gem. ${fmtPct(d.er_avg, 1)}</span></div></td>
    <td class="n"><div class="big">${fmt(d.reach)}</div><div class="cell-sub">${trend(d.reach_trend, { band: 10 })}</div></td>
    <td class="n"><div class="big">${fmt(d.views)}</div><div class="cell-sub">${trend(d.views_trend, { band: 10 })}</div></td>
    <td class="n">${st ? `<div class="big">${fmt(st.reach)}</div><div class="cell-sub">${fmt(st.views)} weergaven${st.limited ? ` · vanaf ${dmy(st.from)}` : ""}</div>` : `<span class="muted small">geen startdatum</span>`}</td>
    <td class="n">${postCell(r)}</td></tr>`;
}
const statusCell = r => `<div class="status">${light(r.status.level)} ${r.status.level}</div><div class="status-reasons">${esc(r.status.reasons.join(" · "))}</div>`;
const postCell = r => `<div class="nowrap">${r.channels?.instagram ? ageCell(r.channels.instagram.last_post_days) : `<span class="muted">–</span>`}
  <span class="muted"> · </span>${ageCell(r.channels?.facebook?.last_post_days)}</div>`;

/* ======================= KLANT: RESULTATEN ======================= */
const clientUi = {}; // page_id -> {preset, since, until, ch, metric}

async function showClient(pid) {
  const acc = accounts.find(a => a.page_id === pid);
  if (!acc) { $("#view").innerHTML = `<div class="empty">Klant niet gevonden.</div>`; return; }
  const st = clientUi[pid] ||= { preset: null, ch: acc.instagram ? "instagram" : "facebook", metric: "reach" };
  const settings = overviewRows[pid]?.settings || await api(`/api/client/${pid}/overview`).then(r => (overviewRows[pid] = r).settings).catch(() => ({}));
  if (!st.preset) st.preset = settings.start ? "collab" : "30";
  const range = periodRange(st, settings);

  $("#view").innerHTML = `
    <a class="back label" href="#/">← Overzicht</a>
    <div class="page-head">
      <div><div class="label" id="eyebrow">Resultaten · ${dmy(range.since)} – ${dmy(range.until)}</div>
        <h1>${esc(acc.page_name)}</h1></div>
      <div class="head-right">${overviewRows[pid]?.status ? `<div class="status">${light(overviewRows[pid].status.level)} ${overviewRows[pid].status.level} <span class="muted small" style="font-weight:400">(laatste 30 dagen)</span></div>` : ""}
        <button class="btn primary" id="export-open">Exporteren</button></div>
    </div>

    <div class="panel"><div class="panel-head"><span class="label">Samenwerking</span></div>
      <div class="panel-body collab">
        <label><span class="label">Start samenwerking</span><input type="date" id="c-start" value="${settings.start || ""}" max="${yesterday()}"></label>
        <label><span class="label">Einde samenwerking</span><input type="date" id="c-end" value="${settings.end || ""}"></label>
        <button class="btn primary" id="c-save">Opslaan</button>
        <span class="note" id="c-note">${collabNote(settings)}</span>
      </div></div>

    ${adsPanel(pid)}

    <div class="controls" style="margin:28px 0 8px">
      <div class="seg" id="p-seg">
        <button data-p="collab" ${settings.start ? "" : "disabled title='Stel eerst een startdatum in'"}>Samenwerking</button>
        <button data-p="30">30 dagen</button><button data-p="90">90 dagen</button><button data-p="365">12 maanden</button><button data-p="custom">Aangepast</button>
      </div>
      <span id="p-custom" style="display:${st.preset === "custom" ? "inline-flex" : "none"};gap:8px;align-items:center">
        <input type="date" id="p-since" value="${range.since}"> <span>tot</span> <input type="date" id="p-until" value="${range.until}" max="${yesterday()}">
        <button class="btn" id="p-apply">Toepassen</button></span>
    </div>
    <div id="results"><div class="loading-bar"><i style="width:35%"></i></div><p class="muted">Resultaten ophalen bij Meta… Bij een lange periode duurt dit de eerste keer tot een minuut; daarna komt het uit de cache.</p></div>`;

  document.querySelectorAll("#p-seg button").forEach(b => {
    b.classList.toggle("active", b.dataset.p === st.preset);
    b.onclick = () => { if (b.disabled) return; st.preset = b.dataset.p; if (st.preset !== "custom") { delete st.since; delete st.until; } showClient(pid); };
  });
  $("#p-apply").onclick = () => { st.since = $("#p-since").value; st.until = $("#p-until").value; showClient(pid); };
  $("#export-open").onclick = () => openExport(pid, acc, settings);
  bindAdsPanel(pid, acc);
  $("#c-save").onclick = async () => {
    const note = $("#c-note");
    try {
      const saved = await api(`/api/client/${pid}/settings`, { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ start: $("#c-start").value, end: $("#c-end").value }) });
      note.textContent = "Opgeslagen. " + collabNote(saved);
      if (saved.start && !settings.start) st.preset = "collab";
      if (!saved.start && st.preset === "collab") st.preset = "30";
      overviewRows[pid] = { ...(overviewRows[pid] || {}), settings: saved };
      // Overzichtsrij (met 'sinds start') op de achtergrond opnieuw berekenen
      api(`/api/client/${pid}/overview`).then(r => { overviewRows[pid] = r; renderSidebar(location.hash.split("/")[2] || null); }).catch(() => {});
      setTimeout(() => showClient(pid), 400);
    } catch (e) { note.textContent = e.message; }
  };

  try {
    const data = await api(`/api/client/${pid}/results?since=${range.since}&until=${range.until}`);
    if (location.hash !== `#/klant/${pid}`) return;
    $("#eyebrow").textContent = `Resultaten · ${dmy(data.period.since)} – ${dmy(data.period.until)} · ${data.period.days} dagen`;
    renderResults(pid, data);
  } catch (e) {
    $("#results").innerHTML = `<div class="warn-box">Kon de resultaten niet ophalen: ${esc(e.message)}</div>`;
  }
}

const MONTHS = ["januari", "februari", "maart", "april", "mei", "juni", "juli", "augustus", "september", "oktober", "november", "december"];
function lastMonthName() { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - 1); const m = MONTHS[d.getMonth()]; return m[0].toUpperCase() + m.slice(1) + " " + d.getFullYear(); }
function updateRankNote() {}

/* ---------- Export-pop-up ---------- */
const EXPORT_SECTIONS = [
  ["samenvatting", "Samenvatting", "Kerncijfers en 'In het kort'"],
  ["voor_na", "Voor en na Elderhorst Media", "Gemiddeld per 30 dagen vóór vs. tijdens de samenwerking"],
  ["kanalen", "Cijfers per kanaal", "Bereik, weergaven, interacties, volgers per kanaal"],
  ["ontwikkeling", "Ontwikkeling", "Grafieken bereik en nieuwe volgers"],
  ["posts", "Best presterende posts", "Top 3 per kanaal met thumbnail"],
  ["formaat", "Wat werkt het best", "Performance per formaat"],
  ["video", "Video", "Kijktijd en retentie"],
  ["publiek", "Publiek", "Leeftijd en plaatsen"],
  ["kansen", "Kansen en volgende stap", "Aandachtspunten en afsluiter"],
];
function loadExportPrefs() {
  const def = { period: "maand", sections: EXPORT_SECTIONS.map(s => s[0]), channels: ["instagram", "facebook"] };
  try { return { ...def, ...JSON.parse(localStorage.getItem("em-export") || "{}") }; } catch { return def; }
}
function saveExportPrefs(p) { try { localStorage.setItem("em-export", JSON.stringify(p)); } catch {} }

function openExport(pid, acc, settings) {
  const prefs = loadExportPrefs();
  if (prefs.period === "start" && !settings.start) prefs.period = "maand";
  const chans = [["instagram", "Instagram", !!acc.instagram], ["facebook", "Facebook", true]];
  const periods = [["maand", lastMonthName()], ["30", "Laatste 30 dagen"], ["60", "Laatste 60 dagen"], ["start", "Sinds start samenwerking"]];
  const box = document.createElement("div");
  box.className = "modal-backdrop";
  box.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="ex-title">
      <div class="modal-head"><div><div class="label">Rapport voor de klant · PDF</div><h3 id="ex-title">${esc(acc.page_name)} exporteren</h3></div>
        <button class="modal-close" aria-label="Sluiten">×</button></div>
      <div class="modal-body">
        <div class="ex-group"><div class="label">Periode</div>
          <div class="seg" id="ex-period">${periods.map(([k, l]) => `<button data-p="${k}" ${k === "start" && !settings.start ? "disabled title='Stel eerst een startdatum in'" : ""}>${l}</button>`).join("")}</div>
          ${settings.start ? "" : `<div class="small muted" style="margin-top:6px">Sinds start is beschikbaar zodra je een startdatum invult.</div>`}</div>
        <div class="ex-group"><div class="label">Kanalen</div>
          <div class="checks">${chans.map(([k, l, ok]) => `<label class="check ${ok ? "" : "off"}"><input type="checkbox" name="ch" value="${k}" ${ok && prefs.channels.includes(k) ? "checked" : ""} ${ok ? "" : "disabled"}><span class="box"></span>${l}${ok ? "" : " <span class='muted small'>(niet gekoppeld)</span>"}</label>`).join("")}</div></div>
        <div class="ex-group"><div class="label" style="display:flex;justify-content:space-between">Onderdelen <a href="#" id="ex-all" class="small" style="text-transform:none;letter-spacing:0">Alles aan / uit</a></div>
          <div class="checks grid">${EXPORT_SECTIONS.map(([k, l, d]) => `<label class="check"><input type="checkbox" name="sec" value="${k}" ${prefs.sections.includes(k) ? "checked" : ""}><span class="box"></span><span><b>${l}</b><br><span class="muted small">${d}</span></span></label>`).join("")}</div></div>
        <div class="ex-group"><div class="label">Best presterende posts gerangschikt op</div>
          <label class="switch"><span class="sw-opt" data-side="interactions">Interacties</span>
            <input type="checkbox" id="ex-rank" ${ui.rank === "views" ? "checked" : ""}><span class="sw-track"><span class="sw-knob"></span></span>
            <span class="sw-opt" data-side="views">Weergaven</span></label></div>
      </div>
      <div class="modal-foot"><span class="small muted" id="ex-note"></span>
        <div class="controls"><button class="btn" id="ex-cancel">Annuleren</button><button class="btn primary" id="ex-go">${config.pdf ? "PDF downloaden" : "PDF maken"}</button></div></div>
    </div>`;
  document.body.appendChild(box);
  const q = s => box.querySelector(s), qa = s => [...box.querySelectorAll(s)];
  const close = () => { box.remove(); document.removeEventListener("keydown", onKey); };
  const onKey = e => { if (e.key === "Escape") close(); };
  document.addEventListener("keydown", onKey);
  box.onclick = e => { if (e.target === box) close(); };
  q(".modal-close").onclick = close; q("#ex-cancel").onclick = close;

  let period = prefs.period;
  const paintPeriod = () => qa("#ex-period button").forEach(b => b.classList.toggle("active", b.dataset.p === period));
  qa("#ex-period button").forEach(b => b.onclick = () => { if (!b.disabled) { period = b.dataset.p; paintPeriod(); } });
  paintPeriod();
  const paintRank = () => qa(".sw-opt").forEach(o => o.classList.toggle("on", o.dataset.side === (q("#ex-rank").checked ? "views" : "interactions")));
  q("#ex-rank").onchange = paintRank;
  qa(".sw-opt").forEach(o => o.onclick = ev => { ev.preventDefault(); q("#ex-rank").checked = o.dataset.side === "views"; paintRank(); });
  paintRank();
  q("#ex-all").onclick = e => { e.preventDefault(); const boxes = qa("input[name=sec]"); const on = boxes.some(b => !b.checked); boxes.forEach(b => b.checked = on); };

  q("#ex-go").onclick = async () => {
    const sections = qa("input[name=sec]:checked").map(b => b.value);
    const channels = qa("input[name=ch]:checked").map(b => b.value);
    const rank = q("#ex-rank").checked ? "views" : "interactions";
    const note = q("#ex-note");
    if (!sections.length) { note.textContent = "Kies minstens één onderdeel."; return; }
    if (!channels.length) { note.textContent = "Kies minstens één kanaal."; return; }
    saveExportPrefs({ period, sections, channels });
    ui.rank = rank; try { localStorage.setItem("em-rank", rank); } catch {}
    const go = q("#ex-go"); go.disabled = true; go.textContent = "Rapport maken…";
    note.textContent = "Dit duurt 5 tot 60 seconden.";
    const params = `period=${period}&rank=${rank}&sections=${sections.join(",")}&channels=${channels.join(",")}`;
    if (!config.pdf) return printReport(pid, params, go, note);
    try {
      const r = await authFetch(`/api/client/${pid}/report.pdf?${params}`);
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
      const name = (r.headers.get("Content-Disposition") || "").match(/filename="(.+)"/)?.[1] || "rapport.pdf";
      const url = URL.createObjectURL(await r.blob());
      Object.assign(document.createElement("a"), { href: url, download: name }).click();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      note.textContent = `Gedownload: ${name}`;
      go.textContent = "Nog een keer";
    } catch (e) { note.textContent = "Kon het rapport niet maken: " + e.message; go.textContent = "PDF downloaden"; }
    go.disabled = false;
  };
  q("#ex-go").focus();
}

/* Online is er geen Chrome op de server: het rapport opent in een nieuw tabblad en de browser maakt de PDF. */
async function printReport(pid, params, go, note) {
  const w = window.open("", "_blank");      // meteen openen, anders blokkeert de browser het venster
  if (!w) { note.textContent = "De browser blokkeerde het nieuwe tabblad. Sta pop-ups toe voor dit dashboard."; go.disabled = false; go.textContent = "PDF maken"; return; }
  w.document.write(`<p style="font:16px sans-serif;padding:40px;color:#000030">Rapport maken… dit duurt 5 tot 60 seconden.</p>`);
  try {
    const r = await authFetch(`/api/client/${pid}/report.html?${params}`);
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || r.statusText);
    const name = ((r.headers.get("Content-Disposition") || "").match(/filename="(.+)"/)?.[1] || "rapport.pdf").replace(/\.pdf$/, "");
    const html = await r.text();
    w.document.open(); w.document.write(html); w.document.close();
    w.document.title = name;                // wordt de standaard bestandsnaam bij 'Opslaan als PDF'
    await w.document.fonts.ready.catch(() => {});
    await Promise.all([...w.document.images].map(img => img.complete ? 0 : new Promise(res => { img.onload = img.onerror = res; })));
    setTimeout(() => w.print(), 300);
    note.innerHTML = "Het rapport staat in een nieuw tabblad. Kies bij <b>Bestemming</b> 'Opslaan als PDF' en zet <b>Kop- en voetteksten</b> uit.";
    go.textContent = "Nog een keer";
  } catch (e) { w.close(); note.textContent = "Kon het rapport niet maken: " + e.message; go.textContent = "PDF maken"; }
  go.disabled = false;
}

function periodRange(st, settings) {
  const y = yesterday();
  if (st.preset === "collab" && settings.start) {
    const end = settings.end && settings.end < y ? settings.end : y;
    return { since: settings.start, until: end };
  }
  if (st.preset === "custom" && st.since && st.until) return { since: st.since, until: st.until };
  const days = { "30": 30, "90": 90, "365": 365 }[st.preset] || 30;
  return { since: addDays(y, -(days - 1)), until: y };
}
function collabNote(s) {
  if (!s?.start) return "Nog geen startdatum. Met een startdatum zie je de resultaten sinds de start van de samenwerking.";
  const end = s.end || yesterday();
  const months = Math.max(0, Math.round((new Date(end) - new Date(s.start)) / 2.63e9));
  return `Looptijd ${months} ${months === 1 ? "maand" : "maanden"}${s.end ? "" : ", loopt nog"}.`;
}

function renderResults(pid, data) {
  clearCharts();
  const st = clientUi[pid];
  const chs = Object.keys(data.channels).sort(); // facebook, instagram → toon IG eerst
  const order = ["instagram", "facebook"].filter(c => data.channels[c]);
  if (!data.channels[st.ch]) st.ch = order[0];
  const ig = data.channels.instagram, fb = data.channels.facebook;
  const limited = data.period.since > (overviewRows[pid]?.settings?.start || "9999");

  $("#results").innerHTML = `
    ${limited ? `<div class="warn-box">Meta bewaart ongeveer 2 jaar aan statistieken. De periode begint daarom op ${dmy(data.period.since)}.</div>` : ""}
    <h2 class="section">Resultaten in deze periode</h2>
    <p class="section-intro">Per kanaal en samen. De pijltjes vergelijken met de ${data.period.days} dagen daarvoor (${dmy(data.period.prev_since)} – ${dmy(data.period.prev_until)}).</p>
    ${kpiMatrix(data, order)}

    <h2 class="section">Ontwikkeling per kanaal</h2>
    <p class="section-intro">Per ${data.bucket_days === 7 ? "week" : "4 weken"}. Volgers is de stand aan het eind van elke ${data.bucket_days === 7 ? "week" : "periode"}.</p>
    <div class="panel"><div class="panel-head"><span class="label">Verloop</span>
      <div class="seg" id="m-seg"><button data-m="reach">Bereik</button><button data-m="views">Weergaven</button><button data-m="interactions">Interacties</button><button data-m="followers">Volgers</button></div></div>
      <div class="panel-body"><div class="chart-box"><canvas id="c-timeline"></canvas></div></div></div>

    <h2 class="section">Top en flop posts</h2>
    <p class="section-intro" id="tf-intro"></p>
    <div class="panel"><div class="panel-head">
      <label class="switch" id="tf-panel-switch"><span class="label">Rangschikken op</span>
        <span class="sw-opt" data-side="interactions">Interacties</span>
        <input type="checkbox" id="rank-switch" ${ui.rank === "views" ? "checked" : ""}><span class="sw-track"><span class="sw-knob"></span></span>
        <span class="sw-opt" data-side="views">Weergaven</span></label>
      ${chSeg("tf", order, st.ch)}</div><div id="tf"></div></div>

    <h2 class="section">Performance per formaat</h2>
    <p class="section-intro">Gemiddelde per post. Engagement rate = interacties ÷ bereik over alle posts van dat formaat.</p>
    <div class="panel"><div class="table-wrap">${formatTable(data, order)}</div></div>

    <h2 class="section">Video: kijktijd en retentie</h2>
    <p class="section-intro">Reels en video's die in deze periode zijn geplaatst. Instagram geeft via de API alleen de gemiddelde en totale kijktijd; een retentiecurve is er alleen voor Facebook.</p>
    ${videoSection(data, order)}

    <h2 class="section">Doelgroep</h2>
    <p class="section-intro">Wie de volgers zijn, op dit moment. Facebook geeft alleen land en stad; leeftijd en geslacht komen van Instagram (vanaf 100 volgers).</p>
    ${audienceSection(data, order)}

    <div class="foot"><b>Definities.</b> Engagement rate = interacties ÷ bereik. Facebook-bereik over een periode is de optelsom van het dagelijkse bereik;
      Instagram-bereik is uniek per blok van maximaal 30 dagen. Klikken: Instagram = tikken op links in het profiel; Facebook = klikken op posts plus klikken op knoppen van de pagina.
      Kijktijd Facebook in de tabel bovenaan is alle videokijktijd op de pagina (ook advertenties); in het videoblok alleen video's die in deze periode zijn geplaatst.</div>`;

  // tijdlijn
  const drawTimeline = () => {
    document.querySelectorAll("#m-seg button").forEach(b => b.classList.toggle("active", b.dataset.m === st.metric));
    charts.filter(c => c.canvas.id === "c-timeline").forEach(c => { c.destroy(); charts.splice(charts.indexOf(c), 1); });
    const labels = data.buckets.map(dm);
    chart($("#c-timeline"), {
      type: "line",
      data: { labels, datasets: order.map(c => ({
        label: CH[c].name, data: data.channels[c].timeline.map(t => t[st.metric]),
        borderColor: CH[c].color, backgroundColor: CH[c].color, borderWidth: 2.5, tension: .25, pointRadius: 2.5, spanGaps: true })) },
      options: lineOpts({ beginAtZero: st.metric !== "followers" }),
    });
  };
  document.querySelectorAll("#m-seg button").forEach(b => b.onclick = () => { st.metric = b.dataset.m; drawTimeline(); });
  drawTimeline();

  // top/flop
  const drawTf = () => {
    document.querySelectorAll("#tf-seg button").forEach(b => b.classList.toggle("active", b.dataset.ch === st.ch));
    document.querySelectorAll("#tf-panel-switch .sw-opt").forEach(o => o.classList.toggle("on", o.dataset.side === ui.rank));
    const word = ui.rank === "views" ? "weergaven" : "interacties";
    $("#tf-intro").textContent = `De 3 posts met de meeste en de minste ${word} in deze periode. Posts van de laatste 2 dagen tellen niet mee als flop. De stand van de schuif bepaalt ook welke posts in het PDF-rapport komen.`;
    const tf = data.channels[st.ch].top_flop[ui.rank];
    // Dekking: welk deel van alle weergaven komt uit de posts in deze lijst (alleen intern, niet in het klantrapport)
    const chd = data.channels[st.ch], share = chd.kpis.views ? chd.post_views / chd.kpis.views * 100 : null;
    const cover = share != null && share < 70 ? `<div class="warn-box" style="margin:0;border-left-color:var(--st-flat)">
      De posts uit deze periode zijn samen goed voor <b>${fmtPct(share, 0)}</b> van alle ${CH[st.ch].name}-weergaven (${fmt(chd.post_views)} van ${fmt(chd.kpis.views)}).
      De rest komt uit advertenties die niet als gewone post zijn geplaatst, of uit oudere posts die nog weergaven krijgen. Die staan niet in deze top en flop.</div>` : "";
    $("#tf").innerHTML = `${cover}<div class="tf-grid">
      <div><div class="label" style="margin-bottom:6px">Top 3</div>${tf.top.map((p, i) => postCard(p, i + 1)).join("") || `<div class="empty">Geen posts in deze periode.</div>`}</div>
      <div><div class="label" style="margin-bottom:6px">Flop 3</div>${tf.flop.map((p, i) => postCard(p, i + 1)).join("") || `<div class="empty">Te weinig posts.</div>`}</div></div>`;
  };
  document.querySelectorAll("#tf-seg button").forEach(b => b.onclick = () => { st.ch = b.dataset.ch; drawTf(); });
  $("#rank-switch").onchange = e => {
    ui.rank = e.target.checked ? "views" : "interactions";
    try { localStorage.setItem("em-rank", ui.rank); } catch {}
    updateRankNote(); drawTf();
  };
  document.querySelectorAll("#tf-panel-switch .sw-opt").forEach(o => o.onclick = ev => { ev.preventDefault(); const sw = $("#rank-switch"); sw.checked = o.dataset.side === "views"; sw.onchange({ target: sw }); });
  drawTf();

  // retentiecurve
  const curve = fb?.video?.retention_curve;
  if (curve && $("#c-retention")) {
    const n = curve.length;
    chart($("#c-retention"), {
      type: "line",
      data: { labels: curve.map((_, i) => Math.round(i / (n - 1) * 100) + "%"),
        datasets: [{ label: "Kijkers nog aan het kijken", data: curve, borderColor: BRAND.navy, backgroundColor: BRAND.navy, borderWidth: 2.5, pointRadius: 0, tension: .2 }] },
      options: lineOpts({ max: 100, pct: true, xTitle: "Positie in de video", legend: false }),
    });
  }
  // leeftijd/geslacht
  const ag = ig?.audience?.age_gender;
  if (ag?.length && $("#c-age")) {
    chart($("#c-age"), {
      type: "bar",
      data: { labels: ag.map(a => a[0]), datasets: [
        { label: "Vrouw", data: ag.map(a => a[1].F), backgroundColor: BRAND.navy },
        { label: "Man", data: ag.map(a => a[1].M), backgroundColor: BRAND.mint },
        { label: "Onbekend", data: ag.map(a => a[1].U), backgroundColor: BRAND.navy15 }] },
      options: { maintainAspectRatio: false, plugins: { legend: { position: "bottom", align: "start", labels: { boxWidth: 12, boxHeight: 12 } }, tooltip: tooltipOpts() },
        scales: { x: { stacked: true, grid: { display: false }, border: { color: BRAND.navy, width: 1.5 } }, y: { stacked: true, grid: { color: BRAND.navy15 }, border: { display: false }, ticks: { callback: v => fmt(v) } } } },
    });
  }
}

const chSeg = (id, order, active) => order.length < 2 ? `<span class="label">${CH[order[0]].name}</span>` :
  `<div class="seg" id="${id}-seg">${order.map(c => `<button data-ch="${c}" class="${c === active ? "active" : ""}">${CH[c].name}</button>`).join("")}</div>`;
const tooltipOpts = () => ({ backgroundColor: BRAND.navy, cornerRadius: 0, padding: 10, boxPadding: 4, titleFont: { weight: "700" } });
function lineOpts({ beginAtZero = true, max, pct, xTitle, legend = true } = {}) {
  return {
    maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
    plugins: { legend: { display: legend, position: "bottom", align: "start", labels: { boxWidth: 14, boxHeight: 3, padding: 18 } },
      tooltip: { ...tooltipOpts(), callbacks: { label: x => ` ${x.dataset.label}: ${pct ? fmtPct(x.parsed.y, 0) : fmt(x.parsed.y)}` } } },
    scales: {
      x: { grid: { display: false }, border: { color: BRAND.navy, width: 1.5 }, ticks: { maxRotation: 0, autoSkipPadding: 14 },
           title: xTitle ? { display: true, text: xTitle } : undefined },
      y: { beginAtZero, max, grid: { color: BRAND.navy15 }, border: { display: false }, ticks: { callback: v => pct ? v + "%" : fmt(v) } },
    },
  };
}

function kpiMatrix(data, order) {
  const k = c => data.channels[c]?.kpis || {}, p = c => data.channels[c]?.prev || null;
  const sum = (key, src = k) => { const v = order.map(c => src(c)?.[key]).filter(x => x != null); return v.length ? v.reduce((a, b) => a + b, 0) : null; };
  const allPrev = order.every(c => p(c));
  const totalEr = (src) => { const i = sum("interactions", src), r = sum("reach", src); return i != null && r ? i / r * 100 : null; };
  const rows = [
    ["Bereik", "reach", fmt, true], ["Weergaven", "views", fmt, true], ["Interacties", "interactions", fmt, true],
    ["Engagement rate", "er", v => fmtPct(v, 1), true, "er"],
    ["Volgers nu", "followers", fmt, false],
    ["Volgersgroei", "follower_net", v => v == null ? "–" : (v >= 0 ? "+" : "") + fmt(v), true, "growth"],
    ["Opgeslagen", "saves", fmt, true], ["Gedeeld", "shares", fmt, true], ["Reacties", "comments", fmt, true],
    ["Likes / reacties", "likes", fmt, true], ["Klikken", "clicks", fmt, true],
    ["Posts geplaatst", "posts", fmt, false], ["Kijktijd (uren)", "watch_h", fmt1, false],
  ];
  const cell = (v, prevV, show, f, extra) => `<td class="n"><div class="big">${f(v)}</div>${show ? `<div class="cell-sub">${trend(pctChange(v, prevV), { band: 5 })}</div>` : ""}${extra || ""}</td>`;
  return `<div class="panel"><div class="table-wrap"><table>
    <thead><tr><th>Resultaat</th>${order.map(c => `<th class="n">${CH[c].name}</th>`).join("")}${order.length > 1 ? `<th class="n">Samen</th>` : ""}</tr></thead>
    <tbody>${rows.map(([label, key, f, trendable, special]) => {
      const cells = order.map(c => {
        const v = k(c)[key], pv = p(c)?.[key];
        const extra = special !== "growth" ? "" :
          (k(c).follower_growth_pct != null ? `<div class="cell-sub">${signed(k(c).follower_growth_pct)}</div>` : "") +
          (k(c).follower_from ? `<div class="cell-sub" title="Meta geeft volgersgegevens van Instagram ongeveer een jaar terug">vanaf ${dmy(k(c).follower_from)}</div>` : "");
        return cell(v, pv, trendable && p(c) && pv != null, f, extra);
      }).join("");
      let total = "";
      if (order.length > 1) {
        const tv = special === "er" ? totalEr(k) : key === "follower_net" ? (order.every(c => k(c)[key] != null) ? sum(key) : null) : sum(key);
        // Alleen een trend als élk kanaal een vergelijkingswaarde heeft
        const prevComplete = allPrev && order.every(c => p(c)[special === "er" ? "reach" : key] != null);
        const tp = !prevComplete ? null : special === "er" ? totalEr(p) : sum(key, p);
        total = cell(tv, tp, trendable && tp != null, f);
      }
      return `<tr><td><b>${label}</b></td>${cells}${total}</tr>`;
    }).join("")}</tbody></table></div></div>`;
}

function postCard(p, i) {
  return `<a class="post" href="${esc(p.url)}" target="_blank" rel="noopener">
    ${p.image ? `<img src="${esc(p.image)}" alt="" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'noimg'}))">` : `<div class="noimg"></div>`}
    <div><div><span class="rank">${String(i).padStart(2, "0")}</span><span class="chip">${esc(p.format)}</span> <span class="muted small">${dmy(p.date)}</span></div>
      <div class="text">${esc(p.text || "(geen tekst)")}</div>
      <div class="stats">${p.views != null ? `<span><b>${fmt(p.views)}</b> weergaven</span>` : ""}
        <span><b>${fmt(p.interactions)}</b> interacties</span><span><b>${fmt(p.reach)}</b> bereik</span><span>ER <b>${fmtPct(p.er, 1)}</b></span>
        ${p.saves != null ? `<span><b>${fmt(p.saves)}</b> opgeslagen</span>` : ""}${p.shares != null ? `<span><b>${fmt(p.shares)}</b> gedeeld</span>` : ""}</div></div></a>`;
}

function formatTable(data, order) {
  const rows = order.flatMap(c => {
    const f = data.channels[c].formats;
    const best = Math.max(...f.filter(x => x.count >= 2).map(x => x.er ?? -1));
    return f.map(x => ({ ...x, ch: c, best: x.count >= 2 && x.er === best && f.length > 1 }));
  });
  if (!rows.length) return `<div class="empty">Geen posts in deze periode.</div>`;
  return `<table><thead><tr><th>Kanaal</th><th>Formaat</th><th class="n">Posts</th><th class="n">Gem. bereik</th><th class="n">Gem. weergaven</th>
    <th class="n">Gem. interacties</th><th class="n">Gem. opgeslagen</th><th class="n">Engagement rate</th></tr></thead>
    <tbody>${rows.map(x => `<tr><td>${CH[x.ch].name}</td><td><b>${esc(x.format)}</b> ${x.best ? `<span class="chip mint">Beste</span>` : ""}</td>
      <td class="n">${fmt(x.count)}</td><td class="n">${fmt(x.reach)}</td><td class="n">${fmt(x.views)}</td><td class="n">${fmt(x.interactions)}</td>
      <td class="n">${x.saves == null ? "–" : fmt(x.saves)}</td><td class="n"><b>${fmtPct(x.er, 1)}</b></td></tr>`).join("")}</tbody></table>`;
}

function videoSection(data, order) {
  const blocks = order.map(c => ({ c, v: data.channels[c].video })).filter(x => x.v);
  if (!blocks.length) return `<div class="panel"><div class="empty">Geen video's of reels in deze periode.</div></div>`;
  return blocks.map(({ c, v }) => `
    <div class="panel"><div class="panel-head"><span class="label">${CH[c].name} · ${c === "instagram" ? "reels" : "video's"}</span></div>
      <div class="tiles" style="border-left:0;border-top:0">
        <div class="tile dark"><div class="label">Gem. kijktijd per weergave</div><div class="value">${fmt1(v.avg_watch_s)} s</div></div>
        <div class="tile"><div class="label">Totale kijktijd</div><div class="value">${fmt1(v.total_watch_h)} uur</div></div>
        <div class="tile"><div class="label">Aantal ${c === "instagram" ? "reels" : "video's"}</div><div class="value">${fmt(v.count)}</div></div>
        ${v.retention_curve ? `<div class="tile"><div class="label">Kijkt tot de helft</div><div class="value">${fmtPct(v.retention_curve[Math.floor(v.retention_curve.length / 2)], 0)}</div><div class="sub">gemiddelde retentie</div></div>
        <div class="tile"><div class="label">Kijkt tot het eind</div><div class="value">${fmtPct(v.retention_curve[v.retention_curve.length - 1], 0)}</div></div>` : ""}
      </div>
      ${v.retention_curve ? `<div class="panel-body" style="border-top:var(--border)"><div class="label" style="margin-bottom:10px">Gemiddelde retentiecurve</div><div class="chart-box small"><canvas id="c-retention"></canvas></div></div>` : ""}
      <div class="table-wrap" style="border-top:var(--border)"><table><thead><tr><th>Video</th><th class="n">Weergaven</th><th class="n">Bereik</th><th class="n">Gem. kijktijd</th><th class="n">Totale kijktijd</th></tr></thead>
        <tbody>${v.videos.map(x => `<tr><td><a href="${esc(x.url)}" target="_blank" rel="noopener">${dmy(x.date)} · ${esc(x.text || "(geen tekst)")}</a></td>
          <td class="n">${fmt(x.views)}</td><td class="n">${fmt(x.reach)}</td><td class="n">${fmt1(x.avg_watch_s)} s</td><td class="n">${fmt1(x.watch_h)} uur</td></tr>`).join("")}</tbody></table></div>
    </div>`).join("");
}

function bars(list, label = x => x) {
  if (!list?.length) return `<div class="empty">Geen gegevens.</div>`;
  const total = list.reduce((a, b) => a + b[1], 0), max = list[0][1];
  return `<ul class="bars">${list.map(([k, v]) => `<li><span>${esc(label(k))}</span><span class="bar-bg"><span class="bar" style="display:block;width:${v / max * 100}%"></span></span><span class="n">${fmtPct(v / total * 100, 0)}</span></li>`).join("")}</ul>`;
}
function audienceSection(data, order) {
  const ig = data.channels.instagram?.audience || {}, fb = data.channels.facebook?.audience || {};
  const city = c => c.replace(/, (Netherlands|Nederland)$/, "");
  return `
    ${ig.age_gender?.length ? `<div class="panel"><div class="panel-head"><span class="label">Instagram · leeftijd en geslacht</span></div>
      <div class="panel-body"><div class="chart-box small"><canvas id="c-age"></canvas></div></div></div>` : ""}
    <div class="two-col">
      ${order.map(c => {
        const a = c === "instagram" ? ig : fb;
        return `<div class="panel"><div class="panel-head"><span class="label">${CH[c].name} · steden</span></div><div class="panel-body">${bars(a.cities, city)}</div></div>
          <div class="panel"><div class="panel-head"><span class="label">${CH[c].name} · landen</span></div><div class="panel-body">${bars(a.countries, countryName)}</div></div>`;
      }).join("")}
    </div>
    <p class="muted small">Percentages zijn het aandeel binnen de getoonde top 10.</p>`;
}

/* ======================= ADVERTENTIES ======================= */
let adsTimer = null;
const ADS_REFRESH_MS = 15 * 60 * 1000;   // gelijk aan de cache op de server
// Enkelvoud voor "kosten per …"
const PER_ONE = { "Leads": "lead", "Aankopen": "aankoop", "Gesprekken gestart": "gesprek", "Bezoeken landingspagina": "bezoek",
  "Linkklikken": "klik", "Videoweergaven": "weergave", "Interacties": "interactie" };
const money = (v, cur = "EUR", d = 2) => v == null ? "–" : v.toLocaleString("nl-NL", { style: "currency", currency: cur, minimumFractionDigits: d, maximumFractionDigits: d });

function adsPanel(pid) {
  const s = adsSettings[pid] || { enabled: false };
  return `<div class="panel"><div class="panel-head"><span class="label">Live advertenties</span>
      ${s.enabled ? `<a class="btn" href="#/klant/${pid}/advertenties">Open advertentiedashboard →</a>` : ""}</div>
    <div class="panel-body collab">
      <label class="switch" style="align-self:center"><span class="sw-opt ${s.enabled ? "" : "on"}">Uit</span>
        <input type="checkbox" id="ads-on" ${s.enabled ? "checked" : ""}><span class="sw-track"><span class="sw-knob"></span></span>
        <span class="sw-opt ${s.enabled ? "on" : ""}">Aan</span></label>
      <label><span class="label">Advertentieaccount</span>
        <select id="ads-acct" class="select"><option value="">${s.ad_account_id ? esc(s.ad_account_id) : "Laden…"}</option></select></label>
      <button class="btn primary" id="ads-save">Opslaan</button>
      <span class="note" id="ads-note"></span>
    </div></div>`;
}

async function bindAdsPanel(pid, acc) {
  const s = adsSettings[pid] || { enabled: false, ad_account_id: null };
  const sel = $("#ads-acct"), note = $("#ads-note");
  const sw = $("#ads-on"), opts = sw.closest(".switch").querySelectorAll(".sw-opt");
  const paint = () => { opts[0].classList.toggle("on", !sw.checked); opts[1].classList.toggle("on", sw.checked); };
  sw.onchange = paint;
  // Klik op 'Uit' of 'Aan' zet de schuif op die stand (niet omdraaien)
  opts.forEach((o, i) => o.onclick = e => { e.preventDefault(); sw.checked = i === 1; paint(); });
  $("#ads-save").onclick = async () => {
    try {
      const saved = await api(`/api/client/${pid}/ads-settings`, { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: $("#ads-on").checked, ad_account_id: sel.value || s.ad_account_id }) });
      adsSettings[pid] = saved; renderSidebar(pid);
      note.textContent = saved.enabled ? (saved.ad_account_id ? "Opgeslagen. Het advertentiedashboard staat aan." : "Opgeslagen. Kies nog een advertentieaccount.") : "Opgeslagen. Het advertentiedashboard staat uit.";
      setTimeout(() => showClient(pid), 700);
    } catch (e) { note.textContent = e.message; }
  };
  try {
    const { accounts: list, suggestion } = await api(`/api/adaccounts?page_id=${pid}`);
    const current = s.ad_account_id || suggestion || "";
    sel.innerHTML = `<option value="">— kies een account —</option>` + list.map(a =>
      `<option value="${esc(a.id)}" ${a.id === current ? "selected" : ""}>${esc(a.name)}${a.business ? ` (${esc(a.business)})` : ""}${a.active ? "" : " · niet actief"}</option>`).join("");
    if (!s.ad_account_id && suggestion) note.textContent = "Voorstel op basis van de naam; controleer en klik op Opslaan.";
  } catch (e) {
    sel.innerHTML = `<option value="">Geen toegang</option>`;
    note.textContent = e.message;
  }
}

async function showAds(pid) {
  const acc = accounts.find(a => a.page_id === pid);
  if (!acc) { $("#view").innerHTML = `<div class="empty">Klant niet gevonden.</div>`; return; }
  const st = clientUi["ads:" + pid] ||= { preset: "7" };
  const today = new Date().toLocaleDateString("sv-SE");
  const range = () => {
    if (st.preset === "today") return { since: today, until: today };
    if (st.preset === "month") return { since: today.slice(0, 8) + "01", until: today };
    const n = +st.preset; return { since: addDays(today, -(n - 1)), until: today };
  };
  $("#view").innerHTML = `
    <a class="back label" href="#/klant/${pid}">← ${esc(acc.page_name)}</a>
    <div class="page-head">
      <div><div class="label" id="ads-eyebrow">Live advertenties</div><h1>${esc(acc.page_name)}</h1></div>
      <div class="controls">
        <div class="seg" id="ads-seg"><button data-p="today">Vandaag</button><button data-p="7">7 dagen</button><button data-p="30">30 dagen</button><button data-p="month">Deze maand</button></div>
        <button class="btn" id="ads-refresh">Vernieuwen</button>
      </div>
    </div>
    <div id="ads-body"><div class="loading-bar"><i style="width:40%"></i></div><p class="muted">Advertentiecijfers ophalen bij Meta…</p></div>`;
  document.querySelectorAll("#ads-seg button").forEach(b => {
    b.classList.toggle("active", b.dataset.p === st.preset);
    b.onclick = () => { st.preset = b.dataset.p; showAds(pid); };
  });
  const load = async () => {
    const r = range();
    try {
      const d = await api(`/api/client/${pid}/ads?since=${r.since}&until=${r.until}`);
      if (location.hash !== `#/klant/${pid}/advertenties`) return;
      renderAds(d);
      $("#ads-eyebrow").textContent = `Live advertenties · ${dmy(d.period.since)} – ${dmy(d.period.until)} · bijgewerkt ${new Date().toLocaleTimeString("nl-NL", { hour: "2-digit", minute: "2-digit" })}`;
    } catch (e) {
      $("#ads-body").innerHTML = `<div class="warn-box">${esc(e.message)}</div>
        <p class="muted small">Het dashboard en de aan/uit-knop werken al; zodra Meta toegang geeft, verschijnen hier de cijfers.</p>`;
    }
  };
  $("#ads-refresh").onclick = async () => { $("#ads-refresh").textContent = "Bezig…"; await api("/api/refresh"); await load(); $("#ads-refresh").textContent = "Vernieuwen"; };
  clearInterval(adsTimer);
  adsTimer = setInterval(load, ADS_REFRESH_MS);   // 'live': elke 15 minuten opnieuw
  await load();
}

function renderAds(d) {
  clearCharts();
  const cur = d.account.currency, t = d.total || {}, p = d.prev || {};
  // Positief gebracht: alleen een pijl bij verbetering (bij kosten = lager)
  const good = (now, prev, lowerIsBetter) => {
    const ch = pctChange(now, prev);
    if (ch == null || !isFinite(ch) || (prev || 0) === 0) return "";
    const better = lowerIsBetter ? ch <= -3 : ch >= 3;
    return better ? `<div class="sub"><span class="tr up">${lowerIsBetter ? "▼" : "▲"} ${signed(ch, 0)}</span> t.o.v. vorige periode</div>` : "";
  };
  const tile = (label, value, extra = "", dark = false) => `<div class="tile ${dark ? "dark" : ""}"><div class="label">${label}</div><div class="value">${value}</div>${extra}</div>`;
  const resLabel = t.result_label || "Resultaten";
  if (!t.spend && !t.impressions) {
    $("#ads-body").innerHTML = `<div class="panel"><div class="empty">Geen advertentieactiviteit in deze periode.</div></div>`;
    return;
  }
  const statusNl = s => ({ ACTIVE: "Actief", PAUSED: "Gepauzeerd", CAMPAIGN_PAUSED: "Gepauzeerd", ADSET_PAUSED: "Gepauzeerd", ARCHIVED: "Gearchiveerd", DELETED: "Verwijderd", IN_PROCESS: "In behandeling", WITH_ISSUES: "Aandacht nodig", PENDING_REVIEW: "In review", DISAPPROVED: "Afgekeurd" }[s] || (s || "–"));
  $("#ads-body").innerHTML = `
    <div class="tiles">
      ${tile(resLabel, fmt(t.results), good(t.results, p.results), true)}
      ${tile(`Kosten per ${PER_ONE[resLabel] || "resultaat"}`, money(t.cost_per_result, cur), good(t.cost_per_result, p.cost_per_result, true))}
      ${tile("Uitgegeven", money(t.spend, cur))}
      ${tile("Bereik", fmt(t.reach), good(t.reach, p.reach))}
      ${tile("Vertoningen", fmt(t.impressions), good(t.impressions, p.impressions))}
      ${tile("Linkklikken", fmt(t.link_clicks), good(t.link_clicks, p.link_clicks))}
      ${tile("CTR", fmtPct(t.ctr, 2), good(t.ctr, p.ctr))}
      ${tile("Kosten per klik", money(t.cpc, cur), good(t.cpc, p.cpc, true))}
    </div>

    <h2 class="section">Verloop per dag</h2>
    <div class="panel"><div class="panel-body"><div class="chart-box"><canvas id="c-ads"></canvas></div></div></div>

    <h2 class="section">Campagnes</h2>
    <div class="panel"><div class="table-wrap"><table><thead><tr><th>Campagne</th><th>Status</th><th class="n">Budget</th><th class="n">Uitgegeven</th>
      <th class="n">Bereik</th><th class="n">Linkklikken</th><th class="n">Resultaten</th><th class="n">Kosten per resultaat</th></tr></thead>
      <tbody>${d.campaigns.map(c => `<tr><td><b>${esc(c.name)}</b></td><td>${c.status === "ACTIVE" ? `<span class="chip mint">Actief</span>` : `<span class="muted small">${statusNl(c.status)}</span>`}</td>
        <td class="n">${c.budget ? `${money(c.budget, cur, 0)} <span class="muted small">${c.budget_type}</span>` : "–"}</td><td class="n">${money(c.spend, cur)}</td>
        <td class="n">${fmt(c.reach)}</td><td class="n">${fmt(c.link_clicks)}</td>
        <td class="n">${c.results ? `${fmt(c.results)} <span class="muted small">${esc(c.result_label)}</span>` : "–"}</td><td class="n">${money(c.cost_per_result, cur)}</td></tr>`).join("")
        || `<tr><td colspan="8" class="muted">Geen campagnes met uitgaven in deze periode.</td></tr>`}</tbody></table></div></div>

    <h2 class="section">Best presterende advertenties</h2>
    <div class="panel"><div class="ads-grid">${d.ads.map(a => `
      <div class="ad-card">${a.image ? `<img src="${esc(a.image)}" alt="" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'noimg'}))">` : `<div class="noimg"></div>`}
        <div><div class="small muted">${esc(a.campaign || "")}</div><b>${esc(a.name)}</b>
          ${a.text ? `<div class="text small">${esc(a.text)}</div>` : ""}
          <div class="stats"><span><b>${fmt(a.results)}</b> ${esc((a.result_label || "resultaten").toLowerCase())}</span><span><b>${money(a.cost_per_result, cur)}</b> per resultaat</span>
            <span><b>${fmt(a.reach)}</b> bereik</span><span>CTR <b>${fmtPct(a.ctr, 2)}</b></span><span><b>${money(a.spend, cur)}</b> uitgegeven</span></div></div></div>`).join("")
      || `<div class="empty">Geen advertenties met resultaten in deze periode.</div>`}</div></div>

    ${t.actions?.length ? `<h2 class="section">Wat de advertenties opleverden</h2>
    <div class="panel"><div class="panel-body">${bars(t.actions.slice(0, 8).map(([k, v]) => [k, v]))}</div></div>` : ""}

    <div class="foot">Bron: Meta advertentieaccount ${esc(d.account.name || d.account.id)}. Cijfers worden elke 15 minuten ververst; Meta zelf loopt soms tot enkele uren achter.
      Resultaat = ${esc(resLabel.toLowerCase())}, het belangrijkste doel dat in deze periode is behaald.</div>`;

  chart($("#c-ads"), {
    type: "bar",
    data: { labels: d.daily.map(x => dm(x.date)), datasets: [
      { type: "bar", label: "Uitgegeven", data: d.daily.map(x => x.spend), backgroundColor: BRAND.navy15, yAxisID: "y1", order: 2 },
      { type: "line", label: resLabel, data: d.daily.map(x => x.results || 0), borderColor: BRAND.navy, backgroundColor: BRAND.navy, borderWidth: 2.5, tension: .25, pointRadius: 2, yAxisID: "y", order: 1 },
      { type: "line", label: "Linkklikken", data: d.daily.map(x => x.link_clicks || 0), borderColor: BRAND.mint, backgroundColor: BRAND.mint, borderWidth: 2.5, tension: .25, pointRadius: 2, yAxisID: "y2", order: 1 }] },
    options: { maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
      plugins: { legend: { position: "bottom", align: "start", labels: { boxWidth: 14, boxHeight: 3, padding: 18 } },
        tooltip: { ...tooltipOpts(), callbacks: { label: x => ` ${x.dataset.label}: ${x.dataset.yAxisID === "y1" ? money(x.parsed.y, cur) : fmt(x.parsed.y)}` } } },
      scales: { x: { grid: { display: false }, border: { color: BRAND.navy, width: 1.5 } },
        y: { beginAtZero: true, grid: { color: BRAND.navy15 }, border: { display: false }, ticks: { precision: 0, callback: v => fmt(v) }, title: { display: true, text: resLabel } },
        y1: { beginAtZero: true, position: "right", grid: { display: false }, border: { display: false }, ticks: { callback: v => money(v, cur, 0) } },
        // linkklikken op een eigen (verborgen) schaal, zodat een klein aantal leads niet plat onderin ligt
        y2: { beginAtZero: true, display: false } } },
  });
}

/* ======================= INSTELLINGEN ======================= */
let syncTimer = null;
const dt = iso => iso ? new Date(iso).toLocaleString("nl-NL", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "–";

async function showSettings() {
  $("#view").innerHTML = `
    <div class="page-head"><div><div class="label">Dashboard</div><h1>Instellingen</h1></div></div>
    <div id="set-body"><div class="empty">Laden…</div></div>`;
  let s;
  try { s = await api("/api/app-settings"); }
  catch (e) { $("#set-body").innerHTML = `<div class="warn-box">${esc(e.message)}</div>`; return; }
  renderSettings(s);
}

function renderSettings(s) {
  const cfg = s.settings, sb = s.supabase, sy = s.sync;
  const times = cfg.sync_times?.length ? cfg.sync_times : ["06:00", "18:00"];
  $("#set-body").innerHTML = `
    <div class="panel"><div class="panel-head"><span class="label">Automatisch verversen</span></div>
      <div class="panel-body">
        <p class="section-intro" style="margin-top:0">Op deze tijden haalt het dashboard alle cijfers op bij Meta en zet ze in Supabase.
          Het dashboard leest daarna uit die cache, dus het laadt direct.</p>
        <div class="label" style="margin-bottom:8px">Tijdstippen per dag</div>
        <div class="controls" id="set-times">${times.map(t => timeRow(t)).join("")}
          <button class="btn" id="set-add">+ Tijdstip</button></div>
        <label class="check" style="margin-top:18px"><input type="checkbox" id="set-new" ${cfg.sync_on_new_accounts ? "checked" : ""}><span class="box"></span>
          <span><b>Ook verversen zodra er een nieuwe pagina of nieuw advertentieaccount bij komt</b><br>
          <span class="muted small">Het dashboard controleert dit elke ${s.online ? "uur" : "15 minuten"}.</span></span></label>
        <div class="controls" style="margin-top:18px"><button class="btn primary" id="set-save">Opslaan</button><span class="note small" id="set-note"></span></div>
        <p class="muted small" style="margin:16px 0 0">${s.online
          ? "Het verversen gebeurt online door GitHub Actions, ook als niemand het dashboard open heeft. GitHub kan een paar minuten later starten dan het ingestelde tijdstip."
          : "Het verversen gebeurt door het dashboard zelf, dus het dashboard moet draaien. Stond het uit of sliep de Mac op het geplande moment, dan wordt de gemiste verversing ingehaald zodra het dashboard weer draait."}</p>
      </div></div>

    <div class="panel"><div class="panel-head"><span class="label">Status</span>
        <button class="btn primary" id="sync-now" ${sb.configured && sb.ok !== false ? "" : "disabled"}>Nu verversen</button></div>
      <div class="tiles" style="border-left:0;border-top:0">
        <div class="tile ${sy.running ? "dark" : ""}"><div class="label">Nu</div><div class="value" style="font-size:20px">${sy.running ? "Bezig met verversen" : "Klaar"}</div>
          <div class="sub">${sy.running ? `${esc(sy.step || "")} ${sy.progress ? `(${sy.progress})` : ""}` : ""}</div></div>
        <div class="tile"><div class="label">Laatst ververst</div><div class="value" style="font-size:20px">${sb.log?.find(l => l.finished_at) ? dt(sb.log.find(l => l.finished_at).finished_at) : "Nog niet"}</div>
          <div class="sub">${esc(sy.last?.message || sb.log?.find(l => l.finished_at)?.message?.split(" | ")[0] || "")}</div></div>
        <div class="tile"><div class="label">Volgende keer</div><div class="value" style="font-size:20px">${dt(s.next_run)}</div></div>
      </div>
      ${sy.last?.errors?.length ? `<div class="panel-body" style="border-top:var(--soft)"><div class="label" style="margin-bottom:6px">Meldingen bij de laatste ronde</div>
        <ul class="small" style="margin:0;padding-left:18px">${sy.last.errors.map(e => `<li>${esc(e)}</li>`).join("")}</ul></div>` : ""}
    </div>

    <div class="panel"><div class="panel-head"><span class="label">Database (Supabase)</span></div>
      <div class="panel-body">${!sb.configured ? `<div class="warn-box" style="margin:0">Supabase is niet ingesteld. Zet SUPABASE_URL en SUPABASE_SERVICE_KEY in .env.</div>`
        : sb.ok === false ? `<div class="warn-box" style="margin:0">${esc(sb.error)}</div>`
        : `<div class="tiles"><div class="tile"><div class="label">Verbinding</div><div class="value" style="font-size:20px">Gekoppeld</div></div>
            <div class="tile"><div class="label">Klanten in database</div><div class="value">${fmt(sb.clients)}</div></div>
            <div class="tile"><div class="label">Dagcijfers vanaf</div><div class="value" style="font-size:20px">${sb.first_day ? dmy(sb.first_day) : "nog leeg"}</div></div>
            <div class="tile"><div class="label">Dagcijfers tot</div><div class="value" style="font-size:20px">${sb.last_day ? dmy(sb.last_day) : "–"}</div></div></div>`}</div></div>

    ${sb.log?.length ? `<div class="panel"><div class="panel-head"><span class="label">Logboek</span></div><div class="table-wrap"><table>
      <thead><tr><th>Gestart</th><th>Klaar</th><th class="n">Dagregels</th><th>Melding</th></tr></thead>
      <tbody>${sb.log.map(l => `<tr><td class="nowrap">${dt(l.started_at)}</td><td class="nowrap">${l.finished_at ? dt(l.finished_at) : "bezig…"}</td>
        <td class="n">${l.rows == null ? "–" : fmt(l.rows)}</td><td class="small">${esc(l.message || "")}</td></tr>`).join("")}</tbody></table></div></div>` : ""}`;

  const bindTimes = () => document.querySelectorAll(".time-del").forEach(b => b.onclick = () => {
    if (document.querySelectorAll(".time-row").length > 1) b.closest(".time-row").remove();
  });
  bindTimes();
  $("#set-add").onclick = () => { if (document.querySelectorAll(".time-row").length < 6) { $("#set-add").insertAdjacentHTML("beforebegin", timeRow("12:00")); bindTimes(); } };
  $("#set-save").onclick = async () => {
    const note = $("#set-note");
    try {
      const out = await api("/api/app-settings", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sync_times: [...document.querySelectorAll(".time-row input")].map(i => i.value), sync_on_new_accounts: $("#set-new").checked }) });
      renderSettings(out); $("#set-note").textContent = "Opgeslagen.";
    } catch (e) { note.textContent = e.message; }
  };
  $("#sync-now").onclick = async () => {
    try { await api("/api/sync", { method: "POST" }); } catch (e) { alert(e.message); return; }
    showSettings();
  };
  clearInterval(syncTimer);
  if (sy.running) syncTimer = setInterval(async () => {   // online: GitHub doet het werk, de status komt uit het logboek
    const st = await api("/api/sync-status").catch(() => null);
    if (!st || !location.hash.startsWith("#/instellingen")) return clearInterval(syncTimer);
    if (!st.sync.running) { clearInterval(syncTimer); showSettings(); return; }
    const tile = document.querySelector("#set-body .tile.dark .sub");
    if (tile) tile.textContent = `${st.sync.step || ""} ${st.sync.progress ? `(${st.sync.progress})` : ""}`;
  }, s.online ? 10000 : 3000);
}
const timeRow = t => `<span class="time-row seg"><input type="time" value="${esc(t)}" class="time-input"><button class="time-del" title="Verwijderen">×</button></span>`;

/* ---------- start ---------- */
(async function init() {
  const hash = new URLSearchParams(location.hash.replace(/^#/, ""));   // uitnodiging / wachtwoord-reset uit de mail
  const authType = hash.get("type"), authError = hash.get("error_description");
  try { config = await fetch("/api/config").then(r => r.json()); } catch {}
  if (config.auth) {
    if (!window.supabase || !config.supabase_url || !config.supabase_anon_key) {
      $("#view").innerHTML = `<div class="warn-box">Inloggen is niet goed ingesteld: SUPABASE_ANON_KEY ontbreekt.</div>`; return;
    }
    sbAuth = window.supabase.createClient(config.supabase_url, config.supabase_anon_key,
      { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: "implicit" } });
    const { data } = await sbAuth.auth.getSession();
    if (data.session && (authType === "invite" || authType === "recovery")) return showLogin(null, "password");
    if (!data.session) return showLogin(authError ? "De link is verlopen of al gebruikt. Vraag een nieuwe aan." : "");
    if (hash.get("access_token")) history.replaceState(null, "", location.pathname + "#/");
    $("#user").innerHTML = `<span class="small">${esc(data.session.user.email)}</span><a href="#" id="logout" class="small">Uitloggen</a>`;
    $("#logout").onclick = async e => { e.preventDefault(); await sbAuth.auth.signOut(); location.replace(location.pathname + "#/"); location.reload(); };
  }
  try { adsSettings = await api("/api/ads-settings"); } catch { adsSettings = {}; }
  try { accounts = await api("/api/accounts"); }
  catch (e) { $("#view").innerHTML = `<div class="warn-box">${esc(e.message)}</div>`; return; }
  window.addEventListener("hashchange", route);
  route();
  loadOverview();
})();
