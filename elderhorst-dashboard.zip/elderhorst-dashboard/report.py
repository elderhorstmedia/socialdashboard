"""
PDF-rapport voor de klant, in Elderhorst Media-huisstijl.

Toon: positief en nuchter. Groei staat vooraan met groene pijlen. Dalingen worden niet verborgen of verdraaid,
maar staan zonder rode pijlen in het blok 'Kansen voor de komende periode'. Alle cijfers zijn echte Meta-cijfers.
"""
import base64
import html
import mimetypes
import shutil
import subprocess
import tempfile
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from pathlib import Path

import analytics
import store

ROOT = Path(__file__).parent
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
MONTHS = ["januari", "februari", "maart", "april", "mei", "juni", "juli", "augustus",
          "september", "oktober", "november", "december"]
MIN_CHANGE = 3.0   # kleinere verschillen noemen we niet als groei of kans
MIN_BASE = 20      # percentages vanaf een te klein vertrekpunt (bv. 1 → 48 = +4.700%) noemen we niet

E = lambda s: html.escape(str(s if s is not None else ""))


# ---------------- periodes ----------------
def resolve_period(preset, settings):
    y = analytics.yesterday()
    if preset == "maand":
        last = date.today().replace(day=1) - timedelta(days=1)
        first = last.replace(day=1)
        return {"since": first, "until": last, "title": f"{MONTHS[first.month - 1]} {first.year}",
                "label": f"in {MONTHS[first.month - 1]}", "cmp": "de maand ervoor", "slug": f"{first.year}-{first.month:02d}"}
    if preset in ("30", "60"):
        n = int(preset)
        return {"since": y - timedelta(days=n - 1), "until": y, "title": f"Laatste {n} dagen",
                "label": f"in de laatste {n} dagen", "cmp": f"de {n} dagen ervoor", "slug": f"laatste-{n}-dagen"}
    if preset == "start":
        if not settings.get("start"):
            raise ValueError("Stel eerst een startdatum van de samenwerking in.")
        s = date.fromisoformat(settings["start"])
        e = min(date.fromisoformat(settings["end"]), y) if settings.get("end") else y
        if s > e:
            raise ValueError("De samenwerking is nog niet begonnen.")
        return {"since": s, "until": e, "title": "Sinds de start van de samenwerking",
                "label": "sinds de start van de samenwerking", "cmp": "dezelfde periode vóór de samenwerking", "slug": "sinds-start"}
    raise ValueError("Onbekende periode.")


# ---------------- helpers ----------------
def nl(n, d=0):
    if n is None:
        return "–"
    s = f"{n:,.{d}f}"
    return s.replace(",", "X").replace(".", ",").replace("X", ".")


def pct(a, b):
    return None if a is None or not b else (a - b) / b * 100


def dmy(d):
    d = date.fromisoformat(d) if isinstance(d, str) else d
    return f"{d.day} {MONTHS[d.month - 1]} {d.year}"


def total(res, key, src="kpis"):
    vals = [ch[src][key] for ch in res["channels"].values() if ch.get(src) and ch[src].get(key) is not None]
    return sum(vals) if vals else None


def total_complete(res, key, src="prev"):
    """Som alleen als élk kanaal de waarde heeft (anders is een vergelijking scheef)."""
    chs = list(res["channels"].values())
    if not all(ch.get(src) and ch[src].get(key) is not None for ch in chs):
        return None
    return sum(ch[src][key] for ch in chs)


def total_er(res, src="kpis"):
    i, r = total(res, "interactions", src), total(res, "reach", src)
    return i / r * 100 if i is not None and r else None


def embed_image(url):
    """Download de thumbnail en verklein hem (macOS 'sips', als die er is) zodat de PDF licht blijft om te mailen."""
    if not url:
        return None
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            data, ctype = r.read(), r.headers.get_content_type()
        if not ctype.startswith("image/"):
            return None
        if shutil.which("sips"):
            with tempfile.TemporaryDirectory() as td:
                src, dst = Path(td) / "in", Path(td) / "out.jpg"
                src.write_bytes(data)
                done = subprocess.run(["sips", "-Z", "480", "-s", "format", "jpeg", "-s", "formatOptions", "75",
                                       str(src), "--out", str(dst)], capture_output=True, timeout=30)
                if done.returncode == 0 and dst.exists():
                    data, ctype = dst.read_bytes(), "image/jpeg"
        return f"data:{ctype};base64,{base64.b64encode(data).decode()}"
    except Exception:  # noqa – thumbnail mag het rapport niet breken
        return None


def file_data_uri(path):
    ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
    if str(path).endswith(".ttf"):
        ctype = "font/ttf"
    return f"data:{ctype};base64,{base64.b64encode(Path(path).read_bytes()).decode()}"


# ---------------- grafiek (SVG) ----------------
def svg_lines(labels, series, w=740, h=210, fmt=lambda v: nl(v)):
    pl, pr, pt, pb = 58, 12, 10, 26
    vals = [v for _, _, vs in series for v in vs if v is not None]
    if not vals or len(labels) < 2:
        return ""
    lo = 0 if min(vals) >= 0 and min(vals) < max(vals) * 0.5 else min(vals) * 0.95
    hi = max(vals) * 1.08 or 1
    X = lambda i: pl + (w - pl - pr) * i / (len(labels) - 1)
    Y = lambda v: pt + (h - pt - pb) * (1 - (v - lo) / (hi - lo or 1))
    out = [f'<svg viewBox="0 0 {w} {h}" width="100%" xmlns="http://www.w3.org/2000/svg" font-family="Montserrat" font-size="10">']
    for k in range(5):
        v = lo + (hi - lo) * k / 4
        out.append(f'<line x1="{pl}" x2="{w - pr}" y1="{Y(v):.1f}" y2="{Y(v):.1f}" stroke="#D5D5E2" stroke-width="1"/>'
                   f'<text x="{pl - 8}" y="{Y(v) + 3:.1f}" text-anchor="end" fill="#26264F">{fmt(v)}</text>')
    out.append(f'<line x1="{pl}" x2="{w - pr}" y1="{h - pb}" y2="{h - pb}" stroke="#000030" stroke-width="1.5"/>')
    step = max(1, len(labels) // 8)
    for i, lab in enumerate(labels):
        if i % step == 0 or i == len(labels) - 1:
            out.append(f'<text x="{X(i):.1f}" y="{h - 8}" text-anchor="middle" fill="#26264F">{E(lab)}</text>')
    for _, color, vs in series:
        pts = [(X(i), Y(v)) for i, v in enumerate(vs) if v is not None]
        if len(pts) > 1:
            out.append(f'<polyline fill="none" stroke="{color}" stroke-width="2.5" stroke-linejoin="round" points="'
                       + " ".join(f"{x:.1f},{y:.1f}" for x, y in pts) + '"/>')
        for x, y in pts:
            out.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2.6" fill="{color}"/>')
    out.append("</svg>")
    return "".join(out)


def legend(series):
    return '<div class="legend">' + "".join(f'<span><i style="background:{c}"></i>{E(n)}</span>' for n, c, _ in series) + "</div>"


# ---------------- data ----------------
CH_NAME = {"instagram": "Instagram", "facebook": "Facebook"}
CH_COLOR = {"instagram": "#000030", "facebook": "#36E092"}
KEY_METRICS = [("reach", "Bereik"), ("views", "Weergaven"), ("interactions", "Interacties"),
               ("follower_net", "Nieuwe volgers"), ("saves", "Keer opgeslagen"), ("shares", "Keer gedeeld"),
               ("comments", "Reacties")]


SECTIONS = ["samenvatting", "voor_na", "kanalen", "ontwikkeling", "posts", "formaat", "video", "publiek", "kansen"]
CHANNELS = ["instagram", "facebook"]


def only_channels(res, channels):
    if channels:
        res["channels"] = {k: v for k, v in res["channels"].items() if k in channels}
        if not res["channels"]:
            raise ValueError("Deze klant heeft geen van de gekozen kanalen gekoppeld.")
    return res


def before_after(c, pid, settings, channels=None):
    """Gemiddelde per 30 dagen vóór de samenwerking tegenover sinds de start."""
    if not settings.get("start"):
        return None
    y = analytics.yesterday()
    s = date.fromisoformat(settings["start"])
    e = min(date.fromisoformat(settings["end"]), y) if settings.get("end") else y
    if s > e:
        return None
    days = (e - s).days + 1
    b_days = min(max(days, 30), 90)
    bs, be = s - timedelta(days=b_days), s - timedelta(days=1)
    if bs < date.today() - timedelta(days=analytics.HISTORY_DAYS):
        return None
    during = only_channels(analytics.client_results(c, pid, s, e), channels)
    before = only_channels(analytics.client_results(c, pid, bs, be), channels)
    rows = []
    for key, label in [("reach", "Bereik"), ("views", "Weergaven"), ("interactions", "Interacties"),
                       ("posts", "Posts geplaatst"), ("follower_net", "Nieuwe volgers")]:
        # alleen kanalen die in beide periodes een waarde hebben
        chs = [ch for ch in during["channels"] if ch in before["channels"]
               and during["channels"][ch]["kpis"].get(key) is not None and before["channels"][ch]["kpis"].get(key) is not None]
        if not chs:
            continue
        a = sum(before["channels"][ch]["kpis"][key] for ch in chs) / b_days * 30
        b = sum(during["channels"][ch]["kpis"][key] for ch in chs) / days * 30
        if a < MIN_BASE:
            # Vóór de samenwerking vrijwel niets: geen (absurd) percentage, maar 'nieuw'
            if b >= MIN_BASE:
                rows.append({"label": label, "before": a, "after": b, "change": None, "new": True})
            continue
        rows.append({"label": label, "before": a, "after": b, "change": pct(b, a)})
    er_b, er_a = total_er(before), total_er(during)
    if er_b is not None and er_a is not None:
        rows.append({"label": "Engagement rate", "before": er_b, "after": er_a, "change": pct(er_a, er_b), "pct": True})
    return {"start": s, "until": e, "days": days, "before_days": b_days, "rows": rows}


def build_data(c, pid, preset, rank="views", sections=None, channels=None):
    rank = rank if rank in analytics.RANK_KEYS else "views"
    sections = [s for s in (sections or SECTIONS) if s in SECTIONS] or SECTIONS
    channels = [ch for ch in (channels or CHANNELS) if ch in CHANNELS] or CHANNELS
    settings = store.get_settings(pid)
    per = resolve_period(preset, settings)
    res = only_channels(analytics.client_results(c, pid, per["since"], per["until"]), channels)
    ba = before_after(c, pid, settings, channels) if "voor_na" in sections or preset == "start" else None

    wins, focus = [], []
    for key, label in KEY_METRICS + [("er", "Engagement rate")]:
        if key == "er":
            now, prev = total_er(res), (total_er(res, "prev") if total_complete(res, "reach") is not None else None)
        else:
            now, prev = total(res, key), total_complete(res, key)
        ch = pct(now, prev)
        if ch is None or prev is None or (key != "er" and prev < MIN_BASE):
            continue
        item = {"key": key, "label": label, "now": now, "prev": prev, "change": ch, "scope": "totaal"}
        (wins if ch >= MIN_CHANGE else focus if ch <= -MIN_CHANGE else []).append(item)
    # per kanaal aanvullen (bv. alleen Instagram heeft opgeslagen)
    for chn, chd in res["channels"].items():
        for key, label in KEY_METRICS:
            now, prev = chd["kpis"].get(key), (chd.get("prev") or {}).get(key)
            if now is None or prev is None or any(w["key"] == key for w in wins + focus):
                continue
            ch = pct(now, prev)
            if ch is None or prev < MIN_BASE:
                continue
            item = {"key": key, "label": f"{label} op {CH_NAME[chn]}", "now": now, "prev": prev, "change": ch, "scope": chn}
            (wins if ch >= MIN_CHANGE else focus if ch <= -MIN_CHANGE else []).append(item)
    wins.sort(key=lambda x: -x["change"])
    focus.sort(key=lambda x: x["change"])
    if ba:
        for r in ba["rows"]:
            if r["change"] is None or r["change"] > -MIN_CHANGE:
                continue
            if r.get("pct") and any(f.get("key") == "er" for f in focus):
                continue  # engagement rate staat er al in
            focus.append({"key": "er" if r.get("pct") else None, "label": f"{r['label']} t.o.v. vóór de samenwerking",
                          "now": r["after"], "prev": r["before"], "change": r["change"], "pct": r.get("pct"),
                          "per30": not r.get("pct")})
    reach_growth = pct(total(res, "reach"), total_complete(res, "reach"))

    # thumbnails van de best presterende posts insluiten
    tops = [(chn, p) for chn, chd in res["channels"].items() for p in chd["top_flop"][rank]["top"]]
    with ThreadPoolExecutor(6) as pool:
        imgs = list(pool.map(lambda t: embed_image(t[1].get("image")), tops))
    for (chn, p), img in zip(tops, imgs):
        p["image_data"] = img
    return {"settings": settings, "period": per, "res": res, "before_after": ba, "wins": wins, "focus": focus, "rank": rank,
            "sections": sections,
            "reach_growth": reach_growth}


# ---------------- HTML ----------------
def up(change, prev=None):
    if change is None or change < MIN_CHANGE or (prev is not None and prev < MIN_BASE):
        return ""
    return f'<span class="up">▲ +{nl(change)}%</span>'


def growth_phrase(label, change, suffix):
    """'2,2× zoveel bereik per maand als …' bij verdubbeling of meer, anders '… 45% hoger …'."""
    if change >= 100:
        return f'{nl(1 + change / 100, 1)}× zoveel {label.lower()} {suffix}'
    return f'{label} {nl(change)}% hoger {suffix.replace("als ", "dan ")}'


def headline(d):
    w, res, per = d["wins"], d["res"], d["period"]
    ba = d["before_after"]
    best_ba = max((r for r in (ba or {}).get("rows", []) if (r["change"] or 0) >= MIN_CHANGE
                   and (r.get("pct") or r["before"] >= MIN_BASE)), key=lambda r: r["change"], default=None)
    if ba and best_ba and ba["days"] <= 120:
        return growth_phrase(best_ba["label"], best_ba["change"], "per maand als vóór de samenwerking")
    new = [r for r in (ba or {}).get("rows", []) if r.get("new")]
    if ba and new and not best_ba:
        r = max(new, key=lambda r: r["after"])
        return f'Van vrijwel nul naar {nl(r["after"])} {r["label"].lower()} per maand sinds de start van de samenwerking'
    if w:
        return f'{w[0]["label"]} groeide {per["label"]} met {nl(w[0]["change"])}%'
    return f'{nl(total(res, "reach"))} keer bereikt en {nl(total(res, "interactions"))} interacties {per["label"]}'


def tile(label, value, change=None, sub=None, dark=False):
    return (f'<div class="tile{" dark" if dark else ""}"><div class="label">{E(label)}</div><div class="value">{value}</div>'
            f'{f"<div class=sub>{up(change)}</div>" if up(change) else ""}{f"<div class=sub>{E(sub)}</div>" if sub else ""}</div>')


def post_card(p, rank):
    img = f'<img src="{p["image_data"]}">' if p.get("image_data") else '<div class="noimg"></div>'
    stats = []
    if p.get("views") is not None:
        stats.append(f'<b>{nl(p["views"])}</b> weergaven')
    stats += [f'<b>{nl(p.get("interactions"))}</b> interacties', f'<b>{nl(p.get("reach"))}</b> bereik']
    if p.get("saves"):
        stats.append(f'<b>{nl(p["saves"])}</b> keer opgeslagen')
    if p.get("shares"):
        stats.append(f'<b>{nl(p["shares"])}</b> keer gedeeld')
    return (f'<div class="post">{img}<div><div><span class="rank">{rank:02d}</span><span class="chip">{E(p["format"])}</span> '
            f'<span class="muted">{dmy(p["date"])}</span></div><div class="ptext">{E(p["text"] or "(geen tekst)")}</div>'
            f'<div class="stats">{" · ".join(stats)}</div></div></div>')


def render_html(d, client_name):
    res, per, ba = d["res"], d["period"], d["before_after"]
    chs = [c for c in ("instagram", "facebook") if c in res["channels"]]
    fonts = {n: file_data_uri(ROOT / "fonts" / f) for n, f in
             (("Josefin Sans", "JosefinSans-VariableFont_wght.ttf"), ("Montserrat", "Montserrat-VariableFont_wght.ttf"))}
    logo = file_data_uri(ROOT / "public" / "logo" / "logo-white.svg")
    mark = file_data_uri(ROOT / "public" / "logo" / "mark-green.svg")
    P = []
    marks = []
    mark = lambda key: marks.append((key, len(P)))

    # ---- kop ----
    P.append(f'''<header class="cover"><div class="raster"></div><div class="cover-in">
      <img class="logo" src="{logo}">
      <div class="label light">Resultatenrapport · {E(per["title"])}</div>
      <div class="mint-label">{E(client_name)}</div>
      <h1>{E(headline(d))}</h1>
      <div class="meta">Periode: {dmy(per["since"])} – {dmy(res["period"]["until"])} · Opgesteld door Elderhorst Media op {dmy(date.today())}</div>
    </div></header>''')

    # ---- samenvatting ----
    mark("samenvatting")
    tr = lambda k: pct(total(res, k), total_complete(res, k)) if (total_complete(res, k) or 0) >= MIN_BASE else None
    fn = total(res, "follower_net")
    P.append(f'''<section><h2>Samenvatting</h2>
      <p class="lead">Dit zijn de resultaten van {" en ".join(CH_NAME[c] for c in chs)} {E(per["label"])}, vergeleken met {E(per["cmp"])}.</p>
      <div class="tiles">
        {tile("Bereik", nl(total(res, "reach")), tr("reach"), dark=True)}
        {tile("Weergaven", nl(total(res, "views")), tr("views"))}
        {tile("Interacties", nl(total(res, "interactions")), tr("interactions"))}
        {tile("Nieuwe volgers", ("+" if (fn or 0) > 0 else "") + nl(fn) if fn is not None else "–", None, f"{nl(total(res, 'followers'))} volgers nu")}
      </div>''')
    if d["wins"]:
        P.append('<div class="conclusion"><div class="label light">In het kort</div><ul>' + "".join(
            f'<li><b>{E(w["label"])}</b>: {nl(w["now"], 1 if w["key"] == "er" else 0)}{"%" if w["key"] == "er" else ""} '
            f'<span class="upl">▲ +{nl(w["change"])}%</span> t.o.v. {E(per["cmp"])}</li>' for w in d["wins"][:4]) + '</ul></div>')
    P.append("</section>")

    # ---- voor en na ----
    mark("voor_na")
    good = [r for r in (ba or {}).get("rows", []) if r.get("new") or (r["change"] is not None and r["change"] >= MIN_CHANGE)]
    if ba and good:
        mx = lambda r: max(r["before"], r["after"]) or 1
        badge = lambda r: '<span class="chip mint">Nieuw</span>' if r.get("new") else f'<span class="up">▲ +{nl(r["change"])}%</span>'
        before_txt = lambda r: "vrijwel 0" if r.get("new") else f'{nl(r["before"], 1 if r.get("pct") else 0)}{"%" if r.get("pct") else ""}'
        P.append(f'''<section><h2>Voor en na Elderhorst Media</h2>
          <p class="lead">Gemiddeld per 30 dagen: de {ba["before_days"]} dagen voordat we begonnen tegenover de periode sinds de start op {dmy(ba["start"])}.</p>
          <div class="ba">{"".join(f"""<div class="ba-row"><div class="ba-label"><b>{E(r["label"])}</b>{badge(r)}</div>
            <div class="ba-bars"><div><span class="bar before" style="width:{r["before"] / mx(r) * 100:.1f}%"></span><em>Vóór: {before_txt(r)}</em></div>
            <div><span class="bar after" style="width:{r["after"] / mx(r) * 100:.1f}%"></span><em>Met Elderhorst Media: {nl(r["after"], 1 if r.get("pct") else 0)}{"%" if r.get("pct") else ""}</em></div></div></div>""" for r in good)}</div>
        </section>''')

    # ---- per kanaal ----
    mark("kanalen")
    for c in chs:
        k, p = res["channels"][c]["kpis"], res["channels"][c].get("prev") or {}
        ch = lambda key: pct(k.get(key), p.get(key)) if key == "er" or (p.get(key) or 0) >= MIN_BASE else None
        growth = f'{"+" if (k.get("follower_net") or 0) > 0 else ""}{nl(k.get("follower_net"))}' if k.get("follower_net") is not None else "–"
        tiles = [tile("Bereik", nl(k["reach"]), ch("reach")), tile("Weergaven", nl(k["views"]), ch("views")),
                 tile("Interacties", nl(k["interactions"]), ch("interactions")),
                 tile("Engagement rate", f'{nl(k["er"], 1)}%' if k.get("er") is not None else "–", ch("er")),
                 tile("Volgers", nl(k["followers"]), None, f"{growth} in deze periode" if growth != "–" else None),
                 tile("Posts geplaatst", nl(k["posts"]))]
        if k.get("saves") is not None:
            tiles.append(tile("Keer opgeslagen", nl(k["saves"]), ch("saves")))
        tiles.append(tile("Keer gedeeld", nl(k["shares"]), ch("shares")))
        P.append(f'<section class="avoid"><h2>{CH_NAME[c]}</h2><div class="tiles">{"".join(tiles)}</div></section>')

    # ---- ontwikkeling ----
    mark("ontwikkeling")
    labels = [f"{date.fromisoformat(b).day}-{date.fromisoformat(b).month}" for b in res["buckets"]]
    if len(labels) >= 2:
        reach_s = [(CH_NAME[c], CH_COLOR[c], [t["reach"] for t in res["channels"][c]["timeline"]]) for c in chs]
        # Nieuwe volgers opgeteld vanaf het begin van de periode (maakt groei zichtbaar, ook bij grote accounts)
        fol_s = []
        for c in chs:
            tl, net = res["channels"][c]["timeline"], res["channels"][c]["kpis"].get("follower_net")
            last = next((t["followers"] for t in reversed(tl) if t["followers"] is not None), None)
            if net is None or last is None:
                continue
            base = last - net
            fol_s.append((CH_NAME[c], CH_COLOR[c], [None if t["followers"] is None else t["followers"] - base for t in tl]))
        fol_html = (f'<p class="lead" style="margin-top:18px">Nieuwe volgers, opgeteld vanaf het begin van de periode.</p>'
                    f'{svg_lines(labels, fol_s, fmt=lambda v: ("+" if v > 0 else "") + nl(v))}{legend(fol_s)}') if fol_s else ""
        P.append(f'''<section><h2>Ontwikkeling</h2>
          <p class="lead">Bereik per {"week" if res["bucket_days"] == 7 else "4 weken"}.</p>{svg_lines(labels, reach_s)}{legend(reach_s)}
          {fol_html}</section>''')

    # ---- beste posts ----
    mark("posts")
    rank_word = "weergaven" if d["rank"] == "views" else "interacties"
    for c in chs:
        top = res["channels"][c]["top_flop"][d["rank"]]["top"]
        if top:
            P.append(f'<section><h2>Best presterende posts op {CH_NAME[c]}</h2>'
                     f'<p class="lead">De 3 posts met de meeste {rank_word} in deze periode.</p>'
                     f'<div class="posts">{"".join(post_card(p, i + 1) for i, p in enumerate(top))}</div></section>')

    # ---- wat werkt ----
    mark("formaat")
    rows, notes = [], []
    for c in chs:
        f = [x for x in res["channels"][c]["formats"] if x["count"] >= 2] or res["channels"][c]["formats"]
        if f:
            best = max(f, key=lambda x: x["er"] or 0)
            notes.append(f'Op {CH_NAME[c]} levert <b>{E(best["format"].lower())}</b> de hoogste betrokkenheid op: '
                         f'{nl(best["er"], 1)}% van het bereik reageert, liket, deelt of slaat op.')
        rows += [(CH_NAME[c], x) for x in res["channels"][c]["formats"]]
    if rows:
        P.append(f'''<section><h2>Wat werkt het best</h2><p class="lead">{"<br>".join(notes)}</p>
          <table><thead><tr><th>Kanaal</th><th>Formaat</th><th class="n">Posts</th><th class="n">Gem. bereik</th><th class="n">Gem. weergaven</th><th class="n">Gem. interacties</th><th class="n">Engagement</th></tr></thead>
          <tbody>{"".join(f'<tr><td>{n}</td><td><b>{E(x["format"])}</b></td><td class="n">{x["count"]}</td><td class="n">{nl(x["reach"])}</td><td class="n">{nl(x["views"])}</td><td class="n">{nl(x["interactions"])}</td><td class="n">{nl(x["er"], 1)}%</td></tr>' for n, x in rows)}</tbody></table></section>''')

    # ---- video ----
    mark("video")
    vids = [(c, res["channels"][c]["video"]) for c in chs if res["channels"][c].get("video")]
    if vids:
        t = []
        for c, v in vids:
            t.append(tile(f"{CH_NAME[c]} · gem. kijktijd", f'{nl(v["avg_watch_s"], 1)} s', sub=f'{v["count"]} {"reels" if c == "instagram" else "video’s"}'))
            t.append(tile(f"{CH_NAME[c]} · totale kijktijd", f'{nl(v["total_watch_h"], 1)} uur'))
            if v.get("retention_curve"):
                rc = v["retention_curve"]
                t.append(tile(f"{CH_NAME[c]} · kijkt tot de helft", f'{nl(rc[len(rc) // 2])}%', sub="gemiddeld per video"))
        P.append(f'<section class="avoid"><h2>Video</h2><p class="lead">Hoe lang er gekeken wordt naar de video’s en reels uit deze periode.</p><div class="tiles">{"".join(t)}</div></section>')

    # ---- publiek ----
    mark("publiek")
    ig_a = res["channels"].get("instagram", {}).get("audience", {}) if "instagram" in res["channels"] else {}
    fb_a = res["channels"].get("facebook", {}).get("audience", {})
    cities = ig_a.get("cities") or fb_a.get("cities") or []
    ages = ig_a.get("age_gender") or []
    if cities or ages:
        blocks = []
        if ages:
            tot = sum(sum(v.values()) for _, v in ages) or 1
            mxa = max(sum(v.values()) for _, v in ages) or 1
            f_share = sum(v.get("F", 0) for _, v in ages) / tot * 100
            blocks.append('<div><div class="label">Leeftijd volgers (Instagram)</div><ul class="bars">' + "".join(
                f'<li><span>{E(a)}</span><span class="bg"><span class="bar" style="width:{sum(v.values()) / mxa * 100:.0f}%"></span></span><span class="n">{nl(sum(v.values()) / tot * 100)}%</span></li>'
                for a, v in ages) + f'</ul><p class="muted small">{nl(f_share)}% vrouw, {nl(sum(v.get("M", 0) for _, v in ages) / tot * 100)}% man.</p></div>')
        if cities:
            ct = sum(v for _, v in cities) or 1
            blocks.append('<div><div class="label">Belangrijkste plaatsen</div><ul class="bars">' + "".join(
                f'<li><span>{E(k.split(",")[0])}</span><span class="bg"><span class="bar" style="width:{v / cities[0][1] * 100:.0f}%"></span></span><span class="n">{nl(v / ct * 100)}%</span></li>'
                for k, v in cities[:8]) + '</ul><p class="muted small">Aandeel binnen de top 10 plaatsen.</p></div>')
        P.append(f'<section class="avoid"><h2>Jullie publiek</h2><div class="two">{"".join(blocks)}</div></section>')

    # ---- kansen ----
    mark("kansen")
    fx = d["focus"][:5]
    closers = ["Hier ligt ruimte om verder te groeien.", "Hier zetten we de komende periode op in.",
               "Een mooi aanknopingspunt voor de volgende periode."]

    def kans(i, f):
        is_pct = bool(f.get("pct") or f.get("key") == "er")
        v = lambda x: f'{nl(x, 1 if is_pct else 0)}{"%" if is_pct else ""}'
        line = f'<li><b>{E(f["label"])}</b>: {v(f["now"])}{" per 30 dagen" if f.get("per30") else ""} (was {v(f["prev"])}). '
        if f.get("key") == "er" and (d.get("reach_growth") or 0) >= 20:
            line += ("Normaal bij een flink groter bereik: er kijken meer mensen mee die het account nog niet kennen. "
                     "Die nieuwe kijkers omzetten in reacties is de volgende stap.")
        else:
            line += closers[i % len(closers)]
        return line + "</li>"
    items = "".join(kans(i, f) for i, f in enumerate(fx))
    P.append(f'''<section><h2>Kansen voor de komende periode</h2>
      {f"<ul class='focus'>{items}</ul>" if items else "<p class='lead'>Alle kerncijfers zijn gelijk gebleven of gegroeid. Daar bouwen we de komende periode op voort.</p>"}
      <div class="closing"><div><div class="label light">Volgende stap</div><h3>Tijd voor een bakkie?</h3>
        <p>We lopen deze resultaten graag samen door en bespreken wat we de komende periode gaan doen. Neem contact op met je vaste contactpersoon bij Elderhorst Media.</p></div>
        <img src="{mark}"></div></section>''')

    # niet-gekozen onderdelen weglaten
    chosen = d.get("sections")
    if chosen:
        bounds = marks + [("_einde", len(P))]
        keep = set(range(bounds[0][1])) if bounds else set(range(len(P)))
        for (key, start), (_, end) in zip(bounds, bounds[1:]):
            if key in chosen:
                keep.update(range(start, end))
        P = [x for i, x in enumerate(P) if i in keep]
    P.append('''<p class="foot">Bron: Meta (Instagram en Facebook). Bereik is het aantal keer dat accounts de content zagen; over langere periodes is het een optelsom.
      Engagement rate = interacties ÷ bereik. Interacties zijn likes, reacties, keer gedeeld en keer opgeslagen.</p>''')

    css = (ROOT / "report.css").read_text()
    font_css = "".join(f'@font-face{{font-family:"{n}";src:url({u}) format("truetype");font-weight:100 900;}}' for n, u in fonts.items())
    return f'<!doctype html><html lang="nl"><head><meta charset="utf-8"><title>{E(client_name)} · {E(per["title"])}</title><style>{font_css}{css}</style></head><body>{"".join(P)}</body></html>'


def pdf_available():
    """Lokaal op de Mac maakt Chrome de PDF; online niet (dan print de browser het rapport)."""
    return Path(CHROME).exists()


def make_html(c, pid, preset, rank="views", sections=None, channels=None):
    acc = c.account(pid)
    d = build_data(c, pid, preset, rank, sections, channels)
    return render_html(d, acc["page_name"]), file_name(acc["page_name"], d["period"]["slug"])


def file_name(page_name, slug):
    name = "".join(ch if ch.isalnum() else "-" for ch in page_name).strip("-")
    return f"Elderhorst-Media_{name}_{slug}.pdf"


def make_pdf(c, pid, preset, rank="views", sections=None, channels=None):
    acc = c.account(pid)
    d = build_data(c, pid, preset, rank, sections, channels)
    page = render_html(d, acc["page_name"])
    tmp = Path(tempfile.mkdtemp(prefix="em-rapport-"))
    try:
        (tmp / "rapport.html").write_text(page, encoding="utf-8")
        out = tmp / "rapport.pdf"
        subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", "--no-first-run",
                        f"--user-data-dir={tmp / 'profiel'}", f"--print-to-pdf={out}", (tmp / "rapport.html").as_uri()],
                       capture_output=True, timeout=120)
        if not out.exists():
            raise RuntimeError("Chrome kon de PDF niet maken.")
        name = "".join(ch if ch.isalnum() else "-" for ch in acc["page_name"]).strip("-")
        return out.read_bytes(), f"Elderhorst-Media_{name}_{d['period']['slug']}.pdf", page
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
