"""
Elderhorst Media – social resultaten dashboard.
Start:  python3 server.py   (leest META_ACCESS_TOKEN uit .env)
Open:   http://localhost:8000
"""
import json
import os
import re
import threading
import traceback
import urllib.parse
from datetime import date, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import ads
import analytics
import auth
import report
import store
import supa
import sync
from meta_client import HOUR, MetaApiError, MetaClient

ROOT = Path(__file__).parent
PUBLIC = ROOT / "public"


def load_env():
    env_file = ROOT / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env()
PORT = int(os.environ.get("PORT", "8000"))
TOKEN = os.environ.get("META_ACCESS_TOKEN", "")
client = MetaClient(TOKEN, os.environ.get("META_API_VERSION", "v24.0"))

ONLINE = bool(os.environ.get("VERCEL"))
PUBLIC_PATHS = {"/api/config"}

DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class NotFound(Exception):
    pass


class RawResponse:
    def __init__(self, body, ctype, filename=None, inline=False):
        self.body, self.ctype, self.filename, self.inline = body, ctype, filename, inline


def cached(key, ttl, fn):
    hit = store.cache_get(key)
    if hit is not None:
        return hit
    val = fn()
    store.cache_set(key, val, ttl)
    return val


CACHE_MAX_AGE = 13 * HOUR   # langer dan de tijd tussen twee verversingen


def computed(key, page_id, fn):
    hit = store.computed_get(key, CACHE_MAX_AGE)
    if hit is not None:
        return hit
    val = fn()
    store.computed_set(key, val, page_id)
    return val


def app_status():
    cfg = store.get_app_settings()
    out = {"settings": cfg, "sync": sync.state(), "next_run": sync.next_slot(cfg.get("sync_times") or []),
           "online": ONLINE, "supabase": {"configured": bool(store.sb())}}
    if store.sb():
        try:
            out["supabase"]["clients"] = len(store.sb().select("clients", select="page_id"))
            first = store.sb().select("daily_metrics", select="day", order="day.asc", limit=1)
            last = store.sb().select("daily_metrics", select="day", order="day.desc", limit=1)
            out["supabase"]["first_day"] = first[0]["day"] if first else None
            out["supabase"]["last_day"] = last[0]["day"] if last else None
            out["supabase"]["log"] = store.sb().select("sync_log", select="started_at,finished_at,rows,message",
                                                       order="started_at.desc", limit=8)
            out["supabase"]["ok"] = True
        except supa.SupaError as e:
            out["supabase"].update(ok=False, error=str(e))
    return out


def get_api(path, qs, user=None):
    if path == "/api/config":
        return {**auth.public_config(), "online": ONLINE, "pdf": report.pdf_available()}

    if path == "/api/me":
        return user or {}

    if path == "/api/accounts":
        return client.list_accounts()

    if path == "/api/app-settings":
        return app_status()

    if path == "/api/sync-status":
        return {"sync": sync.state()}

    if path == "/api/refresh":
        client.clear_cache()
        return {"ok": True}

    m = re.match(r"^/api/client/(\d+)/overview$", path)
    if m:
        # Per klant, zodat het overzicht rij voor rij kan vullen. Komt uit de cache die 2x per dag wordt ververst.
        pid, st = m.group(1), store.get_settings(m.group(1))
        return computed(sync.overview_key(pid, st), pid, lambda: analytics.client_overview(client, client.account(pid), st))

    m = re.match(r"^/api/client/(\d+)/report\.(pdf|html)$", path)
    if m:
        split = lambda k: [x for x in qs.get(k, "").split(",") if x] or None
        args = (client, m.group(1), qs.get("period", "maand"), qs.get("rank", "views"), split("sections"), split("channels"))
        if m.group(2) == "pdf":
            if not report.pdf_available():
                raise ValueError("PDF maken kan hier niet; gebruik report.html en print die als PDF.")
            pdf, name, _ = report.make_pdf(*args)
            return RawResponse(pdf, "application/pdf", name)
        page, name = report.make_html(*args)
        return RawResponse(page.encode(), "text/html; charset=utf-8", name, inline=True)

    # ---------- advertenties ----------
    if path == "/api/ads-settings":
        return store.all_ads_settings()

    if path == "/api/adaccounts":
        accounts = ads.ad_accounts(client)
        pid = qs.get("page_id")
        suggestion = ads.suggest_account(accounts, client.account(pid)["page_name"]) if pid else None
        return {"accounts": accounts, "suggestion": suggestion}

    m = re.match(r"^/api/client/(\d+)/ads$", path)
    if m:
        today = date.today()
        until = date.fromisoformat(qs["until"]) if DATE.match(qs.get("until", "")) else today
        since = date.fromisoformat(qs["since"]) if DATE.match(qs.get("since", "")) else until - timedelta(days=6)
        return ads.client_ads(client, m.group(1), since, until)

    m = re.match(r"^/api/client/(\d+)/results$", path)
    if m:
        y = analytics.yesterday()
        until = date.fromisoformat(qs["until"]) if DATE.match(qs.get("until", "")) else y
        since = date.fromisoformat(qs["since"]) if DATE.match(qs.get("since", "")) else until - timedelta(days=29)
        key = sync.results_key(m.group(1), since, until, store.get_settings(m.group(1)))
        return computed(key, m.group(1), lambda: analytics.client_results(client, m.group(1), since, until))
    raise NotFound(path)


def post_api(path, body, user=None):
    if path == "/api/app-settings":
        times = sorted({t for t in body.get("sync_times", []) if re.match(r"^([01]\d|2[0-3]):[0-5]\d$", t or "")})
        if not times:
            raise ValueError("Geef minstens één tijdstip op (UU:MM).")
        if len(times) > 6:
            raise ValueError("Maximaal 6 verversmomenten per dag.")
        store.save_app_settings({"sync_times": times, "sync_on_new_accounts": bool(body.get("sync_on_new_accounts"))})
        return app_status()

    if path == "/api/sync":
        if not store.sb():
            raise ValueError("Supabase is niet ingesteld.")
        who = (user or {}).get("email", "").split("@")[0]
        reason = f"handmatig{f' ({who})' if who else ''}"
        if sync.state()["running"]:
            return {"started": False, "sync": sync.state()}
        if ONLINE:   # online mag een verzoek niet 12 minuten duren: GitHub Actions doet het werk
            sync.github_dispatch(reason)
            return {"started": True, "sync": {**sync.state(), "running": True, "step": "start in GitHub…"}}
        started = sync.run_in_background(client, reason)
        return {"started": started, "sync": sync.state()}

    m = re.match(r"^/api/client/(\d+)/settings$", path)
    if m:
        start, end = body.get("start") or None, body.get("end") or None
        for v in (start, end):
            if v and not DATE.match(v):
                raise ValueError("Datum moet het formaat JJJJ-MM-DD hebben.")
        if start and end and end < start:
            raise ValueError("De einddatum ligt vóór de startdatum.")
        client.account(m.group(1))  # controleert of de pagina bestaat
        store.save_settings(m.group(1), start, end)  # cache-sleutels bevatten de datums, dus geen cache legen
        return store.get_settings(m.group(1))

    m = re.match(r"^/api/client/(\d+)/ads-settings$", path)
    if m:
        acct = body.get("ad_account_id") or None
        if acct and not re.match(r"^(act_)?\d+$", acct):
            raise ValueError("Ongeldig advertentieaccount.")
        client.account(m.group(1))
        store.save_ads_settings(m.group(1), bool(body.get("enabled")), acct)
        return store.get_ads_settings(m.group(1))
    raise NotFound(path)


class Handler(BaseHTTPRequestHandler):
    def _api(self, fn, path, arg):
        user = None
        if auth.required() and path not in PUBLIC_PATHS:
            try:
                user = auth.check(self.headers.get("Authorization"))
            except auth.AuthError as e:
                return self.send_json(401, {"error": str(e), "login": True})
        try:
            out = fn(path, arg, user)
            if isinstance(out, RawResponse):
                self.send_response(200)
                self.send_header("Content-Type", out.ctype)
                self.send_header("Content-Length", str(len(out.body)))
                if out.filename:
                    kind = "inline" if out.inline else "attachment"
                    self.send_header("Content-Disposition", f'{kind}; filename="{out.filename}"')
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(out.body)
                return
            self.send_json(200, out)
        except NotFound:
            self.send_json(404, {"error": "Onbekend endpoint"})
        except supa.SupaError as e:
            self.send_json(503, {"error": str(e)})
        except ads.AdsError as e:
            self.send_json(409, {"error": str(e)})
        except ValueError as e:
            self.send_json(400, {"error": str(e)})
        except MetaApiError as e:
            self.send_json(502, {"error": f"Meta: {e}", "meta_code": e.code})
        except Exception as e:  # noqa
            traceback.print_exc()
            self.send_json(500, {"error": str(e)})

    def do_GET(self):
        path, qs = self._route()
        if path.startswith("/api/"):
            return self._api(get_api, path, qs)
        file = (PUBLIC / ("index.html" if path == "/" else path.lstrip("/"))).resolve()
        if file.is_file() and PUBLIC.resolve() in file.parents:
            ctype = {".html": "text/html", ".js": "text/javascript", ".css": "text/css",
                     ".svg": "image/svg+xml"}.get(file.suffix, "application/octet-stream")
            self.send_response(200)
            self.send_header("Content-Type", ctype + "; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(file.read_bytes())
        else:
            self.send_json(404, {"error": "Niet gevonden"})

    def _route(self):
        """Pad en query. Op Vercel komt alles binnen als /api/index?__p=<rest van het pad>."""
        url = urllib.parse.urlparse(self.path)
        qs = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
        path = url.path
        if "__p" in qs:
            path = "/api/" + qs.pop("__p").lstrip("/")
        return path, qs

    def do_POST(self):
        path, _ = self._route()
        try:
            length = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(length) or b"{}")
        except ValueError:
            return self.send_json(400, {"error": "Ongeldige JSON"})
        self._api(post_api, path, body)

    def send_json(self, status, obj):
        body = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        print("  ", fmt % args)


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("META_ACCESS_TOKEN ontbreekt. Zet hem in .env.")
    if store.sb():
        try:
            store.ensure_clients(client.list_accounts())
            moved = store.migrate_local_to_supabase()
            print(f"Supabase gekoppeld{f' ({moved} instellingen overgezet)' if moved else ''}. Verversen op: "
                  + ", ".join(store.get_app_settings().get("sync_times", [])))
        except supa.SupaError as e:
            print("Supabase: " + str(e))
        threading.Thread(target=sync.scheduler, args=(client,), daemon=True).start()
    print(f"Dashboard draait op http://localhost:{PORT}")
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
