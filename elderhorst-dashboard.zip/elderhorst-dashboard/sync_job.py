"""
Verversen vanuit GitHub Actions (of met de hand).

  python3 sync_job.py            ververst alleen als het tijd is (ingestelde tijden) of als er een nieuw account is
  python3 sync_job.py --force    ververst altijd ('Nu verversen')

Leest META_ACCESS_TOKEN, SUPABASE_URL en SUPABASE_SERVICE_KEY uit de omgeving of uit .env.
"""
import os
import sys
import time

os.environ.setdefault("TZ", "Europe/Amsterdam")
time.tzset()

import server  # noqa: E402 – laadt .env en maakt de Meta-client
import store  # noqa: E402
import sync  # noqa: E402


def main():
    if not server.TOKEN:
        sys.exit("META_ACCESS_TOKEN ontbreekt.")
    if not store.sb():
        sys.exit("SUPABASE_URL / SUPABASE_SERVICE_KEY ontbreken.")
    force = "--force" in sys.argv
    reason = os.environ.get("SYNC_REASON") or "handmatig"
    if not force:
        reason = sync.due(server.client)
        if not reason:
            print("Niets te doen: geen gepland moment voorbij en geen nieuwe accounts.")
            return
    print(f"Verversen ({reason})…")
    out = sync.run(server.client, reason)
    print(out)
    if out and out.get("errors"):
        print("\n".join(out["errors"]))


if __name__ == "__main__":
    main()
