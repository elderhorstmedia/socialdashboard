"""
Minimale Supabase-client via de REST-API (PostgREST). Alleen standaardbibliotheek.
Configuratie in .env: SUPABASE_URL en SUPABASE_SERVICE_KEY (service_role / secret key – nooit delen).
"""
import json
import os
import urllib.error
import urllib.parse
import urllib.request


class SupaError(Exception):
    pass


class Supabase:
    def __init__(self, url, key):
        self.base = url.rstrip("/") + "/rest/v1"
        self.key = key

    def _req(self, method, table, params=None, body=None, prefer=None):
        url = f"{self.base}/{table}"
        if params:
            url += "?" + urllib.parse.urlencode(params, safe=",.()*:")
        headers = {"apikey": self.key, "Authorization": f"Bearer {self.key}", "Content-Type": "application/json"}
        if prefer:
            headers["Prefer"] = prefer
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                raw = r.read()
        except urllib.error.HTTPError as e:
            detail = e.read().decode(errors="replace")
            try:
                detail = json.loads(detail).get("message", detail)
            except ValueError:
                pass
            if e.code == 404 or "does not exist" in detail or "schema cache" in detail:
                raise SupaError(f"Tabel '{table}' bestaat niet. Voer supabase_schema.sql uit in de SQL Editor van Supabase.")
            raise SupaError(f"Supabase {e.code}: {detail}")
        except urllib.error.URLError as e:
            raise SupaError(f"Supabase niet bereikbaar: {e.reason}")
        return json.loads(raw) if raw else None

    def select(self, table, filters=None, select="*", order=None, limit=None):
        params = {"select": select, **(filters or {})}
        if order:
            params["order"] = order
        if limit:
            params["limit"] = limit
        return self._req("GET", table, params) or []

    def upsert(self, table, rows, on_conflict):
        rows = list(rows)
        for i in range(0, len(rows), 500):
            self._req("POST", table, {"on_conflict": on_conflict}, rows[i:i + 500],
                      prefer="resolution=merge-duplicates,return=minimal")
        return len(rows)

    def insert(self, table, row):
        out = self._req("POST", table, None, row, prefer="return=representation")
        return out[0] if out else None

    def update(self, table, filters, values):
        self._req("PATCH", table, filters, values, prefer="return=minimal")


def from_env():
    url, key = os.environ.get("SUPABASE_URL", ""), os.environ.get("SUPABASE_SERVICE_KEY", "")
    return Supabase(url, key) if url and key else None
