"""
Synchronisatie Meta → Supabase.

Per ronde:
1. Klanten bijwerken en nieuwe pagina's / advertentieaccounts herkennen.
2. Dagcijfers (daily_metrics) aanvullen vanaf de laatst opgeslagen dag (eerste keer: zo ver terug als Meta geeft).
3. Dashboardcijfers vooraf berekenen (overzicht + laatste 30 dagen per klant) en in computed_cache zetten.

Draait automatisch op de ingestelde tijden (standaard 06:00 en 18:00), bij nieuwe accounts, of via 'Nu verversen'.
Online gebeurt dat via GitHub Actions (.github/workflows/sync.yml → sync_job.py), lokaal door de server zelf.
Een lopende ronde staat in sync_log (zonder finished_at), zodat er nooit twee tegelijk draaien.
"""
import json
import os
import threading
import time
import traceback
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta

import ads
import analytics
import store
import supa
from meta_client import MetaApiError, _num, _ts, chunks, value_day

FB_BACKFILL_DAYS = 728      # Meta: ~2 jaar
IG_REACH_BACKFILL_DAYS = 728
IG_DAILY_BACKFILL_DAYS = 7  # weergaven/interacties per dag kosten 1 verzoek per dag; daarna groeit het vanzelf aan
ADS_BACKFILL_DAYS = 365

_state = {"running": False, "step": None, "progress": None, "started": None, "last": None, "error": None}
_run_lock = threading.Lock()


RUN_TIMEOUT = 45 * 60   # een ronde die langer 'bezig' staat, is afgebroken


def state():
    """Status van deze server, aangevuld met een ronde die elders draait (GitHub Actions)."""
    out = dict(_state)
    if not out["running"]:
        other = running_elsewhere()
        if other:
            msg = other.get("message") or ""
            out.update(running=True, started=other.get("started_at"), step=msg.split(": ", 1)[-1] if msg.startswith("bezig") else msg,
                       progress=None)
    return out


def _parse(ts):
    return store.parse_ts(ts)


def running_elsewhere():
    """De laatste ronde in sync_log als die nog bezig is (en niet te oud)."""
    sbc = store.sb()
    if not sbc:
        return None
    try:
        rows = sbc.select("sync_log", select="id,started_at,finished_at,message", order="started_at.desc", limit=1)
    except supa.SupaError:
        return None
    if rows and not rows[0]["finished_at"] and time.time() - _parse(rows[0]["started_at"]) < RUN_TIMEOUT:
        return rows[0]
    return None


def github_dispatch(reason="handmatig"):
    """Start de verversing in GitHub Actions (online: daar mag een verzoek niet 12 minuten duren)."""
    repo, tok = os.environ.get("GITHUB_REPO"), os.environ.get("GITHUB_TOKEN")
    if not repo or not tok:
        raise ValueError("Nu verversen werkt online via GitHub. Zet GITHUB_REPO en GITHUB_TOKEN bij de Environment Variables in Vercel.")
    req = urllib.request.Request(f"https://api.github.com/repos/{repo}/actions/workflows/sync.yml/dispatches", method="POST",
                                 data=json.dumps({"ref": os.environ.get("GITHUB_BRANCH", "main"),
                                                  "inputs": {"reason": reason}}).encode(),
                                 headers={"Authorization": f"Bearer {tok}", "Accept": "application/vnd.github+json",
                                          "Content-Type": "application/json", "User-Agent": "dashboard"})
    try:
        urllib.request.urlopen(req, timeout=20).close()
    except urllib.error.HTTPError as e:
        raise ValueError(f"GitHub weigerde het starten ({e.code}). Controleer GITHUB_REPO en de rechten van GITHUB_TOKEN.")
    return True


def _last_day(sbc, pid, channel):
    rows = sbc.select("daily_metrics", {"page_id": f"eq.{pid}", "channel": f"eq.{channel}"}, select="day", order="day.desc", limit=1)
    return date.fromisoformat(rows[0]["day"]) if rows else None


def _start_from(sbc, pid, channel, backfill):
    """Vanaf welke dag ophalen: de laatst opgeslagen dag (opnieuw, die kan nog veranderd zijn) of de backfill-grens."""
    last = _last_day(sbc, pid, channel)
    y = analytics.yesterday()
    floor = y - timedelta(days=backfill - 1)
    return max(floor, last - timedelta(days=2)) if last else floor


def _row(pid, channel, day, **vals):
    def i(v):
        return None if v is None else int(round(v))
    return {"page_id": pid, "channel": channel, "day": day.isoformat(),
            "followers": i(vals.get("followers")), "new_followers": i(vals.get("new_followers")),
            "reach": i(vals.get("reach")), "views": i(vals.get("views")), "interactions": i(vals.get("interactions")),
            "spend": vals.get("spend"), "impressions": i(vals.get("impressions")), "link_clicks": i(vals.get("link_clicks")),
            "results": i(vals.get("results")), "result_type": vals.get("result_type"),
            "updated_at": store._now()}


def snapshot_facebook(c, sbc, acc):
    pid, y = acc["page_id"], analytics.yesterday()
    since = _start_from(sbc, pid, "facebook", FB_BACKFILL_DAYS)
    if since > y:
        return 0
    daily = analytics.fb_daily(c, pid, since, y, ["page_follows", "page_daily_follows_unique", "page_total_media_view_unique",
                                                  "page_media_view", "page_post_engagements"])
    days = sorted(set().union(*[set(v) for v in daily.values()]) if daily else set())
    rows = [_row(pid, "facebook", d, followers=daily["page_follows"].get(d) or None,
                 new_followers=daily["page_daily_follows_unique"].get(d), reach=daily["page_total_media_view_unique"].get(d),
                 views=daily["page_media_view"].get(d), interactions=daily["page_post_engagements"].get(d)) for d in days]
    return sbc.upsert("daily_metrics", rows, "page_id,channel,day") if rows else 0


def snapshot_instagram(c, sbc, acc):
    ig = acc.get("instagram")
    if not ig:
        return 0
    pid, y = acc["page_id"], analytics.yesterday()
    tok = c.page_token(pid)
    since = _start_from(sbc, pid, "instagram", IG_REACH_BACKFILL_DAYS)
    if since > y:
        return 0
    data = {}
    # Bereik per dag (Meta geeft dit als reeks, max. 30 dagen per verzoek)
    for s, u in chunks(since, y, 30):
        try:
            res = c.get(f"{ig['id']}/insights", {"metric": "reach", "period": "day",
                                                 "since": _ts(s), "until": _ts(u + timedelta(days=1))}, token=tok)["data"]
            for m in res:
                for v in m.get("values", []):
                    d = value_day(v["end_time"])
                    if since <= d <= y:
                        data.setdefault(d, {})["reach"] = _num(v.get("value"))
        except MetaApiError:
            pass
    # Nieuwe volgers per dag (Meta geeft alleen de laatste 30 dagen)
    f_since = max(since, date.today() - timedelta(days=30))
    if f_since <= y:
        try:
            res = c.get(f"{ig['id']}/insights", {"metric": "follower_count", "period": "day",
                                                 "since": _ts(f_since), "until": _ts(y + timedelta(days=1))}, token=tok)["data"]
            for m in res:
                for v in m.get("values", []):
                    d = value_day(v["end_time"])
                    if f_since <= d <= y:
                        data.setdefault(d, {})["new_followers"] = _num(v.get("value"))
        except MetaApiError:
            pass
    # Weergaven en interacties per dag: 1 verzoek per dag, alleen voor recente dagen
    v_since = max(since, y - timedelta(days=IG_DAILY_BACKFILL_DAYS - 1))
    d = v_since
    while d <= y:
        w = analytics.ig_window(c, ig["id"], tok, d, d, ["views", "total_interactions"])
        if w:
            data.setdefault(d, {}).update({"views": w.get("views"), "interactions": w.get("total_interactions")})
        d += timedelta(days=1)
    # Volgersstand: alleen het huidige aantal is bekend; we leggen het vast op gisteren
    data.setdefault(y, {})["followers"] = ig.get("followers")
    rows = [_row(pid, "instagram", d, **v) for d, v in sorted(data.items())]
    return sbc.upsert("daily_metrics", rows, "page_id,channel,day") if rows else 0


def snapshot_ads(c, sbc, acc):
    st = store.get_ads_settings(acc["page_id"])
    if not st["enabled"] or not st["ad_account_id"]:
        return 0
    pid, y = acc["page_id"], analytics.yesterday()
    acct = st["ad_account_id"] if st["ad_account_id"].startswith("act_") else "act_" + st["ad_account_id"]
    since = _start_from(sbc, pid, "ads", ADS_BACKFILL_DAYS)
    if since > y:
        return 0
    wide = ads.summarize((ads._insights(c, acct, y - timedelta(days=29), y) or [None])[0])
    rtype = wide and wide.get("result_type")
    rows = []
    for r in ads._insights(c, acct, since, y, time_increment=1):
        s = ads.summarize(r, rtype)
        rows.append(_row(pid, "ads", date.fromisoformat(r["date_start"]), reach=s["reach"], spend=round(s["spend"], 2),
                         impressions=s["impressions"], link_clicks=s["link_clicks"], results=s["results"],
                         result_type=s["result_type"]))
    return sbc.upsert("daily_metrics", rows, "page_id,channel,day") if rows else 0


def precompute(c, acc):
    """Dashboardcijfers vooraf berekenen en in Supabase zetten, zodat het dashboard direct laadt."""
    pid = acc["page_id"]
    st = store.get_settings(pid)
    store.computed_set(overview_key(pid, st), analytics.client_overview(c, acc, st), pid)
    y = analytics.yesterday()
    since = y - timedelta(days=29)
    store.computed_set(results_key(pid, since, y, st), analytics.client_results(c, pid, since, y), pid)


def overview_key(pid, st):
    return f"overview:{pid}:{st.get('start')}:{st.get('end')}:{date.today()}"


def results_key(pid, since, until, st):
    return f"results:{pid}:{since}:{until}:{st.get('start')}:{st.get('end')}:{date.today()}"


def detect_new_accounts(c):
    """Geeft nieuwe pagina's en advertentieaccounts terug (en onthoudt ze)."""
    sbc = store.sb()
    if not sbc:
        return []
    pages = [(a["page_id"], "page", a["page_name"]) for a in c.list_accounts()]
    try:
        pages += [(a["id"], "ad_account", a["name"]) for a in ads.ad_accounts(c)]
    except ads.AdsError:
        pass
    known = {r["id"] for r in sbc.select("known_accounts", select="id")}
    new = [p for p in pages if p[0] not in known]
    if new:
        sbc.upsert("known_accounts", [{"id": i, "kind": k, "name": n} for i, k, n in new], "id")
    # De allereerste keer is alles 'nieuw': dat telt niet als nieuw account
    return new if known else []


def run(c, reason="handmatig"):
    """Eén volledige synchronisatie. Veilig om dubbel aan te roepen (tweede wacht niet maar stopt meteen)."""
    sbc = store.sb()
    if not sbc:
        raise supa.SupaError("Supabase is niet ingesteld (SUPABASE_URL en SUPABASE_SERVICE_KEY in .env).")
    if not _run_lock.acquire(blocking=False):
        return {"skipped": "loopt al"}
    if running_elsewhere():
        _run_lock.release()
        return {"skipped": "loopt al ergens anders"}
    t0 = time.time()
    _state.update(running=True, step="starten", progress=None, started=datetime.now().isoformat(timespec="seconds"), error=None)
    rows, errors, log = 0, [], None
    try:
        log = sbc.insert("sync_log", {"message": f"gestart ({reason})"})
        store.cache_clear_recent()          # verse cijfers bij Meta ophalen
        accounts = c.list_accounts()
        store.ensure_clients(accounts)
        store.migrate_local_to_supabase()
        detect_new_accounts(c)
        for i, acc in enumerate(accounts, 1):
            _state.update(step=acc["page_name"], progress=f"{i}/{len(accounts)}")
            if log:
                try:
                    sbc.update("sync_log", {"id": f"eq.{log['id']}"}, {"message": f"bezig ({reason}): {acc['page_name']} ({i}/{len(accounts)})"})
                except supa.SupaError:
                    pass
            for fn in (snapshot_facebook, snapshot_instagram, snapshot_ads):
                try:
                    rows += fn(c, sbc, acc)
                except Exception as e:  # noqa – één klant of kanaal mag de rest niet stoppen
                    errors.append(f"{acc['page_name']} ({fn.__name__.split('_')[1]}): {e}")
            try:
                precompute(c, acc)
            except Exception as e:  # noqa
                errors.append(f"{acc['page_name']} (cache): {e}")
        msg = f"klaar ({reason}): {len(accounts)} klanten, {rows} dagregels" + (f", {len(errors)} fouten" if errors else "")
    except Exception as e:  # noqa
        traceback.print_exc()
        msg, errors = f"mislukt ({reason}): {e}", errors + [str(e)]
    finally:
        took = round(time.time() - t0)
        if log:
            try:
                sbc.update("sync_log", {"id": f"eq.{log['id']}"},
                           {"finished_at": store._now(), "rows": rows, "message": msg + (" | " + " | ".join(errors[:10]) if errors else "")})
            except supa.SupaError:
                pass
        _state.update(running=False, step=None, progress=None, last={"message": msg, "seconds": took, "errors": errors[:10],
                                                                       "finished": datetime.now().isoformat(timespec="seconds")},
                      error=errors[0] if errors else None)
        _run_lock.release()
    return _state["last"]


def run_in_background(c, reason="handmatig"):
    if _state["running"]:
        return False
    threading.Thread(target=run, args=(c, reason), daemon=True).start()
    return True


# ---------- planner ----------
def _due_slot(times, last_run):
    """Laatste geplande tijdstip dat al voorbij is en nog niet gedraaid heeft (ook na slaapstand/herstart)."""
    now = datetime.now()
    slots = []
    for day_offset in (0, 1):
        d = (now - timedelta(days=day_offset)).date()
        for t in times:
            try:
                h, m = map(int, t.split(":"))
                slots.append(datetime(d.year, d.month, d.day, h, m))
            except ValueError:
                continue
    past = [s for s in slots if s <= now]
    if not past:
        return None
    latest = max(past)
    return latest if not last_run or last_run < latest else None


def next_slot(times):
    now = datetime.now()
    slots = []
    for day_offset in (0, 1):
        d = (now + timedelta(days=day_offset)).date()
        for t in times:
            try:
                h, m = map(int, t.split(":"))
                slots.append(datetime(d.year, d.month, d.day, h, m))
            except ValueError:
                continue
    future = [s for s in slots if s > now]
    return min(future).isoformat(timespec="minutes") if future else None


def last_finished_run():
    sbc = store.sb()
    if not sbc:
        return None
    try:
        rows = sbc.select("sync_log", {"finished_at": "not.is.null"}, select="finished_at", order="finished_at.desc", limit=1)
    except supa.SupaError:
        return None
    if not rows:
        return None
    return datetime.fromtimestamp(_parse(rows[0]["finished_at"]))


def scheduler(c, check_every=60, account_check_every=15 * 60):
    """Achtergrondthread in de server: draait op de ingestelde tijden en bij nieuwe accounts."""
    last_account_check = 0
    while True:
        try:
            if store.sb() and not _state["running"]:
                cfg = store.get_app_settings()
                if _due_slot(cfg.get("sync_times") or [], last_finished_run()):
                    run(c, "gepland")
                elif cfg.get("sync_on_new_accounts") and time.time() - last_account_check > account_check_every:
                    last_account_check = time.time()
                    c._page_tokens.clear()
                    new = detect_new_accounts_fresh(c)
                    if new:
                        run(c, "nieuw account: " + ", ".join(n for _, _, n in new[:3]))
        except Exception:  # noqa – de planner mag nooit stoppen
            traceback.print_exc()
        time.sleep(check_every)


def due(c, check_accounts=True):
    """Moet er nu ververst worden? Geeft de reden terug, of None."""
    cfg = store.get_app_settings()
    if _due_slot(cfg.get("sync_times") or [], last_finished_run()):
        return "gepland"
    if check_accounts and cfg.get("sync_on_new_accounts"):
        new = detect_new_accounts_fresh(c)
        if new:
            return "nieuw account: " + ", ".join(n for _, _, n in new[:3])
    return None


def detect_new_accounts_fresh(c):
    """Accountlijst direct bij Meta ophalen (niet uit de cache) en vergelijken met de bekende accounts."""
    import sqlite3
    store.init()
    with sqlite3.connect(store.DB) as con:
        con.execute("DELETE FROM cache WHERE key LIKE 'me/accounts%' OR key LIKE 'me/adaccounts%'")
    return detect_new_accounts(c)
